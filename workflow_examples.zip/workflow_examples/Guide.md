# Workflow Quick Reference Guide

## 📋 All Four Workflows Created

### 1. **Document Comparison Workflow** (`document_comparison.yaml`)

**Best for:** Legal teams, compliance officers, version control

- **Input:** 2 document versions (PDF, DOCX, TXT)
- **Processing Time:** 5-15 minutes
- **Output:** HTML report, PDF summary, Excel change log, JSON data
- **Key Features:**
  - Side-by-side comparison with semantic understanding
  - Critical change detection (legal, financial, dates)
  - Risk assessment for modifications
  - Multi-format output options

**Quick Start:**

```yaml
# Upload both documents
# Select comparison type: detailed, summary, or semantic
# Enable critical change flagging
# Choose output formats
```

---

### 2. **Entity Extraction Workflow** (`entity_extraction.yaml`)

**Best for:** Data entry automation, KYC processing, resume parsing

- **Input:** 1-100 documents (PDF, DOCX, TXT, images)
- **Processing Time:** 10-30 minutes
- **Output:** JSON, CSV, Excel, Knowledge Graph
- **Key Features:**
  - Batch processing with 13+ entity types
  - Quality-based routing (auto-retry for low quality)
  - Relationship extraction between entities
  - Validation and normalization

**Quick Start:**

```yaml
# Upload documents (up to 100)
# Select document type preset or generic
# Choose entity types to extract
# Set confidence threshold (0.7 recommended)
# Select output formats
```

---

### 3. **Contract Risk Analysis Workflow** (`contract_risk_analysis.yaml`)

**Best for:** Legal teams, procurement, contract management

- **Input:** 1 contract (PDF, DOCX)
- **Processing Time:** 2-5 minutes
- **Output:** PDF risk report, JSON data export
- **Key Features:**
  - Clause-by-clause risk assessment
  - Missing protection identification
  - Overall risk scoring (0-100)
  - Negotiation strategy recommendations

**Quick Start:**

```yaml
# Upload contract
# Select contract type (employment, vendor, etc.)
# Specify your role (buyer, seller, etc.)
# Set risk tolerance level
# Optionally add industry/jurisdiction context
```

---

### 4. **Invoice Processing Workflow** (`invoice_processing.yaml`)

**Best for:** Accounts payable, finance automation, invoice processing

- **Input:** 1-500 invoices (PDF, images)
- **Processing Time:** 5-20 minutes
- **Output:** CSV, Excel, JSON, or direct API integration
- **Key Features:**
  - Batch processing with OCR support
  - Mathematical validation
  - PO matching and vendor validation
  - Auto-approval based on rules
  - GL account mapping

**Quick Start:**

```yaml
# Upload invoices (up to 500)
# Optionally upload PO reference data
# Optionally upload vendor master file
# Set auto-approve threshold ($)
# Choose output format (CSV, Excel, JSON, API)
```

---

## 🔧 Common Configuration Patterns

### Adjusting Batch Processing

**Small files (quick processing):**

```yaml
batch_size: 20
concurrency: 10-15
```

**Large files (more careful):**

```yaml
batch_size: 5
concurrency: 3-5
```

### Modifying Timeout

**Simple workflows:**

```yaml
config:
  timeout: 300  # 5 minutes
```

**Complex workflows:**

```yaml
config:
  timeout: 1800  # 30 minutes
```

---

## 📊 Workflow Comparison Table

| Feature | Doc Comparison | Entity Extraction | Contract Risk | Invoice Processing |
|---------|----------------|-------------------|---------------|-------------------|
| **Max Files** | 2 | 100 | 1 | 500 |
| **Nodes** | 10 | 12 | 13 | 12 |
| **Parallel Processing** | ✅ Yes | ✅ Yes | ✅ Yes | ✅ Yes |
| **OCR Support** | ❌ No | ✅ Yes | ✅ Yes | ✅ Yes |
| **Quality Retry** | ❌ No | ✅ Yes | ❌ No | ❌ No |
| **API Integration** | ✅ Yes | ✅ Yes | ✅ Yes | ✅ Yes |
| **Cost per Doc** | $0.50-1.00 | $0.30-0.80 | $0.20-0.40 | $0.15-0.30 |
| **Avg Time** | 5-15 min | 10-30 min | 2-5 min | 5-20 min |

---

## 🎯 Key Node Types Used

### 1. **Input Node**

- Handles file uploads
- Defines configuration fields
- Sets validation rules

### 2. **Agent Node**

- Runs AI model for processing
- Uses prompt templates
- Performs extraction/analysis

### 3. **Batch Node**

- Groups items for processing
- Optimizes parallel execution

### 4. **Parallel Node**

- Processes multiple items simultaneously
- Configurable concurrency limits

### 5. **Merge Node**

- Combines results from parallel processing
- Supports flatten, join, concatenate

### 6. **Conditional Node**

- Routes data based on conditions
- Supports multiple branches

### 7. **Output Node**

- Generates final deliverables
- Handles multiple formats
- Manages notifications

---

## 🔄 Common Workflow Patterns

### Pattern 1: Simple Sequential

```
Input → Process → Output
```

**Used in:** Basic transformations

### Pattern 2: Batch & Parallel

```bash
Input → Batch → [Parallel Processing] → Merge → Output
```

**Used in:** Entity Extraction, Invoice Processing

### Pattern 3: Quality-Based Routing

```bash
Input → Process → Quality Check →
  ├─ High Quality → Output
  ├─ Medium Quality → Output
  └─ Low Quality → Retry with Better Model → Output
```

**Used in:** Entity Extraction

### Pattern 4: Multi-Branch Analysis

```bash
Input → Extract →
  ├─ Analyze Aspect 1 →
  ├─ Analyze Aspect 2 →
  └─ Analyze Aspect 3 →
    → Merge → Generate Report → Output
```

**Used in:** Contract Risk Analysis

---

## 💡 Customization Tips

### Adding Custom Entity Types

```yaml
entity_types:
  - name: custom_field
    pattern: "REGEX_PATTERN"
    description: "What this field represents"
    validation: "validation_rule"
```

### Adding Custom Validation Rules

```yaml
validation:
  custom_checks:
    - name: business_rule_1
      condition: "expression"
      error_message: "Error if condition fails"
      severity: critical|high|medium|low
```

### Modifying Output Delivery

```yaml
delivery:
  - type: s3
    bucket: your-bucket
    key: "path/to/output.ext"
  
  - type: email
    to: [recipient@company.com]
    subject: "Custom subject"
    template: custom_template.html
  
  - type: webhook
    url: https://your-api.com/endpoint
    method: POST
    headers:
      Authorization: Bearer ${YOUR_API_KEY}
  
  - type: database
    connection: postgresql://...
    table: your_table
    action: insert|upsert
```

---

## 🐛 Troubleshooting Guide

### Issue: Workflow times out

**Solutions:**

- Increase timeout value in config
- Reduce batch size
- Increase concurrency for parallel nodes
- Use faster AI model (haiku instead of sonnet)

### Issue: Low extraction accuracy

**Solutions:**

- Switch to more powerful model (sonnet → opus)
- Adjust prompt template with examples
- Enable OCR if processing images
- Increase confidence threshold

### Issue: High costs

**Solutions:**

- Use small model for simple tasks
- Implement caching for repeated operations
- Pre-filter documents (remove blank pages)
- Reduce redundant processing steps

### Issue: Validation failures

**Solutions:**

- Check YAML syntax with validator
- Verify all node dependencies are correct
- Ensure input/output mappings match schema
- Test with smaller dataset first

### Issue: Missing entities

**Solutions:**

- Add specific entity types to extraction list
- Provide examples in prompt template
- Lower confidence threshold
- Enable relationship extraction

---

## ✅ Checklist for Production Deployment

- [ ] YAML syntax validated
- [ ] Tested with sample data
- [ ] Configured error handling
- [ ] Set up monitoring and alerts
- [ ] Documented custom modifications
- [ ] Configured backup/recovery
- [ ] Tested all output formats
- [ ] Validated API integrations
- [ ] Set up cost alerts
- [ ] Created runbook for operations team
- [ ] Performed security review
- [ ] Configured access controls

---