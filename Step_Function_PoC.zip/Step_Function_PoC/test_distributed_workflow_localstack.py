"""Test script for LocalStack-compatible distributed map batch workflow."""
import requests
import json
import time


API_URL = "http://localhost:8000"
WORKFLOW_ID = "distributed_map_batch_workflow_localstack"


def test_workflow_listing():
    """Test that the LocalStack workflow appears in the list."""
    print("\n=== Testing Workflow Listing ===\n")

    response = requests.get(f"{API_URL}/api/workflows/templates")

    if response.status_code == 200:
        data = response.json()
        workflows = data['workflows']

        # Find our workflow
        our_workflow = next((w for w in workflows if w['id'] == WORKFLOW_ID), None)

        if our_workflow:
            print(f"✅ Found workflow: {our_workflow['name']}")
            print(f"   Category: {our_workflow['category']}")
            print(f"   Features: {', '.join(our_workflow['features'])}")
            print(f"   Description: {our_workflow['description'][:80]}...")
            return True
        else:
            print(f"❌ Workflow '{WORKFLOW_ID}' not found in list")
            return False
    else:
        print(f"❌ Failed to list workflows: {response.status_code}")
        return False


def test_workflow_schema():
    """Test getting workflow schema."""
    print("\n=== Testing Workflow Schema ===\n")

    response = requests.get(f"{API_URL}/api/workflows/templates/{WORKFLOW_ID}")

    if response.status_code == 200:
        data = response.json()
        print(f"✅ Retrieved workflow schema")
        print(f"   States: {len(data['definition']['States'])}")
        print(f"   Required inputs: {', '.join(data['input_schema']['required'])}")
        print(f"\n   Example input:")
        print(f"   {json.dumps(data['input_schema']['example'], indent=4)}")
        return data
    else:
        print(f"❌ Failed to get schema: {response.status_code}")
        return None


def test_workflow_deployment():
    """Test deploying the workflow."""
    print("\n=== Testing Workflow Deployment ===\n")

    response = requests.post(
        f"{API_URL}/api/workflows/templates/{WORKFLOW_ID}/deploy"
    )

    if response.status_code == 200:
        data = response.json()
        print(f"✅ Workflow deployed successfully")
        print(f"   Status: {data['status']}")
        print(f"   Name: {data['name']}")
        print(f"   ARN: {data['stateMachineArn']}")
        return data
    else:
        print(f"❌ Deployment failed: {response.status_code}")
        print(f"   Error: {response.text}")
        return None


def test_workflow_execution(file_count=10):
    """Test executing the workflow with a batch of files."""
    print(f"\n=== Testing Workflow Execution ({file_count} files) ===\n")

    # Generate file list
    files = []
    for i in range(file_count):
        files.append({
            'bucket': 'test-batch-processing',
            'file_key': f'test-files/file_{i:06d}.pdf',
            'file_id': f'FILE-{i:06d}'
        })

    input_data = {
        'files': files,
        'expectedFileCount': file_count,
        'processingConfig': {
            'enableOCR': True,
            'enableNER': True,
            'enablePII': True
        },
        'notificationEmails': ['test@example.com']
    }

    # Start execution
    execution_name = f"test-batch-{file_count}-{int(time.time())}"
    response = requests.post(
        f"{API_URL}/api/workflows/templates/{WORKFLOW_ID}/execute",
        params={"execution_name": execution_name},
        json=input_data
    )

    if response.status_code == 200:
        execution = response.json()
        print(f"✅ Workflow execution started")
        print(f"   Execution ARN: {execution['executionArn']}")
        print(f"   Execution ID: {execution['executionId']}")
        print(f"   Start time: {execution['startDate']}")

        # Monitor execution
        print("\n⏳ Monitoring execution...")
        execution_arn = execution['executionArn']

        for attempt in range(30):  # Poll for up to 1 minute
            time.sleep(2)

            status_response = requests.get(
                f"{API_URL}/api/workflows/status/{execution_arn}"
            )

            if status_response.status_code == 200:
                status = status_response.json()
                current_status = status['status']
                print(f"   [{attempt+1}/30] Status: {current_status}")

                if current_status in ['SUCCEEDED', 'FAILED', 'TIMED_OUT', 'ABORTED']:
                    print(f"\n✅ Execution completed with status: {current_status}")

                    if current_status == 'SUCCEEDED':
                        output = status.get('output')
                        if output:
                            try:
                                output_data = json.loads(output) if isinstance(output, str) else output
                                print(f"\n📊 Execution Results:")
                                if 'statistics' in output_data:
                                    stats = output_data['statistics']
                                    print(f"   Total files: {stats.get('totalFiles', 0)}")
                                    print(f"   Successful: {stats.get('successfulFiles', 0)}")
                                    print(f"   Failed: {stats.get('failedFiles', 0)}")
                            except:
                                print(f"   Output: {output}")

                    elif current_status == 'FAILED':
                        print(f"\n❌ Execution failed:")
                        print(f"   Error: {status.get('error', 'Unknown')}")
                        print(f"   Cause: {status.get('cause', 'Unknown')}")

                    return status
            else:
                print(f"   ❌ Failed to get status: {status_response.status_code}")
                break

        print("\n⏰ Execution still running after monitoring period")
        return None

    else:
        print(f"❌ Execution failed to start: {response.status_code}")
        print(f"   Error: {response.text}")
        return None


def run_batch_size_tests():
    """Test with different batch sizes."""
    print("\n=== Testing Different Batch Sizes ===\n")

    test_cases = [
        {"size": 10, "desc": "Small batch (10 files)"},
        {"size": 50, "desc": "Medium batch (50 files)"},
        {"size": 100, "desc": "Large batch (100 files)"},
    ]

    results = []

    for test_case in test_cases:
        size = test_case["size"]
        desc = test_case["desc"]

        print(f"\n{'='*60}")
        print(f"Test: {desc}")
        print(f"{'='*60}")

        result = test_workflow_execution(file_count=size)
        results.append({
            'size': size,
            'desc': desc,
            'result': result
        })

        # Wait between tests
        if result:
            time.sleep(3)

    # Summary
    print(f"\n{'='*60}")
    print("Test Summary")
    print(f"{'='*60}")

    for test_result in results:
        size = test_result['size']
        result = test_result['result']

        if result and result.get('status') == 'SUCCEEDED':
            print(f"✅ {size} files: SUCCEEDED")
        elif result:
            print(f"❌ {size} files: {result.get('status', 'UNKNOWN')}")
        else:
            print(f"⏰ {size} files: TIMEOUT")


if __name__ == "__main__":
    print("=" * 80)
    print("Distributed Map Batch Workflow (LocalStack) - Test Suite")
    print("=" * 80)

    try:
        # Test 1: Check workflow is listed
        if not test_workflow_listing():
            print("\n❌ Workflow not found - stopping tests")
            exit(1)

        # Test 2: Get workflow schema
        schema = test_workflow_schema()
        if not schema:
            print("\n❌ Failed to get schema - stopping tests")
            exit(1)

        # Test 3: Deploy workflow
        deployment = test_workflow_deployment()
        if not deployment:
            print("\n❌ Failed to deploy - stopping tests")
            exit(1)

        # Test 4: Run single execution test
        print("\n" + "=" * 80)
        print("Single Execution Test")
        print("=" * 80)
        test_workflow_execution(file_count=10)

        # Test 5: Run batch size tests (optional - comment out if too slow)
        # run_batch_size_tests()

        print("\n" + "=" * 80)
        print("✅ All tests completed!")
        print("=" * 80)

    except requests.exceptions.ConnectionError:
        print("\n❌ Error: Cannot connect to API server at http://localhost:8000")
        print("   Please ensure the backend server is running:")
        print("   cd backend && docker compose up -d")
    except KeyboardInterrupt:
        print("\n\n⚠️  Tests interrupted by user")
    except Exception as e:
        print(f"\n❌ Unexpected error: {str(e)}")
        import traceback
        traceback.print_exc()
