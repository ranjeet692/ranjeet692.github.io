# Quick Start Guide

Get started with the LLM Document Processing Orchestration PoC in 5 minutes!

## Prerequisites

- Docker Desktop installed and running
- 8GB+ RAM available
- Ports 3000, 4566, and 8000 available

## 🚀 Start in 3 Steps

### 1. Run the Start Script

```bash
./start.sh
```

This will:
- Create `.env` file from template
- Start all services (LocalStack, Backend, Frontend)
- Wait for initialization
- Display access URLs

### 2. Access the Dashboard

Open your browser to: **http://localhost:3000**

### 3. Process Documents

1. **Select files** from the list (sample files are pre-loaded)
2. **Click "Start Processing"**
3. **Watch real-time progress** via WebSocket updates

## 🎯 What You'll See

### Dashboard Features
- **File Selection**: Choose documents from S3
- **Execution Control**: Start, stop, and monitor workflows
- **Real-time Progress**: Live updates via WebSocket
- **Metrics**: Success rates, processing times, execution counts

### Processing Flow
1. Files are chunked based on size
2. Chunks processed in parallel (simulated LLM)
3. Results aggregated per file
4. Real-time status updates throughout

## 📊 Example Workflow

```bash
# Start processing 5 sample files
1. Open http://localhost:3000
2. Select all 5 sample files
3. Click "Start Processing"
4. Watch execution progress in real-time
5. Processing takes 10-60 seconds per chunk (simulated)
```

## 🔍 View What's Happening

### Backend Logs
```bash
docker compose logs -f backend
```

### Lambda Execution Logs
```bash
docker compose logs -f localstack | grep "Lambda"
```

### All Services
```bash
docker compose logs -f
```

## 🛠️ Common Tasks

### Add Your Own Files

```bash
# Copy file to S3 bucket
aws --endpoint-url=http://localhost:4566 s3 cp myfile.txt s3://document-processing-bucket/
```

### Check Step Functions Execution

```bash
# List all executions
aws --endpoint-url=http://localhost:4566 stepfunctions list-executions \
  --state-machine-arn arn:aws:states:us-east-1:000000000000:stateMachine:DocumentProcessingWorkflow
```

### View Processing State

```bash
# Query DynamoDB for execution state
aws --endpoint-url=http://localhost:4566 dynamodb scan \
  --table-name document-processing-state
```

### Test API Directly

```bash
# Health check
curl http://localhost:8000/health

# List files
curl http://localhost:8000/api/workflows/files

# View API docs
open http://localhost:8000/docs
```

## 🔧 Configuration

### Adjust Processing Time

Edit `.env`:
```bash
MIN_PROCESSING_TIME=5
MAX_PROCESSING_TIME=30
```

Restart backend:
```bash
docker compose restart backend
```

### Change Concurrency

Edit `.env`:
```bash
MAX_CONCURRENT_EXECUTIONS=20
```

Or set per execution in the API request.

### Modify Chunk Size

Edit `.env`:
```bash
CHUNK_SIZE_MB=10
```

## ⚠️ Troubleshooting

### Services Won't Start

```bash
# Stop everything
docker compose down

# Check Docker resources
docker stats

# Restart
./start.sh
```

### Can't Access Dashboard

```bash
# Check if frontend is running
curl http://localhost:3000

# Check logs
docker compose logs frontend

# Restart frontend
docker compose restart frontend
```

### LocalStack Issues

```bash
# Check LocalStack logs
docker compose logs localstack

# Restart LocalStack
docker compose restart localstack

# Wait 1-2 minutes for full initialization
```

### WebSocket Not Connecting

```bash
# Check backend is running
curl http://localhost:8000/health

# Check CORS settings (should allow localhost:3000)
docker compose logs backend | grep CORS
```

## 📚 Next Steps

1. **Explore API**: http://localhost:8000/docs
2. **Read Full README**: See detailed architecture and features
3. **Customize Lambdas**: Edit functions in `backend/lambdas/`
4. **Modify Workflow**: Edit `backend/stepfunctions/workflow.json`
5. **Deploy to AWS**: Follow deployment guide in README

## 🛑 Stop Services

```bash
docker compose down
```

To remove all data:
```bash
docker compose down -v
```

## 💡 Tips

- Sample files are auto-created in S3 on startup
- Processing time is random (10-60s) to simulate real LLM
- WebSocket updates every 2 seconds
- All executions are tracked in DynamoDB
- Failed chunks automatically retry 3 times

## 🎓 Understanding the Flow

```
User Action (Frontend)
    ↓
API Request (FastAPI)
    ↓
Start Step Functions Execution
    ↓
┌─────────────────────────────┐
│  For Each File:             │
│  1. Chunk file (Lambda)     │
│  2. Process chunks (Lambda) │ ← Parallel processing
│  3. Aggregate (Lambda)      │
└─────────────────────────────┘
    ↓
Results in DynamoDB
    ↓
WebSocket Updates to Frontend
```

---

**Need help?** Check the full README or view logs with `docker compose logs`