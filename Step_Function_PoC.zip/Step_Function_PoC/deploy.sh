#!/bin/bash

# Deployment script for LLM Orchestration PoC to AWS
# Usage: ./deploy.sh [environment] [region]

set -e

ENVIRONMENT=${1:-dev}
AWS_REGION=${2:-us-east-1}
STACK_NAME="${ENVIRONMENT}-llm-orchestration"

echo "=========================================="
echo "Deploying LLM Orchestration PoC"
echo "Environment: $ENVIRONMENT"
echo "Region: $AWS_REGION"
echo "=========================================="

# 1. Deploy CloudFormation Stack
echo "Step 1: Deploying CloudFormation stack..."
aws cloudformation deploy \
    --template-file infrastructure/cloudformation/stack.yaml \
    --stack-name $STACK_NAME \
    --parameter-overrides EnvironmentName=$ENVIRONMENT \
    --capabilities CAPABILITY_NAMED_IAM \
    --region $AWS_REGION

echo "Waiting for stack to complete..."
aws cloudformation wait stack-create-complete \
    --stack-name $STACK_NAME \
    --region $AWS_REGION || true

# Get stack outputs
echo "Getting stack outputs..."
DOCUMENT_BUCKET=$(aws cloudformation describe-stacks \
    --stack-name $STACK_NAME \
    --query 'Stacks[0].Outputs[?OutputKey==`DocumentBucketName`].OutputValue' \
    --output text \
    --region $AWS_REGION)

STATE_MACHINE_ARN=$(aws cloudformation describe-stacks \
    --stack-name $STACK_NAME \
    --query 'Stacks[0].Outputs[?OutputKey==`StateMachineArn`].OutputValue' \
    --output text \
    --region $AWS_REGION)

echo "Document Bucket: $DOCUMENT_BUCKET"
echo "State Machine ARN: $STATE_MACHINE_ARN"

# 2. Package and Deploy Lambda Functions
echo ""
echo "Step 2: Deploying Lambda functions..."

# Chunker Lambda
echo "Deploying Chunker Lambda..."
cd backend/lambdas/chunker
zip -r function.zip handler.py
aws lambda update-function-code \
    --function-name ${ENVIRONMENT}-document-chunker \
    --zip-file fileb://function.zip \
    --region $AWS_REGION
rm function.zip
cd ../../..

# Processor Lambda
echo "Deploying Processor Lambda..."
cd backend/lambdas/processor
zip -r function.zip handler.py
aws lambda update-function-code \
    --function-name ${ENVIRONMENT}-document-processor \
    --zip-file fileb://function.zip \
    --region $AWS_REGION
rm function.zip
cd ../../..

# Aggregator Lambda
echo "Deploying Aggregator Lambda..."
cd backend/lambdas/aggregator
zip -r function.zip handler.py
aws lambda update-function-code \
    --function-name ${ENVIRONMENT}-result-aggregator \
    --zip-file fileb://function.zip \
    --region $AWS_REGION
rm function.zip
cd ../..

# 3. Update Step Functions Definition
echo ""
echo "Step 3: Updating Step Functions state machine..."

# Get Lambda ARNs
CHUNKER_ARN=$(aws lambda get-function \
    --function-name ${ENVIRONMENT}-document-chunker \
    --query 'Configuration.FunctionArn' \
    --output text \
    --region $AWS_REGION)

PROCESSOR_ARN=$(aws lambda get-function \
    --function-name ${ENVIRONMENT}-document-processor \
    --query 'Configuration.FunctionArn' \
    --output text \
    --region $AWS_REGION)

AGGREGATOR_ARN=$(aws lambda get-function \
    --function-name ${ENVIRONMENT}-result-aggregator \
    --query 'Configuration.FunctionArn' \
    --output text \
    --region $AWS_REGION)

# Replace ARNs in workflow definition
sed "s|arn:aws:lambda:us-east-1:000000000000:function:document-chunker|$CHUNKER_ARN|g" stepfunctions/workflow.json > /tmp/workflow.json
sed -i "s|arn:aws:lambda:us-east-1:000000000000:function:document-processor|$PROCESSOR_ARN|g" /tmp/workflow.json
sed -i "s|arn:aws:lambda:us-east-1:000000000000:function:result-aggregator|$AGGREGATOR_ARN|g" /tmp/workflow.json

# Update state machine
aws stepfunctions update-state-machine \
    --state-machine-arn $STATE_MACHINE_ARN \
    --definition file:///tmp/workflow.json \
    --region $AWS_REGION

rm /tmp/workflow.json

# 4. Upload Sample Files
echo ""
echo "Step 4: Uploading sample files to S3..."
for i in {1..5}; do
    echo "Sample document $i" > /tmp/sample_$i.txt
    aws s3 cp /tmp/sample_$i.txt s3://$DOCUMENT_BUCKET/sample_$i.txt --region $AWS_REGION
    rm /tmp/sample_$i.txt
done

echo ""
echo "=========================================="
echo "Deployment Complete!"
echo "=========================================="
echo "Document Bucket: $DOCUMENT_BUCKET"
echo "State Machine ARN: $STATE_MACHINE_ARN"
echo ""
echo "Next steps:"
echo "1. Update backend .env file with AWS values"
echo "2. Deploy backend API (ECS, EKS, or EC2)"
echo "3. Build and deploy frontend"
echo ""
echo "To test locally with AWS:"
echo "  USE_LOCALSTACK=false"
echo "  AWS_ENDPOINT_URL="
echo "  STATE_MACHINE_ARN=$STATE_MACHINE_ARN"
echo "  S3_BUCKET_NAME=$DOCUMENT_BUCKET"