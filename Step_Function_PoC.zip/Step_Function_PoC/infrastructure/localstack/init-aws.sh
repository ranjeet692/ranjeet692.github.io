#!/bin/bash

echo "Initializing LocalStack resources..."

# Set endpoint
export AWS_ENDPOINT_URL=http://localhost:4566
export AWS_REGION=us-east-1
export AWS_ACCESS_KEY_ID=test
export AWS_SECRET_ACCESS_KEY=test

# Create S3 buckets
echo "Creating S3 buckets..."
awslocal s3 mb s3://document-processing-bucket
awslocal s3 mb s3://document-processing-results

# Create DynamoDB tables
echo "Creating DynamoDB tables..."

# State tracking table
awslocal dynamodb create-table \
    --table-name document-processing-state \
    --attribute-definitions \
        AttributeName=execution_id,AttributeType=S \
        AttributeName=file_id,AttributeType=S \
    --key-schema \
        AttributeName=execution_id,KeyType=HASH \
        AttributeName=file_id,KeyType=RANGE \
    --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5 \
    --global-secondary-indexes \
        "[{\"IndexName\": \"FileIdIndex\",
          \"KeySchema\": [{\"AttributeName\":\"file_id\",\"KeyType\":\"HASH\"}],
          \"Projection\": {\"ProjectionType\":\"ALL\"},
          \"ProvisionedThroughput\": {\"ReadCapacityUnits\":5,\"WriteCapacityUnits\":5}}]"

# Execution history table
awslocal dynamodb create-table \
    --table-name execution-history \
    --attribute-definitions \
        AttributeName=execution_id,AttributeType=S \
        AttributeName=timestamp,AttributeType=N \
    --key-schema \
        AttributeName=execution_id,KeyType=HASH \
        AttributeName=timestamp,KeyType=RANGE \
    --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5

echo "Creating IAM role for Lambda..."
awslocal iam create-role \
    --role-name lambda-execution-role \
    --assume-role-policy-document '{
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Principal": {"Service": "lambda.amazonaws.com"},
            "Action": "sts:AssumeRole"
        }]
    }'

awslocal iam attach-role-policy \
    --role-name lambda-execution-role \
    --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole

echo "Creating IAM role for Step Functions..."
awslocal iam create-role \
    --role-name stepfunctions-execution-role \
    --assume-role-policy-document '{
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Principal": {"Service": "states.amazonaws.com"},
            "Action": "sts:AssumeRole"
        }]
    }'

# Create Lambda functions (placeholders - will be updated by deployment script)
echo "Creating Lambda functions..."

# Chunker Lambda
cd /tmp
cat > chunker.py << 'EOF'
import json

def handler(event, context):
    print(f"Chunker received: {json.dumps(event)}")
    file_key = event.get('file_key', '')
    file_size = event.get('file_size', 0)
    chunk_size = event.get('chunk_size', 5242880)  # 5MB default
    
    num_chunks = max(1, (file_size + chunk_size - 1) // chunk_size)
    
    chunks = []
    for i in range(num_chunks):
        chunks.append({
            'chunk_id': f"{file_key}_chunk_{i}",
            'file_key': file_key,
            'chunk_index': i,
            'chunk_size': chunk_size,
            'offset': i * chunk_size,
            'total_chunks': num_chunks
        })
    
    return {
        'statusCode': 200,
        'chunks': chunks,
        'total_chunks': num_chunks,
        'file_key': file_key
    }
EOF

zip chunker.zip chunker.py

awslocal lambda create-function \
    --function-name document-chunker \
    --runtime python3.11 \
    --handler chunker.handler \
    --role arn:aws:iam::000000000000:role/lambda-execution-role \
    --zip-file fileb://chunker.zip \
    --timeout 300 \
    --memory-size 512

# Processor Lambda
cat > processor.py << 'EOF'
import json
import time
import random

def handler(event, context):
    print(f"Processor received: {json.dumps(event)}")
    
    chunk_id = event.get('chunk_id', 'unknown')
    file_key = event.get('file_key', 'unknown')
    chunk_index = event.get('chunk_index', 0)
    
    # Simulate processing time (10s to 600s)
    processing_time = random.randint(10, 60)  # Reduced for demo
    
    print(f"Processing {chunk_id} for {processing_time} seconds...")
    
    # Simulate streaming output
    results = []
    for i in range(5):
        time.sleep(processing_time / 5)
        results.append({
            'timestamp': time.time(),
            'chunk_id': chunk_id,
            'progress': (i + 1) * 20,
            'partial_result': f"Processed segment {i+1}/5 of {chunk_id}"
        })
    
    return {
        'statusCode': 200,
        'chunk_id': chunk_id,
        'file_key': file_key,
        'chunk_index': chunk_index,
        'results': results,
        'processing_time': processing_time,
        'entities_found': random.randint(5, 50),
        'summary': f"Processed {chunk_id} successfully"
    }
EOF

zip processor.zip processor.py

awslocal lambda create-function \
    --function-name document-processor \
    --runtime python3.11 \
    --handler processor.handler \
    --role arn:aws:iam::000000000000:role/lambda-execution-role \
    --zip-file fileb://processor.zip \
    --timeout 900 \
    --memory-size 1024

# Aggregator Lambda
cat > aggregator.py << 'EOF'
import json

def handler(event, context):
    print(f"Aggregator received: {json.dumps(event)}")
    
    # accept both dict input and list input (ASL may pass a list of results)
    if isinstance(event, list):
        results = event
        file_key = results[0].get('file_key', 'unknown') if results and isinstance(results[0], dict) else 'unknown'
    else:
        results = event.get('results', []) if isinstance(event, dict) else []
        file_key = event.get('file_key', 'unknown') if isinstance(event, dict) else 'unknown'
    
    total_entities = sum(r.get('entities_found', 0) for r in results if isinstance(r, dict))
    total_chunks = len(results)
    
    aggregated = {
        'file_key': file_key,
        'total_chunks': total_chunks,
        'total_entities': total_entities,
        'status': 'completed',
        'summaries': [r.get('summary', '') for r in results if isinstance(r, dict)]
    }
    
    return {
        'statusCode': 200,
        'file_key': file_key,
        'aggregated_results': aggregated
    }
EOF

zip aggregator.zip aggregator.py

awslocal lambda create-function \
    --function-name result-aggregator \
    --runtime python3.11 \
    --handler aggregator.handler \
    --role arn:aws:iam::000000000000:role/lambda-execution-role \
    --zip-file fileb://aggregator.zip \
    --timeout 300 \
    --memory-size 512

# Create Step Functions state machine
echo "Creating Step Functions state machine..."

cat > workflow.json << 'EOF'
{
  "Comment": "Document processing workflow with chunking and parallel processing",
  "StartAt": "ChunkFiles",
  "States": {
    "ChunkFiles": {
      "Type": "Map",
      "ItemsPath": "$.files",
      "MaxConcurrency": 10,
      "Iterator": {
        "StartAt": "ChunkFile",
        "States": {
          "ChunkFile": {
            "Type": "Task",
            "Resource": "arn:aws:lambda:us-east-1:000000000000:function:document-chunker",
            "ResultPath": "$.chunks_output",
            "Next": "ProcessChunks"
          },
          "ProcessChunks": {
            "Type": "Map",
            "ItemsPath": "$.chunks_output.chunks",
            "MaxConcurrency": 5,
            "Iterator": {
              "StartAt": "ProcessChunk",
              "States": {
                "ProcessChunk": {
                  "Type": "Task",
                  "Resource": "arn:aws:lambda:us-east-1:000000000000:function:document-processor",
                  "Retry": [
                    {
                      "ErrorEquals": ["States.TaskFailed", "States.Timeout"],
                      "IntervalSeconds": 2,
                      "MaxAttempts": 3,
                      "BackoffRate": 2.0
                    }
                  ],
                  "Catch": [
                    {
                      "ErrorEquals": ["States.ALL"],
                      "ResultPath": "$.error",
                      "Next": "HandleError"
                    }
                  ],
                  "End": true
                },
                "HandleError": {
                  "Type": "Pass",
                  "Result": {
                    "status": "failed",
                    "error": "Processing failed"
                  },
                  "End": true
                }
              }
            },
            "ResultPath": "$.chunk_results",
            "Next": "AggregateResults"
          },
          "AggregateResults": {
            "Type": "Task",
            "Resource": "arn:aws:lambda:us-east-1:000000000000:function:result-aggregator",
            "InputPath": "$.chunk_results",
            "ResultPath": "$.aggregated",
            "End": true
          }
        }
      },
      "ResultPath": "$.file_results",
      "End": true
    }
  }
}
EOF

awslocal stepfunctions create-state-machine \
    --name DocumentProcessingWorkflow \
    --definition file://workflow.json \
    --role-arn arn:aws:iam::000000000000:role/stepfunctions-execution-role

echo "Uploading sample files to S3..."
# Create some sample files
for i in {1..5}; do
    echo "Sample document content for file $i. This simulates a document that needs processing." > sample_$i.txt
    awslocal s3 cp sample_$i.txt s3://document-processing-bucket/sample_$i.txt
done

echo "LocalStack initialization complete!"
echo "Resources created:"
echo "  - S3 Buckets: document-processing-bucket, document-processing-results"
echo "  - DynamoDB Tables: document-processing-state, execution-history"
echo "  - Lambda Functions: document-chunker, document-processor, result-aggregator"
echo "  - Step Functions: DocumentProcessingWorkflow"