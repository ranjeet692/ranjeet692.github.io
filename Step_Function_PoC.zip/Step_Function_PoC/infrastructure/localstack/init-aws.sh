#!/bin/bash

echo "Initializing LocalStack resources..."

# Set endpoint
export AWS_ENDPOINT_URL=http://localhost:4566
export AWS_REGION=us-east-1
export AWS_ACCESS_KEY_ID=test
export AWS_SECRET_ACCESS_KEY=test

# Create S3 buckets
echo "Creating S3 buckets..."
awslocal s3 mb s3://document-processing-bucket
awslocal s3 mb s3://document-processing-results
awslocal s3 mb s3://document-chunks

# Create DynamoDB tables
echo "Creating DynamoDB tables..."

# State tracking table
awslocal dynamodb create-table \
    --table-name document-processing-state \
    --attribute-definitions \
        AttributeName=execution_id,AttributeType=S \
        AttributeName=file_id,AttributeType=S \
    --key-schema \
        AttributeName=execution_id,KeyType=HASH \
        AttributeName=file_id,KeyType=RANGE \
    --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5 \
    --global-secondary-indexes \
        "[{\"IndexName\": \"FileIdIndex\",
          \"KeySchema\": [{\"AttributeName\":\"file_id\",\"KeyType\":\"HASH\"}],
          \"Projection\": {\"ProjectionType\":\"ALL\"},
          \"ProvisionedThroughput\": {\"ReadCapacityUnits\":5,\"WriteCapacityUnits\":5}}]"

# Execution history table
awslocal dynamodb create-table \
    --table-name execution-history \
    --attribute-definitions \
        AttributeName=execution_id,AttributeType=S \
        AttributeName=timestamp,AttributeType=N \
    --key-schema \
        AttributeName=execution_id,KeyType=HASH \
        AttributeName=timestamp,KeyType=RANGE \
    --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5

echo "Creating IAM role for Lambda..."
awslocal iam create-role \
    --role-name lambda-execution-role \
    --assume-role-policy-document '{
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Principal": {"Service": "lambda.amazonaws.com"},
            "Action": "sts:AssumeRole"
        }]
    }'

awslocal iam attach-role-policy \
    --role-name lambda-execution-role \
    --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole

echo "Creating IAM policy for S3 access..."
awslocal iam create-policy \
    --policy-name lambda-s3-access-policy \
    --policy-document '{
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Action": [
                    "s3:GetObject",
                    "s3:PutObject",
                    "s3:DeleteObject",
                    "s3:ListBucket",
                    "s3:HeadObject"
                ],
                "Resource": [
                    "arn:aws:s3:::document-processing-bucket/*",
                    "arn:aws:s3:::document-processing-bucket",
                    "arn:aws:s3:::document-processing-results/*",
                    "arn:aws:s3:::document-processing-results",
                    "arn:aws:s3:::document-chunks/*",
                    "arn:aws:s3:::document-chunks"
                ]
            }
        ]
    }'

awslocal iam attach-role-policy \
    --role-name lambda-execution-role \
    --policy-arn arn:aws:iam::000000000000:policy/lambda-s3-access-policy

echo "Creating IAM role for Step Functions..."
awslocal iam create-role \
    --role-name stepfunctions-execution-role \
    --assume-role-policy-document '{
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Principal": {"Service": "states.amazonaws.com"},
            "Action": "sts:AssumeRole"
        }]
    }'

# Create Lambda functions
echo "Creating Lambda functions..."

# Set the base path for Lambda functions
# The backend is mounted at /opt/backend in the container
BACKEND_PATH="/opt/backend"

# Verify the path exists
if [ ! -d "${BACKEND_PATH}" ]; then
    echo "ERROR: Backend path ${BACKEND_PATH} does not exist!"
    exit 1
fi

echo "Using backend path: ${BACKEND_PATH}"

# Chunker Lambda - Splits files and saves chunks to S3
echo "Packaging chunker lambda..."
cd /tmp
rm -f chunker.zip
cp "${BACKEND_PATH}/lambdas/chunker/handler.py" ./chunker.py
zip chunker.zip chunker.py

awslocal lambda create-function \
    --function-name document-chunker \
    --runtime python3.11 \
    --handler chunker.handler \
    --role arn:aws:iam::000000000000:role/lambda-execution-role \
    --zip-file fileb://chunker.zip \
    --timeout 300 \
    --memory-size 512 \
    --environment Variables={AWS_ENDPOINT_URL=http://localstack:4566}

# Processor Lambda - Reads chunks from S3, calls API, and polls for completion
echo "Packaging processor lambda..."
rm -f processor.zip
rm -rf processor_pkg
mkdir -p processor_pkg

# Install dependencies if requirements.txt exists
if [ -f "${BACKEND_PATH}/lambdas/processor/requirements.txt" ]; then
    echo "Installing processor dependencies..."
    pip install -r "${BACKEND_PATH}/lambdas/processor/requirements.txt" -t processor_pkg/ -q
fi

# Copy handler
cp "${BACKEND_PATH}/lambdas/processor/handler.py" processor_pkg/processor.py

# Package everything
cd processor_pkg
zip -r ../processor.zip . -q
cd ..

awslocal lambda create-function \
    --function-name document-processor \
    --runtime python3.11 \
    --handler processor.handler \
    --role arn:aws:iam::000000000000:role/lambda-execution-role \
    --zip-file fileb://processor.zip \
    --timeout 900 \
    --memory-size 1024 \
    --environment Variables={AWS_ENDPOINT_URL=http://localstack:4566}

# Aggregator Lambda - Collects all chunk outputs
echo "Packaging aggregator lambda..."
rm -f aggregator.zip
cp "${BACKEND_PATH}/lambdas/aggregator/handler.py" ./aggregator.py
zip aggregator.zip aggregator.py

awslocal lambda create-function \
    --function-name result-aggregator \
    --runtime python3.11 \
    --handler aggregator.handler \
    --role arn:aws:iam::000000000000:role/lambda-execution-role \
    --zip-file fileb://aggregator.zip \
    --timeout 300 \
    --memory-size 512 \
    --environment Variables={AWS_ENDPOINT_URL=http://localstack:4566}

# Create Step Functions state machine
echo "Creating Step Functions state machine..."

# Copy workflow definition from backend
cp "${BACKEND_PATH}/stepfunctions/workflow.json" /tmp/workflow.json

awslocal stepfunctions create-state-machine \
    --name DocumentProcessingWorkflow \
    --definition file:///tmp/workflow.json \
    --role-arn arn:aws:iam::000000000000:role/stepfunctions-execution-role

echo "Uploading sample files to S3..."
# Create some sample files
for i in {1..5}; do
    echo "Sample document content for file $i. This simulates a document that needs processing." > sample_$i.txt
    awslocal s3 cp sample_$i.txt s3://document-processing-bucket/sample_$i.txt
done

echo "LocalStack initialization complete!"
echo "Resources created:"
echo "  - S3 Buckets: document-processing-bucket, document-processing-results, document-chunks"
echo "  - DynamoDB Tables: document-processing-state, execution-history"
echo "  - Lambda Functions: document-chunker, document-processor (with polling), result-aggregator"
echo "  - Step Functions: DocumentProcessingWorkflow"
echo ""
echo "To test, execute the workflow with:"
echo 'awslocal stepfunctions start-execution \'
echo '  --state-machine-arn arn:aws:states:us-east-1:000000000000:stateMachine:DocumentProcessingWorkflow \'
echo '  --input '"'"'{"files":[{"file_key":"sample_1.txt","source_bucket":"document-processing-bucket","chunk_size":1024}]}'"'"