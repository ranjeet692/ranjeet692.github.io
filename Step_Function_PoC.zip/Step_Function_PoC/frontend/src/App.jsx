import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import ExecutionsPage from './pages/ExecutionsPage';
import ExecutionDetailsPage from './pages/ExecutionDetailsPage';
import ExecutionMonitorPage from './pages/ExecutionMonitorPage';
import BatchUploadPage from './pages/BatchUploadPage';
import ComparisonPage from './pages/ComparisonPage';
import StateMachinesPage from './pages/StateMachinesPage';
import AnalyticsPage from './pages/AnalyticsPage';
import AdvancedSearchPage from './pages/AdvancedSearchPage';
import WorkflowTemplatesPage from './pages/WorkflowTemplatesPage';
import './App.css';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/batch-upload" element={<BatchUploadPage />} />
          <Route path="/executions" element={<ExecutionsPage />} />
          <Route path="/executions/:executionId" element={<ExecutionDetailsPage />} />
          <Route path="/executions/:executionArn/monitor" element={<ExecutionMonitorPage />} />
          <Route path="/comparison" element={<ComparisonPage />} />
          <Route path="/state-machines" element={<StateMachinesPage />} />
          <Route path="/analytics" element={<AnalyticsPage />} />
          <Route path="/search" element={<AdvancedSearchPage />} />
          <Route path="/templates" element={<WorkflowTemplatesPage />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;