import { useState, useEffect, useRef, useCallback } from 'react';

const WS_URL = process.env.REACT_APP_WS_URL || 'ws://localhost:8000';

export const useWebSocket = (executionId) => {
  const [messages, setMessages] = useState([]);
  const [status, setStatus] = useState('disconnected');
  const [progress, setProgress] = useState(null);
  const [streamData, setStreamData] = useState([]);
  const wsRef = useRef(null);
  const reconnectTimeoutRef = useRef(null);

  const connect = useCallback(() => {
    if (!executionId) return;

    try {
      const ws = new WebSocket(`${WS_URL}/ws/execution/${executionId}`);
      
      ws.onopen = () => {
        console.log('WebSocket connected');
        setStatus('connected');
      };

      ws.onmessage = (event) => {
        const message = JSON.parse(event.data);
        console.log('WebSocket message:', message);

        setMessages(prev => [...prev, message]);

        switch (message.type) {
          case 'status':
            setStatus(message.data.status);
            break;
          case 'progress':
            setProgress(message.data);
            break;
          case 'stream':
            setStreamData(prev => [...prev, message.data]);
            break;
          case 'complete':
            setStatus('completed');
            break;
          case 'error':
            console.error('WebSocket error:', message.data);
            break;
          case 'heartbeat':
          case 'pong':
            // Heartbeat received
            break;
          default:
            console.log('Unknown message type:', message.type);
        }
      };

      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        setStatus('error');
      };

      ws.onclose = () => {
        console.log('WebSocket disconnected');
        setStatus('disconnected');
        
        // Attempt to reconnect after 5 seconds
        reconnectTimeoutRef.current = setTimeout(() => {
          console.log('Attempting to reconnect...');
          connect();
        }, 5000);
      };

      wsRef.current = ws;
    } catch (error) {
      console.error('Failed to create WebSocket:', error);
      setStatus('error');
    }
  }, [executionId]);

  const disconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
    
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
  }, []);

  const sendMessage = useCallback((message) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(message));
    }
  }, []);

  useEffect(() => {
    connect();

    // Ping interval to keep connection alive
    const pingInterval = setInterval(() => {
      sendMessage({ type: 'ping' });
    }, 30000);

    return () => {
      clearInterval(pingInterval);
      disconnect();
    };
  }, [connect, disconnect, sendMessage]);

  return {
    messages,
    status,
    progress,
    streamData,
    sendMessage,
    reconnect: connect
  };
};