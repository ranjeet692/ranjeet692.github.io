import React, { useEffect, useState } from 'react';
import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const WorkflowGraph = ({ stateMachineArn }) => {
  const [definition, setDefinition] = useState(null);
  const [selectedState, setSelectedState] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadWorkflowDefinition();
  }, [stateMachineArn]);

  const loadWorkflowDefinition = async () => {
    try {
      setLoading(true);
      const response = await axios.get(
        `${API_URL}/api/workflows/state-machine/${encodeURIComponent(stateMachineArn)}`
      );
      const def = JSON.parse(response.data.definition);
      setDefinition(def);
    } catch (error) {
      console.error('Failed to load workflow definition:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="text-center py-8">Loading workflow...</div>;
  }

  if (!definition) {
    return <div className="text-center py-8 text-gray-500">No workflow definition available</div>;
  }

  const states = definition.States || {};
  const startAt = definition.StartAt;

  const getStateColor = (state) => {
    const type = state.Type;
    switch (type) {
      case 'Task': return 'bg-blue-100 border-blue-500';
      case 'Map': return 'bg-purple-100 border-purple-500';
      case 'Parallel': return 'bg-green-100 border-green-500';
      case 'Choice': return 'bg-yellow-100 border-yellow-500';
      case 'Wait': return 'bg-orange-100 border-orange-500';
      case 'Pass': return 'bg-gray-100 border-gray-500';
      case 'Succeed': return 'bg-green-200 border-green-600';
      case 'Fail': return 'bg-red-100 border-red-500';
      default: return 'bg-gray-100 border-gray-400';
    }
  };

  const getStateIcon = (type) => {
    switch (type) {
      case 'Task': return '⚙️';
      case 'Map': return '🔄';
      case 'Parallel': return '⚡';
      case 'Choice': return '🔀';
      case 'Wait': return '⏱️';
      case 'Pass': return '➡️';
      case 'Succeed': return '✅';
      case 'Fail': return '❌';
      default: return '🔹';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Workflow Visualization</h2>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Workflow Graph */}
        <div className="lg:col-span-2">
          <div className="bg-gray-50 rounded-lg p-6 min-h-96">
            <div className="space-y-4">
              {/* Start Node */}
              <div className="flex items-center justify-center">
                <div className="px-4 py-2 bg-green-500 text-white rounded-full font-medium">
                  START
                </div>
              </div>

              <div className="flex justify-center">
                <div className="w-0.5 h-8 bg-gray-400"></div>
              </div>

              {/* States */}
              {Object.entries(states).map(([stateName, state], index) => {
                const isStart = stateName === startAt;
                const isEnd = state.End === true;
                const nextState = state.Next;

                return (
                  <div key={stateName}>
                    <div className="flex flex-col items-center">
                      <button
                        onClick={() => setSelectedState({ name: stateName, ...state })}
                        className={`w-full max-w-md border-2 rounded-lg p-4 ${getStateColor(state)} hover:shadow-lg transition-all ${
                          selectedState?.name === stateName ? 'ring-2 ring-blue-500' : ''
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{getStateIcon(state.Type)}</span>
                          <div className="flex-1 text-left">
                            <div className="font-bold text-gray-900">{stateName}</div>
                            <div className="text-xs text-gray-600">{state.Type}</div>
                          </div>
                          {isStart && (
                            <span className="px-2 py-1 bg-green-500 text-white text-xs rounded-full">START</span>
                          )}
                          {isEnd && (
                            <span className="px-2 py-1 bg-red-500 text-white text-xs rounded-full">END</span>
                          )}
                        </div>
                      </button>

                      {/* Connection Line */}
                      {!isEnd && nextState && (
                        <div className="flex flex-col items-center my-2">
                          <div className="w-0.5 h-8 bg-gray-400"></div>
                          <div className="text-xs text-gray-500">↓ {nextState}</div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}

              {/* End Node */}
              <div className="flex items-center justify-center mt-4">
                <div className="px-4 py-2 bg-red-500 text-white rounded-full font-medium">
                  END
                </div>
              </div>
            </div>
          </div>

          {/* Legend */}
          <div className="mt-4 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-medium text-gray-900 mb-2">State Types</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
              {['Task', 'Map', 'Parallel', 'Choice', 'Wait', 'Pass', 'Succeed', 'Fail'].map(type => (
                <div key={type} className="flex items-center gap-2">
                  <span className="text-lg">{getStateIcon(type)}</span>
                  <span className="text-gray-700">{type}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* State Details Panel */}
        <div className="lg:col-span-1">
          <div className="bg-gray-50 rounded-lg p-4 sticky top-4">
            <h3 className="font-bold text-gray-900 mb-3">State Details</h3>
            {selectedState ? (
              <div className="space-y-3">
                <div>
                  <div className="text-xs text-gray-600 mb-1">Name</div>
                  <div className="font-medium text-gray-900">{selectedState.name}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-600 mb-1">Type</div>
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{getStateIcon(selectedState.Type)}</span>
                    <span className="font-medium text-gray-900">{selectedState.Type}</span>
                  </div>
                </div>

                {selectedState.Resource && (
                  <div>
                    <div className="text-xs text-gray-600 mb-1">Resource</div>
                    <div className="text-xs text-gray-900 break-all">{selectedState.Resource}</div>
                  </div>
                )}

                {selectedState.Next && (
                  <div>
                    <div className="text-xs text-gray-600 mb-1">Next State</div>
                    <div className="font-medium text-gray-900">{selectedState.Next}</div>
                  </div>
                )}

                {selectedState.End && (
                  <div className="px-2 py-1 bg-red-100 text-red-800 rounded text-xs text-center">
                    Terminal State
                  </div>
                )}

                {selectedState.Retry && (
                  <div>
                    <div className="text-xs text-gray-600 mb-1">Retry Policy</div>
                    <div className="text-xs text-gray-900">
                      Max Attempts: {selectedState.Retry[0]?.MaxAttempts || 'N/A'}
                    </div>
                  </div>
                )}

                {selectedState.Catch && (
                  <div>
                    <div className="text-xs text-gray-600 mb-1">Error Handling</div>
                    <div className="text-xs text-gray-900">
                      {selectedState.Catch.length} catch block(s)
                    </div>
                  </div>
                )}

                <div className="pt-3 border-t border-gray-300">
                  <details>
                    <summary className="text-xs text-gray-600 cursor-pointer hover:text-gray-900">
                      View Full Definition
                    </summary>
                    <pre className="mt-2 text-xs bg-white p-2 rounded overflow-auto max-h-60">
                      {JSON.stringify(selectedState, null, 2)}
                    </pre>
                  </details>
                </div>
              </div>
            ) : (
              <p className="text-sm text-gray-500">Click on a state to view details</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default WorkflowGraph;
