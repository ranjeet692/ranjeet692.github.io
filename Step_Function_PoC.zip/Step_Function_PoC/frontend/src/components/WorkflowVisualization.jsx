import React, { useState, useEffect, useRef } from 'react';

const WorkflowVisualization = ({ definition, executionHistory = null }) => {
  const [nodes, setNodes] = useState([]);
  const [edges, setEdges] = useState([]);
  const [selectedNode, setSelectedNode] = useState(null);
  const svgRef = useRef(null);

  useEffect(() => {
    if (definition && definition.States) {
      const { nodes: parsedNodes, edges: parsedEdges } = parseWorkflowDefinition(definition);
      setNodes(parsedNodes);
      setEdges(parsedEdges);
    }
  }, [definition]);

  const parseWorkflowDefinition = (def) => {
    const nodes = [];
    const edges = [];
    const states = def.States || {};
    const startAt = def.StartAt;

    // Calculate layout positions
    let yOffset = 50;
    const xCenter = 400;
    const nodeSpacing = 120;

    Object.entries(states).forEach(([stateName, stateConfig], index) => {
      const node = {
        id: stateName,
        type: stateConfig.Type,
        x: xCenter,
        y: yOffset + (index * nodeSpacing),
        config: stateConfig,
        isStart: stateName === startAt,
        isEnd: stateConfig.End === true,
        label: stateName
      };

      nodes.push(node);

      // Parse transitions
      if (stateConfig.Next) {
        edges.push({
          from: stateName,
          to: stateConfig.Next,
          label: 'Next',
          type: 'next'
        });
      }

      // Parse Choice state branches
      if (stateConfig.Type === 'Choice') {
        (stateConfig.Choices || []).forEach((choice, idx) => {
          edges.push({
            from: stateName,
            to: choice.Next,
            label: `Choice ${idx + 1}`,
            type: 'choice'
          });
        });
        if (stateConfig.Default) {
          edges.push({
            from: stateName,
            to: stateConfig.Default,
            label: 'Default',
            type: 'default'
          });
        }
      }

      // Parse Parallel state branches
      if (stateConfig.Type === 'Parallel') {
        (stateConfig.Branches || []).forEach((branch, idx) => {
          const branchStart = branch.StartAt;
          edges.push({
            from: stateName,
            to: branchStart,
            label: `Branch ${idx + 1}`,
            type: 'parallel'
          });
        });
        if (stateConfig.Next) {
          edges.push({
            from: stateName,
            to: stateConfig.Next,
            label: 'After Parallel',
            type: 'next'
          });
        }
      }

      // Parse Map state
      if (stateConfig.Type === 'Map') {
        if (stateConfig.Iterator && stateConfig.Iterator.StartAt) {
          edges.push({
            from: stateName,
            to: stateConfig.Iterator.StartAt,
            label: 'Iterator',
            type: 'iterator'
          });
        }
      }

      // Parse Catch handlers
      if (stateConfig.Catch) {
        stateConfig.Catch.forEach((catchHandler, idx) => {
          edges.push({
            from: stateName,
            to: catchHandler.Next,
            label: 'Catch',
            type: 'catch'
          });
        });
      }
    });

    return { nodes, edges };
  };

  const getNodeColor = (node) => {
    if (node.isStart) return '#10b981'; // Green
    if (node.isEnd) return '#ef4444'; // Red

    const typeColors = {
      'Task': '#3b82f6',      // Blue
      'Pass': '#8b5cf6',      // Purple
      'Choice': '#f59e0b',    // Orange
      'Parallel': '#06b6d4',  // Cyan
      'Map': '#14b8a6',       // Teal
      'Wait': '#6366f1',      // Indigo
      'Succeed': '#10b981',   // Green
      'Fail': '#ef4444'       // Red
    };

    return typeColors[node.type] || '#6b7280'; // Gray default
  };

  const getNodeIcon = (type) => {
    const icons = {
      'Task': '⚙️',
      'Pass': '➡️',
      'Choice': '🔀',
      'Parallel': '🔗',
      'Map': '🗺️',
      'Wait': '⏱️',
      'Succeed': '✅',
      'Fail': '❌'
    };
    return icons[type] || '⭕';
  };

  const getEdgeColor = (type) => {
    const colors = {
      'next': '#6b7280',
      'choice': '#f59e0b',
      'default': '#ef4444',
      'parallel': '#06b6d4',
      'iterator': '#14b8a6',
      'catch': '#ef4444'
    };
    return colors[type] || '#6b7280';
  };

  const handleNodeClick = (node) => {
    setSelectedNode(selectedNode?.id === node.id ? null : node);
  };

  const width = 800;
  const height = Math.max(600, nodes.length * 120 + 100);

  return (
    <div className="workflow-visualization">
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Workflow Diagram</h3>
          <div className="flex gap-2 text-xs">
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 rounded-full bg-green-500"></span>
              Start
            </span>
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 rounded-full bg-red-500"></span>
              End
            </span>
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 rounded-full bg-blue-500"></span>
              Task
            </span>
            <span className="flex items-center gap-1">
              <span className="w-3 h-3 rounded-full bg-orange-500"></span>
              Choice
            </span>
          </div>
        </div>

        <div className="overflow-auto border border-gray-200 rounded" style={{ maxHeight: '600px' }}>
          <svg
            ref={svgRef}
            width={width}
            height={height}
            className="bg-gray-50"
            style={{ minHeight: '400px' }}
          >
            <defs>
              <marker
                id="arrowhead"
                markerWidth="10"
                markerHeight="10"
                refX="9"
                refY="3"
                orient="auto"
              >
                <polygon points="0 0, 10 3, 0 6" fill="#6b7280" />
              </marker>
              <marker
                id="arrowhead-choice"
                markerWidth="10"
                markerHeight="10"
                refX="9"
                refY="3"
                orient="auto"
              >
                <polygon points="0 0, 10 3, 0 6" fill="#f59e0b" />
              </marker>
              <marker
                id="arrowhead-catch"
                markerWidth="10"
                markerHeight="10"
                refX="9"
                refY="3"
                orient="auto"
              >
                <polygon points="0 0, 10 3, 0 6" fill="#ef4444" />
              </marker>
            </defs>

            {/* Draw edges */}
            {edges.map((edge, idx) => {
              const fromNode = nodes.find(n => n.id === edge.from);
              const toNode = nodes.find(n => n.id === edge.to);

              if (!fromNode || !toNode) return null;

              const x1 = fromNode.x;
              const y1 = fromNode.y + 30;
              const x2 = toNode.x;
              const y2 = toNode.y - 10;

              const edgeColor = getEdgeColor(edge.type);
              const markerEnd = edge.type === 'catch' ? 'url(#arrowhead-catch)' :
                                edge.type === 'choice' ? 'url(#arrowhead-choice)' :
                                'url(#arrowhead)';

              return (
                <g key={`edge-${idx}`}>
                  <path
                    d={`M ${x1} ${y1} Q ${x1} ${(y1 + y2) / 2}, ${x2} ${y2}`}
                    fill="none"
                    stroke={edgeColor}
                    strokeWidth="2"
                    markerEnd={markerEnd}
                    opacity="0.6"
                  />
                  {edge.label && (
                    <text
                      x={(x1 + x2) / 2}
                      y={(y1 + y2) / 2}
                      fill={edgeColor}
                      fontSize="10"
                      fontWeight="500"
                      textAnchor="middle"
                    >
                      {edge.label}
                    </text>
                  )}
                </g>
              );
            })}

            {/* Draw nodes */}
            {nodes.map((node) => {
              const isSelected = selectedNode?.id === node.id;
              const nodeColor = getNodeColor(node);

              return (
                <g
                  key={node.id}
                  transform={`translate(${node.x}, ${node.y})`}
                  onClick={() => handleNodeClick(node)}
                  style={{ cursor: 'pointer' }}
                >
                  {/* Node background */}
                  <rect
                    x="-80"
                    y="-20"
                    width="160"
                    height="50"
                    rx="8"
                    fill={nodeColor}
                    opacity={isSelected ? '1' : '0.9'}
                    stroke={isSelected ? '#1f2937' : 'none'}
                    strokeWidth={isSelected ? '3' : '0'}
                  />

                  {/* Node icon and label */}
                  <text
                    x="-70"
                    y="5"
                    fill="white"
                    fontSize="20"
                  >
                    {getNodeIcon(node.type)}
                  </text>
                  <text
                    x="-45"
                    y="2"
                    fill="white"
                    fontSize="12"
                    fontWeight="600"
                  >
                    {node.label.length > 18 ? node.label.substring(0, 18) + '...' : node.label}
                  </text>
                  <text
                    x="-45"
                    y="15"
                    fill="white"
                    fontSize="9"
                    opacity="0.9"
                  >
                    {node.type}
                  </text>

                  {/* Start/End badges */}
                  {node.isStart && (
                    <circle cx="70" cy="-15" r="8" fill="#10b981" />
                  )}
                  {node.isEnd && (
                    <circle cx="70" cy="25" r="8" fill="#ef4444" />
                  )}
                </g>
              );
            })}
          </svg>
        </div>

        {/* Node details panel */}
        {selectedNode && (
          <div className="mt-4 p-4 bg-gray-50 rounded border border-gray-200">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-semibold text-gray-900">
                {getNodeIcon(selectedNode.type)} {selectedNode.label}
              </h4>
              <button
                onClick={() => setSelectedNode(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                ✕
              </button>
            </div>
            <div className="text-sm space-y-2">
              <div>
                <span className="font-medium text-gray-700">Type:</span>{' '}
                <span className="text-gray-600">{selectedNode.type}</span>
              </div>
              {selectedNode.config.Resource && (
                <div>
                  <span className="font-medium text-gray-700">Resource:</span>{' '}
                  <span className="text-xs text-gray-600 font-mono">
                    {selectedNode.config.Resource}
                  </span>
                </div>
              )}
              {selectedNode.config.Comment && (
                <div>
                  <span className="font-medium text-gray-700">Description:</span>{' '}
                  <span className="text-gray-600">{selectedNode.config.Comment}</span>
                </div>
              )}
              {selectedNode.config.TimeoutSeconds && (
                <div>
                  <span className="font-medium text-gray-700">Timeout:</span>{' '}
                  <span className="text-gray-600">{selectedNode.config.TimeoutSeconds}s</span>
                </div>
              )}
              {selectedNode.config.MaxConcurrency && (
                <div>
                  <span className="font-medium text-gray-700">Max Concurrency:</span>{' '}
                  <span className="text-gray-600">{selectedNode.config.MaxConcurrency}</span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default WorkflowVisualization;
