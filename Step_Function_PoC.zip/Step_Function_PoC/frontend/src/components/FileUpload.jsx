import React, { useState, useCallback } from 'react';
import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const FileUpload = ({ onUploadComplete, bucket = 'test-batch-processing', prefix = 'uploads' }) => {
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [uploadProgress, setUploadProgress] = useState({});

  // Handle file selection
  const handleFileSelect = (event) => {
    const selectedFiles = Array.from(event.target.files);
    addFiles(selectedFiles);
  };

  // Handle drag and drop
  const handleDrag = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const droppedFiles = Array.from(e.dataTransfer.files);
    addFiles(droppedFiles);
  }, []);

  const addFiles = (newFiles) => {
    const fileObjects = newFiles.map((file, index) => ({
      id: `${Date.now()}-${index}`,
      file,
      name: file.name,
      size: file.size,
      status: 'pending',
      progress: 0,
      error: null
    }));

    setFiles((prev) => [...prev, ...fileObjects]);
  };

  const removeFile = (fileId) => {
    setFiles((prev) => prev.filter((f) => f.id !== fileId));
    setUploadProgress((prev) => {
      const newProgress = { ...prev };
      delete newProgress[fileId];
      return newProgress;
    });
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  };

  // Upload a single file with multipart support for large files
  const uploadSingleFile = async (fileObj) => {
    const { file, id } = fileObj;
    const fileSize = file.size;
    const largeFileThreshold = 10 * 1024 * 1024; // 10MB

    try {
      // Update status
      setFiles((prev) =>
        prev.map((f) => (f.id === id ? { ...f, status: 'uploading' } : f))
      );

      if (fileSize > largeFileThreshold) {
        // Use multipart upload for large files
        await uploadLargeFile(fileObj);
      } else {
        // Use simple upload for small files
        await uploadSmallFile(fileObj);
      }

      // Mark as completed
      setFiles((prev) =>
        prev.map((f) => (f.id === id ? { ...f, status: 'completed', progress: 100 } : f))
      );

      setUploadProgress((prev) => ({ ...prev, [id]: 100 }));

    } catch (error) {
      console.error(`Error uploading ${file.name}:`, error);
      setFiles((prev) =>
        prev.map((f) =>
          f.id === id ? { ...f, status: 'error', error: error.message } : f
        )
      );
    }
  };

  // Small file upload (simple POST)
  const uploadSmallFile = async (fileObj) => {
    const { file, id } = fileObj;
    const formData = new FormData();
    formData.append('files', file);
    formData.append('bucket', bucket);
    formData.append('prefix', prefix);

    console.log(`Uploading file: ${file.name} to ${bucket}/${prefix}`);

    try {
      const response = await axios.post(`${API_URL}/api/workflows/files/upload/batch`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        },
        onUploadProgress: (progressEvent) => {
          const percentCompleted = Math.round(
            (progressEvent.loaded * 100) / progressEvent.total
          );
          setUploadProgress((prev) => ({ ...prev, [id]: percentCompleted }));
          setFiles((prev) =>
            prev.map((f) => (f.id === id ? { ...f, progress: percentCompleted } : f))
          );
        }
      });
      console.log(`Upload response for ${file.name}:`, response.data);
      return response.data;
    } catch (error) {
      console.error(`Upload error for ${file.name}:`, error.response?.data || error.message);
      throw error;
    }
  };

  // Large file multipart upload
  const uploadLargeFile = async (fileObj) => {
    const { file, id } = fileObj;
    const key = `${prefix}/${file.name}`;

    console.log(`Starting multipart upload for large file: ${file.name} (${file.size} bytes)`);

    try {
      // 1. Initiate multipart upload
      const formData = new FormData();
      formData.append('bucket', bucket);
      formData.append('key', key);
      formData.append('file_size', file.size);
      formData.append('content_type', file.type || 'application/octet-stream');

      const initResponse = await axios.post(
        `${API_URL}/api/workflows/files/upload/multipart/initiate`,
        formData
      );

      console.log(`Multipart upload initiated for ${file.name}:`, initResponse.data);

      const { upload_id, presigned_urls } = initResponse.data;

    // 2. Upload parts in parallel
    const uploadedParts = await Promise.all(
      presigned_urls.map(async (part) => {
        const chunk = file.slice(part.start_byte, part.end_byte + 1);

        const response = await fetch(part.url, {
          method: 'PUT',
          body: chunk,
          headers: {
            'Content-Type': file.type
          }
        });

        if (!response.ok) {
          throw new Error(`Failed to upload part ${part.part_number}`);
        }

        const etag = response.headers.get('ETag');

        // Update progress
        const progress = Math.round((part.part_number / presigned_urls.length) * 100);
        setUploadProgress((prev) => ({ ...prev, [id]: progress }));
        setFiles((prev) =>
          prev.map((f) => (f.id === id ? { ...f, progress } : f))
        );

        return {
          part_number: part.part_number,
          etag
        };
      })
    );

      // 3. Complete multipart upload
      const completeResponse = await axios.post(`${API_URL}/api/workflows/files/upload/multipart/complete`, {
        bucket,
        key,
        upload_id,
        parts: uploadedParts
      });

      console.log(`Multipart upload completed for ${file.name}:`, completeResponse.data);
      return completeResponse.data;
    } catch (error) {
      console.error(`Multipart upload error for ${file.name}:`, error.response?.data || error.message);
      throw error;
    }
  };

  // Upload all files
  const handleUploadAll = async () => {
    setUploading(true);

    const pendingFiles = files.filter((f) => f.status === 'pending');

    try {
      // Upload files sequentially (can be parallelized if needed)
      for (const fileObj of pendingFiles) {
        await uploadSingleFile(fileObj);
      }

      // Wait a moment for state to update
      await new Promise(resolve => setTimeout(resolve, 100));

      // Call completion callback with all completed files
      if (onUploadComplete) {
        setFiles((currentFiles) => {
          const uploadedFiles = currentFiles
            .filter((f) => f.status === 'completed')
            .map((f) => ({
              bucket,
              key: `${prefix}/${f.name}`,
              file_key: `${prefix}/${f.name}`,
              file_id: f.id,
              size: f.size,
              name: f.name
            }));

          onUploadComplete(uploadedFiles);
          return currentFiles;
        });
      }
    } finally {
      setUploading(false);
    }
  };

  const clearCompleted = () => {
    setFiles((prev) => prev.filter((f) => f.status !== 'completed'));
  };

  const pendingCount = files.filter((f) => f.status === 'pending').length;
  const uploadingCount = files.filter((f) => f.status === 'uploading').length;
  const completedCount = files.filter((f) => f.status === 'completed').length;
  const errorCount = files.filter((f) => f.status === 'error').length;

  return (
    <div className="file-upload-component">
      {/* Drag & Drop Zone */}
      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
          dragActive
            ? 'border-blue-500 bg-blue-50'
            : 'border-gray-300 hover:border-gray-400'
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <svg
          className="mx-auto h-12 w-12 text-gray-400"
          stroke="currentColor"
          fill="none"
          viewBox="0 0 48 48"
        >
          <path
            d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02"
            strokeWidth={2}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
        <div className="mt-4">
          <label
            htmlFor="file-upload"
            className="cursor-pointer rounded-md font-medium text-blue-600 hover:text-blue-500"
          >
            <span>Upload files</span>
            <input
              id="file-upload"
              name="file-upload"
              type="file"
              className="sr-only"
              multiple
              onChange={handleFileSelect}
            />
          </label>
          <p className="pl-1 inline">or drag and drop</p>
        </div>
        <p className="text-xs text-gray-500 mt-2">
          Any file type, up to 5TB per file
        </p>
      </div>

      {/* File List */}
      {files.length > 0 && (
        <div className="mt-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">
              Files ({files.length})
            </h3>
            <div className="flex gap-2">
              {completedCount > 0 && (
                <button
                  onClick={clearCompleted}
                  className="px-3 py-1 text-sm text-gray-600 hover:text-gray-800 bg-gray-100 rounded hover:bg-gray-200"
                >
                  Clear Completed
                </button>
              )}
              {pendingCount > 0 && (
                <button
                  onClick={handleUploadAll}
                  disabled={uploading}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                  {uploading ? 'Uploading...' : `Upload ${pendingCount} Files`}
                </button>
              )}
            </div>
          </div>

          {/* Stats */}
          <div className="flex gap-4 mb-4 text-sm">
            {pendingCount > 0 && (
              <span className="text-gray-600">
                ⏳ Pending: {pendingCount}
              </span>
            )}
            {uploadingCount > 0 && (
              <span className="text-blue-600">
                ⬆️ Uploading: {uploadingCount}
              </span>
            )}
            {completedCount > 0 && (
              <span className="text-green-600">
                ✅ Completed: {completedCount}
              </span>
            )}
            {errorCount > 0 && (
              <span className="text-red-600">
                ❌ Errors: {errorCount}
              </span>
            )}
          </div>

          {/* File Items */}
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {files.map((fileObj) => (
              <div
                key={fileObj.id}
                className="flex items-center justify-between p-3 bg-white border border-gray-200 rounded-lg"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-gray-900 truncate">
                      {fileObj.name}
                    </span>
                    <span className="text-xs text-gray-500">
                      {formatFileSize(fileObj.size)}
                    </span>
                  </div>

                  {/* Progress Bar */}
                  {fileObj.status === 'uploading' && (
                    <div className="mt-2">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-blue-600 h-2 rounded-full transition-all"
                            style={{ width: `${fileObj.progress}%` }}
                          />
                        </div>
                        <span className="text-xs text-gray-600">
                          {fileObj.progress}%
                        </span>
                      </div>
                    </div>
                  )}

                  {/* Error Message */}
                  {fileObj.status === 'error' && (
                    <p className="mt-1 text-xs text-red-600">{fileObj.error}</p>
                  )}
                </div>

                {/* Status & Actions */}
                <div className="flex items-center gap-2 ml-4">
                  {fileObj.status === 'pending' && (
                    <span className="text-gray-400">⏳</span>
                  )}
                  {fileObj.status === 'uploading' && (
                    <span className="text-blue-500 animate-spin">⬆️</span>
                  )}
                  {fileObj.status === 'completed' && (
                    <span className="text-green-500">✅</span>
                  )}
                  {fileObj.status === 'error' && (
                    <span className="text-red-500">❌</span>
                  )}

                  {(fileObj.status === 'pending' || fileObj.status === 'error') && (
                    <button
                      onClick={() => removeFile(fileObj.id)}
                      className="text-gray-400 hover:text-red-600"
                    >
                      ✕
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default FileUpload;
