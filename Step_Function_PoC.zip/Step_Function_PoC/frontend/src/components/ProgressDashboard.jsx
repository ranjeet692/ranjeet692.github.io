import React, { useState, useEffect, useRef } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const ProgressDashboard = ({ executionId }) => {
  const [progress, setProgress] = useState(null);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [progressHistory, setProgressHistory] = useState([]);
  const eventSourceRef = useRef(null);

  useEffect(() => {
    if (!executionId) return;

    // Initial fetch
    fetchProgress();

    // Connect to SSE stream for real-time updates
    connectToStream();

    // Cleanup
    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
    };
  }, [executionId]);

  const fetchProgress = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${API_URL}/api/workflows/progress/${executionId}`);

      if (!response.ok) {
        throw new Error(`Failed to fetch progress: ${response.statusText}`);
      }

      const data = await response.json();
      setProgress(data.progress);
      setEvents(data.recent_events || []);
      setError(null);

      // Add to history for chart
      addToHistory(data.progress);

    } catch (err) {
      console.error('Error fetching progress:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const connectToStream = () => {
    const eventSource = new EventSource(
      `${API_URL}/api/workflows/progress/${executionId}/stream`
    );

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);

        if (data.type === 'progress') {
          setProgress(data.data);
          addToHistory(data.data);
        } else if (data.type === 'completed') {
          console.log('Execution completed:', data.status);
          eventSource.close();
        } else if (data.type === 'error') {
          setError(data.message);
          eventSource.close();
        }
      } catch (err) {
        console.error('Error parsing SSE message:', err);
      }
    };

    eventSource.onerror = (err) => {
      console.error('SSE error:', err);
      eventSource.close();

      // Retry connection after 5 seconds
      setTimeout(() => {
        if (progress?.status === 'RUNNING') {
          connectToStream();
        }
      }, 5000);
    };

    eventSourceRef.current = eventSource;
  };

  const addToHistory = (progressData) => {
    const timestamp = new Date().toLocaleTimeString();
    setProgressHistory((prev) => [
      ...prev.slice(-20), // Keep last 20 data points
      {
        time: timestamp,
        progress: progressData.progress_percentage || 0,
        completed: progressData.completed_items || 0,
        failed: progressData.failed_items || 0
      }
    ]);
  };

  const formatDuration = (start, end) => {
    const startTime = new Date(start);
    const endTime = end ? new Date(end) : new Date();
    const duration = Math.floor((endTime - startTime) / 1000); // seconds

    const hours = Math.floor(duration / 3600);
    const minutes = Math.floor((duration % 3600) / 60);
    const seconds = duration % 60;

    if (hours > 0) {
      return `${hours}h ${minutes}m ${seconds}s`;
    } else if (minutes > 0) {
      return `${minutes}m ${seconds}s`;
    } else {
      return `${seconds}s`;
    }
  };

  const formatETA = (eta) => {
    if (!eta) return 'Calculating...';

    const etaTime = new Date(eta);
    const now = new Date();
    const diff = Math.floor((etaTime - now) / 1000); // seconds

    if (diff < 0) return 'Soon';

    const hours = Math.floor(diff / 3600);
    const minutes = Math.floor((diff % 3600) / 60);
    const seconds = diff % 60;

    if (hours > 0) {
      return `~${hours}h ${minutes}m`;
    } else if (minutes > 0) {
      return `~${minutes}m ${seconds}s`;
    } else {
      return `~${seconds}s`;
    }
  };

  if (loading && !progress) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error && !progress) {
    return (
      <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
        <p className="text-red-800">Error: {error}</p>
        <button
          onClick={fetchProgress}
          className="mt-2 px-4 py-2 text-sm bg-red-600 text-white rounded hover:bg-red-700"
        >
          Retry
        </button>
      </div>
    );
  }

  if (!progress) {
    return (
      <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
        <p className="text-gray-600">No progress data available</p>
      </div>
    );
  }

  const statusColors = {
    RUNNING: 'bg-blue-100 text-blue-800',
    SUCCEEDED: 'bg-green-100 text-green-800',
    FAILED: 'bg-red-100 text-red-800',
    TIMED_OUT: 'bg-yellow-100 text-yellow-800',
    ABORTED: 'bg-gray-100 text-gray-800'
  };

  return (
    <div className="progress-dashboard space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Execution Progress</h2>
        <span className={`px-3 py-1 rounded-full text-sm font-medium ${statusColors[progress.status] || 'bg-gray-100 text-gray-800'}`}>
          {progress.status}
        </span>
      </div>

      {/* Progress Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Progress Percentage */}
        <div className="bg-white p-6 rounded-lg shadow border border-gray-200">
          <div className="flex flex-col">
            <span className="text-sm font-medium text-gray-600">Progress</span>
            <span className="text-3xl font-bold text-blue-600 mt-2">
              {progress.progress_percentage?.toFixed(1) || 0}%
            </span>
            <div className="mt-3 bg-gray-200 rounded-full h-2">
              <div
                className="bg-blue-600 h-2 rounded-full transition-all duration-500"
                style={{ width: `${progress.progress_percentage || 0}%` }}
              />
            </div>
          </div>
        </div>

        {/* Items Processed */}
        <div className="bg-white p-6 rounded-lg shadow border border-gray-200">
          <div className="flex flex-col">
            <span className="text-sm font-medium text-gray-600">Completed</span>
            <span className="text-3xl font-bold text-green-600 mt-2">
              {progress.completed_items || 0}
            </span>
            <span className="text-sm text-gray-500 mt-1">
              of {progress.total_items || 0} items
            </span>
          </div>
        </div>

        {/* Failed Items */}
        <div className="bg-white p-6 rounded-lg shadow border border-gray-200">
          <div className="flex flex-col">
            <span className="text-sm font-medium text-gray-600">Failed</span>
            <span className="text-3xl font-bold text-red-600 mt-2">
              {progress.failed_items || 0}
            </span>
            <span className="text-sm text-gray-500 mt-1">
              {progress.total_items > 0
                ? `${((progress.failed_items / progress.total_items) * 100).toFixed(1)}% failure rate`
                : '0% failure rate'}
            </span>
          </div>
        </div>

        {/* Performance */}
        <div className="bg-white p-6 rounded-lg shadow border border-gray-200">
          <div className="flex flex-col">
            <span className="text-sm font-medium text-gray-600">Speed</span>
            <span className="text-3xl font-bold text-purple-600 mt-2">
              {progress.items_per_second?.toFixed(1) || 0}
            </span>
            <span className="text-sm text-gray-500 mt-1">items/second</span>
          </div>
        </div>
      </div>

      {/* Timeline & ETA */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
          <span className="text-sm font-medium text-gray-600">Duration</span>
          <p className="text-lg font-semibold text-gray-900 mt-1">
            {formatDuration(progress.start_time, progress.end_time)}
          </p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
          <span className="text-sm font-medium text-gray-600">Estimated Completion</span>
          <p className="text-lg font-semibold text-gray-900 mt-1">
            {progress.status === 'RUNNING'
              ? formatETA(progress.estimated_completion_time)
              : 'Completed'}
          </p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
          <span className="text-sm font-medium text-gray-600">Current State</span>
          <p className="text-lg font-semibold text-gray-900 mt-1 truncate">
            {progress.current_state || 'Initializing'}
          </p>
        </div>
      </div>

      {/* Progress Chart */}
      {progressHistory.length > 1 && (
        <div className="bg-white p-6 rounded-lg shadow border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Progress Over Time</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={progressHistory}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="time" />
              <YAxis yAxisId="left" label={{ value: 'Items', angle: -90, position: 'insideLeft' }} />
              <YAxis yAxisId="right" orientation="right" label={{ value: 'Progress %', angle: 90, position: 'insideRight' }} />
              <Tooltip />
              <Legend />
              <Line yAxisId="left" type="monotone" dataKey="completed" stroke="#10b981" name="Completed" />
              <Line yAxisId="left" type="monotone" dataKey="failed" stroke="#ef4444" name="Failed" />
              <Line yAxisId="right" type="monotone" dataKey="progress" stroke="#3b82f6" name="Progress %" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Recent Events */}
      {events.length > 0 && (
        <div className="bg-white p-6 rounded-lg shadow border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Events</h3>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {events.map((event, index) => (
              <div
                key={index}
                className="flex items-start gap-3 p-3 bg-gray-50 rounded border border-gray-200"
              >
                <span className="text-2xl">
                  {event.event_type === 'file_completed' ? '✅' :
                   event.event_type === 'file_failed' ? '❌' :
                   event.event_type === 'execution_started' ? '🚀' :
                   event.event_type === 'execution_completed' ? '🎉' :
                   '📝'}
                </span>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-gray-900">
                      {event.event_type.replace(/_/g, ' ').toUpperCase()}
                    </span>
                    {event.file_id && (
                      <span className="text-xs text-gray-500">
                        {event.file_id}
                      </span>
                    )}
                  </div>
                  {event.message && (
                    <p className="text-sm text-gray-600 mt-1">{event.message}</p>
                  )}
                  <span className="text-xs text-gray-400">
                    {new Date(event.timestamp).toLocaleString()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* File Lists */}
      {(progress.files_processed?.length > 0 || progress.files_failed?.length > 0) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Processed Files */}
          {progress.files_processed?.length > 0 && (
            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h4 className="font-semibold text-gray-900 mb-2">
                ✅ Processed Files ({progress.files_processed.length})
              </h4>
              <div className="max-h-32 overflow-y-auto space-y-1">
                {progress.files_processed.slice(0, 10).map((fileId, index) => (
                  <div key={index} className="text-sm text-gray-600">
                    {fileId}
                  </div>
                ))}
                {progress.files_processed.length > 10 && (
                  <div className="text-sm text-gray-400 italic">
                    +{progress.files_processed.length - 10} more
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Failed Files */}
          {progress.files_failed?.length > 0 && (
            <div className="bg-white p-4 rounded-lg shadow border border-red-200">
              <h4 className="font-semibold text-red-900 mb-2">
                ❌ Failed Files ({progress.files_failed.length})
              </h4>
              <div className="max-h-32 overflow-y-auto space-y-1">
                {progress.files_failed.map((fileId, index) => (
                  <div key={index} className="text-sm text-red-600">
                    {fileId}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ProgressDashboard;
