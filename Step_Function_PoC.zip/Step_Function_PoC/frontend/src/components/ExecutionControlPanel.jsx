import React, { useState } from 'react';
import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const ExecutionControlPanel = ({ executionArn, executionId, status, onActionComplete }) => {
  const [loading, setLoading] = useState(false);
  const [showStopDialog, setShowStopDialog] = useState(false);
  const [showResumeDialog, setShowResumeDialog] = useState(false);
  const [showParametersDialog, setShowParametersDialog] = useState(false);
  const [stopReason, setStopReason] = useState('');
  const [checkpointData, setCheckpointData] = useState('{}');
  const [parameters, setParameters] = useState('{}');
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  const handleStop = async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await axios.post(
        `${API_URL}/api/workflows/executions/${encodeURIComponent(executionArn)}/stop`,
        { reason: stopReason || 'Stopped by user' }
      );

      setSuccess('Execution stopped successfully');
      setShowStopDialog(false);
      setStopReason('');

      if (onActionComplete) {
        onActionComplete('stopped', response.data);
      }
    } catch (err) {
      setError(err.response?.data?.detail || err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleResume = async () => {
    try {
      setLoading(true);
      setError(null);

      const checkpoint = checkpointData ? JSON.parse(checkpointData) : null;

      const response = await axios.post(
        `${API_URL}/api/workflows/executions/${encodeURIComponent(executionArn)}/resume`,
        { checkpoint_data: checkpoint }
      );

      setSuccess(`Execution resumed. New execution ID: ${response.data.new_execution_id}`);
      setShowResumeDialog(false);
      setCheckpointData('{}');

      if (onActionComplete) {
        onActionComplete('resumed', response.data);
      }
    } catch (err) {
      setError(err.response?.data?.detail || err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateParameters = async () => {
    try {
      setLoading(true);
      setError(null);

      const params = JSON.parse(parameters);

      const response = await axios.put(
        `${API_URL}/api/workflows/executions/${encodeURIComponent(executionArn)}/parameters`,
        params
      );

      setSuccess('Parameters updated successfully');
      setShowParametersDialog(false);

      if (onActionComplete) {
        onActionComplete('parameters_updated', response.data);
      }
    } catch (err) {
      setError(err.response?.data?.detail || err.message);
    } finally {
      setLoading(false);
    }
  };

  const isRunning = status === 'RUNNING';
  const isStopped = status === 'ABORTED' || status === 'FAILED' || status === 'TIMED_OUT';

  return (
    <div className="execution-control-panel">
      {/* Control Buttons */}
      <div className="flex flex-wrap gap-3">
        {/* Stop Button */}
        {isRunning && (
          <button
            onClick={() => setShowStopDialog(true)}
            className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-colors"
          >
            <span className="flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 10a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z" />
              </svg>
              Stop Execution
            </span>
          </button>
        )}

        {/* Resume Button */}
        {isStopped && (
          <button
            onClick={() => setShowResumeDialog(true)}
            className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors"
          >
            <span className="flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Resume from Checkpoint
            </span>
          </button>
        )}

        {/* Update Parameters Button */}
        {isRunning && (
          <button
            onClick={() => setShowParametersDialog(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
          >
            <span className="flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
              </svg>
              Update Parameters
            </span>
          </button>
        )}
      </div>

      {/* Success/Error Messages */}
      {success && (
        <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
          <p className="text-green-800">{success}</p>
          <button
            onClick={() => setSuccess(null)}
            className="mt-2 text-sm text-green-600 hover:text-green-800"
          >
            Dismiss
          </button>
        </div>
      )}

      {error && (
        <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-800">{error}</p>
          <button
            onClick={() => setError(null)}
            className="mt-2 text-sm text-red-600 hover:text-red-800"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Stop Dialog */}
      {showStopDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Stop Execution</h3>
            <p className="text-sm text-gray-600 mb-4">
              Are you sure you want to stop this execution? This action cannot be undone.
            </p>

            <label className="block text-sm font-medium text-gray-700 mb-2">
              Reason (optional)
            </label>
            <textarea
              value={stopReason}
              onChange={(e) => setStopReason(e.target.value)}
              placeholder="Enter reason for stopping..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
              rows={3}
            />

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowStopDialog(false)}
                className="flex-1 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
                disabled={loading}
              >
                Cancel
              </button>
              <button
                onClick={handleStop}
                className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:bg-gray-400"
                disabled={loading}
              >
                {loading ? 'Stopping...' : 'Stop Execution'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Resume Dialog */}
      {showResumeDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Resume Execution</h3>
            <p className="text-sm text-gray-600 mb-4">
              This will create a new execution with checkpoint data. The original execution will remain stopped.
            </p>

            <label className="block text-sm font-medium text-gray-700 mb-2">
              Checkpoint Data (JSON)
            </label>
            <textarea
              value={checkpointData}
              onChange={(e) => setCheckpointData(e.target.value)}
              placeholder='{"processed_files": ["FILE-001"], "resume_from_index": 1}'
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 font-mono text-sm"
              rows={5}
            />

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowResumeDialog(false)}
                className="flex-1 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
                disabled={loading}
              >
                Cancel
              </button>
              <button
                onClick={handleResume}
                className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-400"
                disabled={loading}
              >
                {loading ? 'Resuming...' : 'Resume'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Update Parameters Dialog */}
      {showParametersDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Update Parameters</h3>
            <p className="text-sm text-gray-600 mb-4">
              Parameters are stored in DynamoDB. The workflow must poll for updates.
            </p>

            <label className="block text-sm font-medium text-gray-700 mb-2">
              Parameters (JSON)
            </label>
            <textarea
              value={parameters}
              onChange={(e) => setParameters(e.target.value)}
              placeholder='{"max_concurrency": 5, "enable_debug": true}'
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono text-sm"
              rows={5}
            />

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowParametersDialog(false)}
                className="flex-1 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
                disabled={loading}
              >
                Cancel
              </button>
              <button
                onClick={handleUpdateParameters}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400"
                disabled={loading}
              >
                {loading ? 'Updating...' : 'Update'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExecutionControlPanel;
