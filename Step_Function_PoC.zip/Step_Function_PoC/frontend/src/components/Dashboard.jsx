import React, { useState, useEffect } from 'react';
import { Play, Pause, Square, RefreshCw, AlertCircle, CheckCircle, Clock } from 'lucide-react';
import { useWebSocket } from '../hooks/useWebSocket';
import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const Dashboard = () => {
  const [executions, setExecutions] = useState([]);
  const [selectedExecution, setSelectedExecution] = useState(null);
  const [files, setFiles] = useState([]);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [metrics, setMetrics] = useState(null);
  const [expandedFiles, setExpandedFiles] = useState(new Set());

  const { messages, status: wsStatus, progress } = useWebSocket(selectedExecution?.execution_id);

  const toggleFileExpansion = (fileId) => {
    setExpandedFiles(prev => {
      const newSet = new Set(prev);
      if (newSet.has(fileId)) {
        newSet.delete(fileId);
      } else {
        newSet.add(fileId);
      }
      return newSet;
    });
  };

  useEffect(() => {
    loadFiles();
    loadExecutions();
    loadMetrics();
    
    const interval = setInterval(() => {
      loadExecutions();
      loadMetrics();
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const loadFiles = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/workflows/files`);
      setFiles(response.data.files);
    } catch (error) {
      console.error('Failed to load files:', error);
    }
  };

  const loadExecutions = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/workflows/list`);
      setExecutions(response.data.executions);
    } catch (error) {
      console.error('Failed to load executions:', error);
    }
  };

  const loadMetrics = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/workflows/metrics`);
      setMetrics(response.data);
    } catch (error) {
      console.error('Failed to load metrics:', error);
    }
  };

  const startWorkflow = async () => {
    if (selectedFiles.length === 0) {
      alert('Please select files to process');
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post(`${API_URL}/api/workflows/start`, {
        files: selectedFiles,
        max_concurrency: 10,
        chunk_size_mb: 5
      });

      setSelectedExecution(response.data);
      await loadExecutions();
    } catch (error) {
      console.error('Failed to start workflow:', error);
      alert('Failed to start workflow');
    } finally {
      setLoading(false);
    }
  };

  const stopWorkflow = async (executionArn) => {
    try {
      await axios.post(`${API_URL}/api/workflows/stop`, {
        execution_arn: executionArn
      });
      await loadExecutions();
    } catch (error) {
      console.error('Failed to stop workflow:', error);
    }
  };

  const toggleFileSelection = (file) => {
    setSelectedFiles(prev => {
      const exists = prev.find(f => f.file_key === file.file_key);
      if (exists) {
        return prev.filter(f => f.file_key !== file.file_key);
      } else {
        return [...prev, file];
      }
    });
  };

  const getStatusIcon = (status) => {
    switch (status?.toUpperCase()) {
      case 'RUNNING':
        return <Clock className="text-blue-500" size={20} />;
      case 'SUCCEEDED':
        return <CheckCircle className="text-green-500" size={20} />;
      case 'FAILED':
      case 'TIMED_OUT':
      case 'ABORTED':
        return <AlertCircle className="text-red-500" size={20} />;
      default:
        return <Clock className="text-gray-500" size={20} />;
    }
  };

  const getStatusColor = (status) => {
    switch (status?.toUpperCase()) {
      case 'RUNNING':
        return 'bg-blue-100 text-blue-800';
      case 'SUCCEEDED':
        return 'bg-green-100 text-green-800';
      case 'FAILED':
      case 'TIMED_OUT':
      case 'ABORTED':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            LLM Document Processing Orchestration
          </h1>
          <p className="text-gray-600">
            FastAPI + AWS Step Functions PoC
          </p>
        </div>

        {/* Metrics Dashboard */}
        {metrics && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="text-sm text-gray-600 mb-1">Total Executions</div>
              <div className="text-3xl font-bold text-gray-900">{metrics.total_executions}</div>
            </div>
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="text-sm text-gray-600 mb-1">Running</div>
              <div className="text-3xl font-bold text-blue-600">{metrics.running_executions}</div>
            </div>
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="text-sm text-gray-600 mb-1">Completed</div>
              <div className="text-3xl font-bold text-green-600">{metrics.completed_executions}</div>
            </div>
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="text-sm text-gray-600 mb-1">Success Rate</div>
              <div className="text-3xl font-bold text-purple-600">{metrics.success_rate.toFixed(1)}%</div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* File Selection */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-900">Select Files</h2>
              <button
                onClick={loadFiles}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <RefreshCw size={20} />
              </button>
            </div>

            <div className="space-y-2 max-h-96 overflow-y-auto">
              {files.map(file => (
                <div
                  key={file.file_key}
                  onClick={() => toggleFileSelection(file)}
                  className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                    selectedFiles.find(f => f.file_key === file.file_key)
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">{file.file_key}</div>
                      <div className="text-sm text-gray-500">
                        {(file.file_size / 1024 / 1024).toFixed(2)} MB
                      </div>
                    </div>
                    {selectedFiles.find(f => f.file_key === file.file_key) && (
                      <CheckCircle className="text-blue-500" size={20} />
                    )}
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={startWorkflow}
              disabled={loading || selectedFiles.length === 0}
              className="w-full mt-4 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white font-medium py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              <Play size={20} />
              {loading ? 'Starting...' : `Start Processing (${selectedFiles.length} files)`}
            </button>
          </div>

          {/* Execution List */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-900">Executions</h2>
              <button
                onClick={loadExecutions}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <RefreshCw size={20} />
              </button>
            </div>

            <div className="space-y-2 max-h-96 overflow-y-auto">
              {executions.map(execution => (
                <div
                  key={execution.execution_id}
                  onClick={() => setSelectedExecution(execution)}
                  className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                    selectedExecution?.execution_id === execution.execution_id
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(execution.status)}
                      <span className="font-medium text-gray-900">
                        {execution.execution_id}
                      </span>
                    </div>
                    <span className={`px-2 py-1 rounded text-xs font-medium ${getStatusColor(execution.status)}`}>
                      {execution.status}
                    </span>
                  </div>
                  
                  <div className="text-sm text-gray-600">
                    Started: {new Date(execution.start_time).toLocaleString()}
                  </div>

                  {execution.status === 'RUNNING' && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        stopWorkflow(execution.execution_arn);
                      }}
                      className="mt-2 px-3 py-1 bg-red-600 hover:bg-red-700 text-white text-sm rounded transition-colors flex items-center gap-1"
                    >
                      <Square size={14} />
                      Stop
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Progress Monitor */}
        {selectedExecution && (
          <div className="bg-white rounded-lg shadow-sm p-6 mt-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              Execution Progress: {selectedExecution.execution_id}
            </h2>

            {progress ? (
              <>
                <div className="mb-6">
                  <div className="flex justify-between text-sm text-gray-600 mb-2">
                    <span>Overall Progress</span>
                    <span>{progress.overall_progress?.toFixed(1)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-4">
                    <div
                      className="bg-blue-600 h-4 rounded-full transition-all duration-300"
                      style={{ width: `${progress.overall_progress || 0}%` }}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-4 gap-4 mb-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">{progress.total_files || 0}</div>
                    <div className="text-sm text-gray-600">Total Files</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{progress.completed_files || 0}</div>
                    <div className="text-sm text-gray-600">Completed</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">{progress.processing_files || 0}</div>
                    <div className="text-sm text-gray-600">Processing</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-red-600">{progress.failed_files || 0}</div>
                    <div className="text-sm text-gray-600">Failed</div>
                  </div>
                </div>
              </>
            ) : (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                <p className="text-gray-600">Connecting to execution monitor...</p>
              </div>
            )}

            {/* File-Level Progress */}
            {progress && progress.files && progress.files.length > 0 && (
              <div className="space-y-4 mb-6">
                <h3 className="text-lg font-medium text-gray-900">File Processing Details</h3>
                {progress.files.map(file => (
                  <div key={file.file_id} className="border border-gray-200 rounded-lg overflow-hidden">
                    <div
                      className="p-4 cursor-pointer hover:bg-gray-50 transition-colors"
                      onClick={() => toggleFileExpansion(file.file_id)}
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          {getStatusIcon(file.status)}
                          <span className="font-medium text-gray-900">{file.file_id}</span>
                          <span className="text-xs text-gray-500">
                            {expandedFiles.has(file.file_id) ? '▼' : '▶'}
                          </span>
                        </div>
                        <span className={`px-2 py-1 rounded text-xs font-medium ${getStatusColor(file.status)}`}>
                          {file.status}
                        </span>
                      </div>

                      {/* Chunk Progress Bar */}
                      <div className="mb-3">
                        <div className="flex justify-between text-xs text-gray-600 mb-1">
                          <span>Chunks Progress</span>
                          <span>{file.completed_chunks}/{file.total_chunks} chunks</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full transition-all duration-300 ${
                              file.status === 'completed' ? 'bg-green-600' :
                              file.status === 'failed' ? 'bg-red-600' : 'bg-blue-600'
                            }`}
                            style={{ width: `${file.total_chunks > 0 ? (file.completed_chunks / file.total_chunks * 100) : 0}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Expandable Details Section */}
                    {expandedFiles.has(file.file_id) && (
                      <div className="border-t border-gray-200 p-4 bg-gray-50">
                        <h4 className="font-medium text-gray-900 mb-3">Processing Details</h4>

                        {/* Latest Chunk Activity */}
                        {file.chunks && file.chunks.length > 0 && (
                          <div className="space-y-2">
                            {file.chunks.slice(-3).reverse().map((chunk, idx) => (
                              <div key={idx} className="bg-white rounded p-3 text-sm shadow-sm">
                                <div className="flex items-center justify-between mb-2">
                                  <span className="font-medium text-gray-700">{chunk.chunk_id}</span>
                                  <span className={`px-2 py-0.5 rounded text-xs ${
                                    chunk.status === 'completed' ? 'bg-green-100 text-green-800' :
                                    chunk.status === 'failed' ? 'bg-red-100 text-red-800' :
                                    chunk.status === 'polling' ? 'bg-yellow-100 text-yellow-800' :
                                    'bg-blue-100 text-blue-800'
                                  }`}>
                                    {chunk.status}
                                  </span>
                                </div>

                                <div className="text-xs text-gray-600 mb-2">{chunk.message}</div>

                                {chunk.poll_attempt && chunk.poll_max_attempts && (
                                  <div className="mt-2 mb-2">
                                    <div className="flex justify-between text-xs text-gray-500 mb-1">
                                      <span>Polling Progress</span>
                                      <span>{chunk.poll_attempt}/{chunk.poll_max_attempts}</span>
                                    </div>
                                    <div className="w-full bg-gray-200 rounded-full h-1">
                                      <div
                                        className="bg-yellow-500 h-1 rounded-full"
                                        style={{ width: `${chunk.poll_progress || 0}%` }}
                                      />
                                    </div>
                                  </div>
                                )}

                                {chunk.job_id && (
                                  <div className="text-xs text-gray-500 mb-2">Job ID: {chunk.job_id}</div>
                                )}

                                {/* Output Data */}
                                {chunk.output_data && (
                                  <div className="mt-3 pt-3 border-t border-gray-200">
                                    <div className="text-xs font-medium text-gray-700 mb-2">Output Data:</div>
                                    <div className="bg-gray-100 rounded p-2 max-h-96 overflow-auto">
                                      <pre className="text-xs text-gray-800 whitespace-pre-wrap">
                                        {typeof chunk.output_data === 'string'
                                          ? chunk.output_data
                                          : JSON.stringify(JSON.parse(chunk.output_data), null, 2)
                                        }
                                      </pre>
                                    </div>
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* WebSocket Status */}
            <div className="mt-4 p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">WebSocket Status:</span>
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  wsStatus === 'connected' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                }`}>
                  {wsStatus}
                </span>
              </div>
              <div className="text-sm text-gray-600 mt-2">
                Messages received: {messages.length}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;