import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import ProgressDashboard from '../components/ProgressDashboard';
import ExecutionControlPanel from '../components/ExecutionControlPanel';
import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const ExecutionMonitorPage = () => {
  const { executionArn } = useParams();
  const navigate = useNavigate();
  const [execution, setExecution] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('progress');

  useEffect(() => {
    if (executionArn) {
      fetchExecutionDetails();
    }
  }, [executionArn]);

  const fetchExecutionDetails = async () => {
    try {
      setLoading(true);
      const response = await axios.get(
        `${API_URL}/api/workflows/status/${encodeURIComponent(executionArn)}`
      );
      setExecution(response.data);
      setError(null);
    } catch (err) {
      setError(err.response?.data?.detail || err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleActionComplete = (action, data) => {
    console.log(`Action ${action} completed:`, data);

    // Refresh execution details
    fetchExecutionDetails();

    // If resumed, navigate to new execution
    if (action === 'resumed' && data.new_execution_arn) {
      setTimeout(() => {
        navigate(`/executions/${encodeURIComponent(data.new_execution_arn)}/monitor`);
      }, 2000);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading execution details...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6">
          <h2 className="text-xl font-semibold text-red-800 mb-2">Error Loading Execution</h2>
          <p className="text-red-600">{error}</p>
          <button
            onClick={() => navigate('/executions')}
            className="mt-4 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
          >
            Back to Executions
          </button>
        </div>
      </div>
    );
  }

  if (!execution) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
          <p className="text-yellow-800">Execution not found</p>
          <button
            onClick={() => navigate('/executions')}
            className="mt-4 px-4 py-2 bg-yellow-600 text-white rounded hover:bg-yellow-700"
          >
            Back to Executions
          </button>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'progress', label: 'Progress', icon: '📊' },
    { id: 'control', label: 'Control', icon: '🎮' },
    { id: 'details', label: 'Details', icon: '📋' }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-6">
        <button
          onClick={() => navigate('/executions')}
          className="text-blue-600 hover:text-blue-800 mb-4 flex items-center gap-2"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          Back to Executions
        </button>

        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Execution Monitor</h1>
            <p className="text-gray-600 mt-1">
              ID: <span className="font-mono text-sm">{execution.execution_id}</span>
            </p>
          </div>

          <div className="text-right">
            <p className="text-sm text-gray-600">Status</p>
            <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium mt-1 ${
              execution.status === 'SUCCEEDED' ? 'bg-green-100 text-green-800' :
              execution.status === 'RUNNING' ? 'bg-blue-100 text-blue-800' :
              execution.status === 'FAILED' ? 'bg-red-100 text-red-800' :
              'bg-gray-100 text-gray-800'
            }`}>
              {execution.status}
            </span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200 mb-6">
        <nav className="-mb-px flex space-x-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <span className="flex items-center gap-2">
                <span>{tab.icon}</span>
                {tab.label}
              </span>
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      <div>
        {activeTab === 'progress' && (
          <ProgressDashboard executionId={execution.execution_id} />
        )}

        {activeTab === 'control' && (
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-lg shadow border border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Execution Control</h2>
              <ExecutionControlPanel
                executionArn={executionArn}
                executionId={execution.execution_id}
                status={execution.status}
                onActionComplete={handleActionComplete}
              />
            </div>

            {/* Control Instructions */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
              <h3 className="font-semibold text-blue-900 mb-2">Control Panel Guide</h3>
              <ul className="space-y-2 text-sm text-blue-800">
                <li className="flex items-start gap-2">
                  <span>•</span>
                  <span><strong>Stop:</strong> Immediately halts the execution. Cannot be undone.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span>•</span>
                  <span><strong>Resume:</strong> Creates a new execution with checkpoint data from where the previous execution stopped.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span>•</span>
                  <span><strong>Update Parameters:</strong> Modifies execution parameters. The workflow must poll for updates to apply them.</span>
                </li>
              </ul>
            </div>
          </div>
        )}

        {activeTab === 'details' && (
          <div className="space-y-6">
            {/* Execution Details */}
            <div className="bg-white p-6 rounded-lg shadow border border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Execution Details</h2>

              <dl className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <dt className="text-sm font-medium text-gray-600">Execution ARN</dt>
                  <dd className="mt-1 text-sm text-gray-900 font-mono break-all">{executionArn}</dd>
                </div>

                <div>
                  <dt className="text-sm font-medium text-gray-600">Start Time</dt>
                  <dd className="mt-1 text-sm text-gray-900">
                    {execution.start_time ? new Date(execution.start_time).toLocaleString() : 'N/A'}
                  </dd>
                </div>

                {execution.stop_time && (
                  <div>
                    <dt className="text-sm font-medium text-gray-600">Stop Time</dt>
                    <dd className="mt-1 text-sm text-gray-900">
                      {new Date(execution.stop_time).toLocaleString()}
                    </dd>
                  </div>
                )}

                {execution.error && (
                  <div className="md:col-span-2">
                    <dt className="text-sm font-medium text-red-600">Error</dt>
                    <dd className="mt-1 text-sm text-red-900 bg-red-50 p-3 rounded border border-red-200">
                      {execution.error}
                    </dd>
                  </div>
                )}

                {execution.cause && (
                  <div className="md:col-span-2">
                    <dt className="text-sm font-medium text-red-600">Cause</dt>
                    <dd className="mt-1 text-sm text-red-900 bg-red-50 p-3 rounded border border-red-200">
                      {execution.cause}
                    </dd>
                  </div>
                )}
              </dl>
            </div>

            {/* Input */}
            {execution.input && (
              <div className="bg-white p-6 rounded-lg shadow border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Input</h3>
                <pre className="bg-gray-50 p-4 rounded border border-gray-200 overflow-x-auto text-sm">
                  {JSON.stringify(
                    typeof execution.input === 'string' ? JSON.parse(execution.input) : execution.input,
                    null,
                    2
                  )}
                </pre>
              </div>
            )}

            {/* Output */}
            {execution.output && (
              <div className="bg-white p-6 rounded-lg shadow border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Output</h3>
                <pre className="bg-gray-50 p-4 rounded border border-gray-200 overflow-x-auto text-sm">
                  {JSON.stringify(
                    typeof execution.output === 'string' ? JSON.parse(execution.output) : execution.output,
                    null,
                    2
                  )}
                </pre>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ExecutionMonitorPage;
