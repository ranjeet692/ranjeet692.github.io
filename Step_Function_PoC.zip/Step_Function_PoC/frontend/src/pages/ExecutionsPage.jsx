import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const ExecutionsPage = () => {
  const navigate = useNavigate();
  const [executions, setExecutions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [page, setPage] = useState(1);
  const [selectedExecutions, setSelectedExecutions] = useState([]);

  useEffect(() => {
    loadExecutions();
    // Auto-refresh every 5 seconds
    const interval = setInterval(loadExecutions, 5000);
    return () => clearInterval(interval);
  }, [statusFilter, page]);

  const loadExecutions = async () => {
    try {
      setLoading(true);
      const params = {
        page,
        page_size: 20,
      };
      if (statusFilter !== 'ALL') {
        params.status = statusFilter;
      }
      const response = await axios.get(`${API_URL}/api/workflows/list`, { params });
      setExecutions(response.data.executions);
    } catch (error) {
      console.error('Failed to load executions:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleStopExecution = async (execution) => {
    if (!window.confirm(`Are you sure you want to stop execution ${execution.execution_id}?`)) {
      return;
    }

    try {
      await axios.post(`${API_URL}/api/workflows/stop`, {
        execution_arn: execution.execution_arn,
      });
      alert('Execution stopped successfully');
      loadExecutions();
    } catch (error) {
      alert(`Failed to stop execution: ${error.message}`);
    }
  };

  const handleRetryExecution = async (execution) => {
    if (!window.confirm(`Retry execution ${execution.execution_id} with the same input?`)) {
      return;
    }

    try {
      const response = await axios.post(`${API_URL}/api/workflows/retry/${encodeURIComponent(execution.execution_arn)}`);
      alert(`Execution retried successfully! New execution ID: ${response.data.new_execution_id}`);
      loadExecutions();
    } catch (error) {
      alert(`Failed to retry execution: ${error.message}`);
    }
  };

  const handleExportExecution = async (execution, format) => {
    try {
      const response = await axios.get(
        `${API_URL}/api/workflows/execution/${encodeURIComponent(execution.execution_arn)}/export`,
        { params: { format } }
      );

      const blob = new Blob([JSON.stringify(response.data.data, null, 2)], {
        type: format === 'csv' ? 'text/csv' : 'application/json',
      });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `execution_${execution.execution_id}.${format}`;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      alert(`Failed to export execution: ${error.message}`);
    }
  };

  const toggleExecutionSelection = (execution) => {
    setSelectedExecutions(prev => {
      const exists = prev.find(e => e.execution_arn === execution.execution_arn);
      if (exists) {
        return prev.filter(e => e.execution_arn !== execution.execution_arn);
      } else {
        return [...prev, execution];
      }
    });
  };

  const handleCompareSelected = () => {
    if (selectedExecutions.length < 2) {
      alert('Please select at least 2 executions to compare');
      return;
    }
    if (selectedExecutions.length > 5) {
      alert('You can compare up to 5 executions at a time');
      return;
    }
    const arns = selectedExecutions.map(e => e.execution_arn).join(',');
    navigate(`/comparison?arns=${encodeURIComponent(arns)}`);
  };

  const filteredExecutions = executions.filter(exec =>
    exec.execution_id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status) => {
    switch (status) {
      case 'RUNNING': return 'bg-blue-100 text-blue-800';
      case 'SUCCEEDED': return 'bg-green-100 text-green-800';
      case 'FAILED': return 'bg-red-100 text-red-800';
      case 'TIMED_OUT': return 'bg-orange-100 text-orange-800';
      case 'ABORTED': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDuration = (start, end) => {
    if (!end) return 'Running...';
    const duration = (new Date(end) - new Date(start)) / 1000;
    if (duration < 60) return `${duration.toFixed(1)}s`;
    if (duration < 3600) return `${(duration / 60).toFixed(1)}m`;
    return `${(duration / 3600).toFixed(1)}h`;
  };

  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Executions</h1>
          {selectedExecutions.length > 0 && (
            <button
              onClick={handleCompareSelected}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Compare Selected ({selectedExecutions.length})
            </button>
          )}
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Search</label>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by execution ID..."
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Status Filter</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="ALL">All Statuses</option>
              <option value="RUNNING">Running</option>
              <option value="SUCCEEDED">Succeeded</option>
              <option value="FAILED">Failed</option>
              <option value="TIMED_OUT">Timed Out</option>
              <option value="ABORTED">Aborted</option>
            </select>
          </div>
        </div>

        {/* Executions Table */}
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <input
                    type="checkbox"
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedExecutions(filteredExecutions.slice(0, 5));
                      } else {
                        setSelectedExecutions([]);
                      }
                    }}
                    checked={selectedExecutions.length === filteredExecutions.length && filteredExecutions.length > 0}
                  />
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Execution ID
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Started
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Duration
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {loading ? (
                <tr>
                  <td colSpan="6" className="px-6 py-4 text-center text-gray-500">
                    Loading executions...
                  </td>
                </tr>
              ) : filteredExecutions.length === 0 ? (
                <tr>
                  <td colSpan="6" className="px-6 py-4 text-center text-gray-500">
                    No executions found
                  </td>
                </tr>
              ) : (
                filteredExecutions.map((execution) => (
                  <tr key={execution.execution_arn} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <input
                        type="checkbox"
                        checked={selectedExecutions.some(e => e.execution_arn === execution.execution_arn)}
                        onChange={() => toggleExecutionSelection(execution)}
                      />
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <button
                        onClick={() => navigate(`/executions/${execution.execution_id}`)}
                        className="text-blue-600 hover:text-blue-900 font-medium"
                      >
                        {execution.execution_id}
                      </button>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(execution.status)}`}>
                        {execution.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(execution.start_time).toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {formatDuration(execution.start_time, execution.end_time)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex gap-2">
                        {execution.status === 'RUNNING' && (
                          <button
                            onClick={() => handleStopExecution(execution)}
                            className="text-red-600 hover:text-red-900"
                            title="Stop Execution"
                          >
                            ⏹️
                          </button>
                        )}
                        {(execution.status === 'FAILED' || execution.status === 'TIMED_OUT' || execution.status === 'ABORTED') && (
                          <button
                            onClick={() => handleRetryExecution(execution)}
                            className="text-green-600 hover:text-green-900"
                            title="Retry Execution"
                          >
                            🔄
                          </button>
                        )}
                        <button
                          onClick={() => navigate(`/executions/${execution.execution_id}`)}
                          className="text-blue-600 hover:text-blue-900"
                          title="View Details"
                        >
                          👁️
                        </button>
                        <button
                          onClick={() => handleExportExecution(execution, 'json')}
                          className="text-purple-600 hover:text-purple-900"
                          title="Export JSON"
                        >
                          📥
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex justify-between items-center mt-6">
          <button
            onClick={() => setPage(p => Math.max(1, p - 1))}
            disabled={page === 1}
            className="px-4 py-2 border border-gray-300 rounded-md disabled:opacity-50"
          >
            Previous
          </button>
          <span className="text-sm text-gray-700">Page {page}</span>
          <button
            onClick={() => setPage(p => p + 1)}
            disabled={executions.length < 20}
            className="px-4 py-2 border border-gray-300 rounded-md disabled:opacity-50"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default ExecutionsPage;
