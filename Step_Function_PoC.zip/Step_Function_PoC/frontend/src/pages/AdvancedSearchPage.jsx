import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const AdvancedSearchPage = () => {
  const navigate = useNavigate();
  const [filters, setFilters] = useState({
    status: '',
    start_date: '',
    end_date: '',
    min_duration: '',
    max_duration: '',
    search_input: '',
    search_output: ''
  });
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    try {
      setLoading(true);
      const params = {};

      // Only include non-empty filters
      if (filters.status) params.status = filters.status;
      if (filters.start_date) params.start_date = new Date(filters.start_date).toISOString();
      if (filters.end_date) params.end_date = new Date(filters.end_date).toISOString();
      if (filters.min_duration) params.min_duration = parseFloat(filters.min_duration);
      if (filters.max_duration) params.max_duration = parseFloat(filters.max_duration);
      if (filters.search_input) params.search_input = filters.search_input;
      if (filters.search_output) params.search_output = filters.search_output;

      const response = await axios.get(`${API_URL}/api/workflows/search/advanced`, { params });
      setResults(response.data);
    } catch (error) {
      console.error('Search failed:', error);
      alert('Search failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setFilters({
      status: '',
      start_date: '',
      end_date: '',
      min_duration: '',
      max_duration: '',
      search_input: '',
      search_output: ''
    });
    setResults(null);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'RUNNING': return 'bg-blue-100 text-blue-800';
      case 'SUCCEEDED': return 'bg-green-100 text-green-800';
      case 'FAILED': return 'bg-red-100 text-red-800';
      case 'TIMED_OUT': return 'bg-orange-100 text-orange-800';
      case 'ABORTED': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDuration = (start, end) => {
    if (!end) return 'Running...';
    const duration = (new Date(end) - new Date(start)) / 1000;
    if (duration < 60) return `${duration.toFixed(1)}s`;
    if (duration < 3600) return `${(duration / 60).toFixed(1)}m`;
    return `${(duration / 3600).toFixed(1)}h`;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white shadow rounded-lg p-6">
        <h1 className="text-3xl font-bold text-gray-900">Advanced Search</h1>
        <p className="text-sm text-gray-500 mt-1">Search executions with multiple filters and criteria</p>
      </div>

      {/* Search Filters */}
      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Search Filters</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Status Filter */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
            <select
              value={filters.status}
              onChange={(e) => setFilters({ ...filters, status: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">All Statuses</option>
              <option value="RUNNING">Running</option>
              <option value="SUCCEEDED">Succeeded</option>
              <option value="FAILED">Failed</option>
              <option value="TIMED_OUT">Timed Out</option>
              <option value="ABORTED">Aborted</option>
            </select>
          </div>

          {/* Start Date */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Start Date (From)</label>
            <input
              type="datetime-local"
              value={filters.start_date}
              onChange={(e) => setFilters({ ...filters, start_date: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          {/* End Date */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">End Date (To)</label>
            <input
              type="datetime-local"
              value={filters.end_date}
              onChange={(e) => setFilters({ ...filters, end_date: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          {/* Min Duration */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Min Duration (seconds)</label>
            <input
              type="number"
              value={filters.min_duration}
              onChange={(e) => setFilters({ ...filters, min_duration: e.target.value })}
              placeholder="e.g., 10"
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          {/* Max Duration */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Max Duration (seconds)</label>
            <input
              type="number"
              value={filters.max_duration}
              onChange={(e) => setFilters({ ...filters, max_duration: e.target.value })}
              placeholder="e.g., 300"
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          {/* Search Input */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Search in Input</label>
            <input
              type="text"
              value={filters.search_input}
              onChange={(e) => setFilters({ ...filters, search_input: e.target.value })}
              placeholder="Search execution input..."
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          {/* Search Output */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Search in Output</label>
            <input
              type="text"
              value={filters.search_output}
              onChange={(e) => setFilters({ ...filters, search_output: e.target.value })}
              placeholder="Search execution output..."
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-4 mt-6">
          <button
            onClick={handleSearch}
            disabled={loading}
            className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Searching...' : 'Search'}
          </button>
          <button
            onClick={handleReset}
            className="px-6 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700"
          >
            Reset
          </button>
        </div>
      </div>

      {/* Search Results */}
      {results && (
        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-900">
              Search Results ({results.total} found)
            </h2>
          </div>

          {/* Active Filters */}
          <div className="mb-4 flex flex-wrap gap-2">
            {Object.entries(results.filters_applied).map(([key, value]) => {
              if (!value) return null;
              return (
                <span key={key} className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                  {key.replace(/_/g, ' ')}: {value}
                </span>
              );
            })}
          </div>

          {results.executions && results.executions.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Execution ID
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Started
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Duration
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {results.executions.map((execution) => (
                    <tr key={execution.execution_arn} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <button
                          onClick={() => navigate(`/executions/${execution.execution_id}`)}
                          className="text-blue-600 hover:text-blue-900 font-medium"
                        >
                          {execution.execution_id}
                        </button>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(execution.status)}`}>
                          {execution.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(execution.start_time).toLocaleString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {formatDuration(execution.start_time, execution.stop_time)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button
                          onClick={() => navigate(`/executions/${execution.execution_id}`)}
                          className="text-blue-600 hover:text-blue-900"
                          title="View Details"
                        >
                          View Details
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              No executions found matching your search criteria
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default AdvancedSearchPage;
