import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const AnalyticsPage = () => {
  const [analytics, setAnalytics] = useState(null);
  const [errors, setErrors] = useState(null);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState(7);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    loadAnalytics();
  }, [timeRange]);

  const loadAnalytics = async () => {
    try {
      setLoading(true);
      const [analyticsRes, errorsRes] = await Promise.all([
        axios.get(`${API_URL}/api/workflows/analytics/overview`, { params: { days: timeRange } }),
        axios.get(`${API_URL}/api/workflows/analytics/errors`, { params: { limit: 100 } })
      ]);
      setAnalytics(analyticsRes.data);
      setErrors(errorsRes.data);
    } catch (error) {
      console.error('Failed to load analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!analytics) {
    return (
      <div className="text-center py-8 text-gray-500">
        No analytics data available
      </div>
    );
  }

  // Prepare data for charts
  const statusData = Object.entries(analytics.status_distribution).map(([status, count]) => ({
    name: status,
    value: count
  }));

  const COLORS = {
    'SUCCEEDED': '#10b981',
    'FAILED': '#ef4444',
    'RUNNING': '#3b82f6',
    'TIMED_OUT': '#f59e0b',
    'ABORTED': '#6b7280'
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Analytics Dashboard</h1>
            <p className="text-sm text-gray-500 mt-1">
              Showing data from {new Date(analytics.period.start_date).toLocaleDateString()} to {new Date(analytics.period.end_date).toLocaleDateString()}
            </p>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700 mr-2">Time Range:</label>
            <select
              value={timeRange}
              onChange={(e) => setTimeRange(Number(e.target.value))}
              className="px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            >
              <option value={1}>Last 24 hours</option>
              <option value={7}>Last 7 days</option>
              <option value={14}>Last 14 days</option>
              <option value={30}>Last 30 days</option>
              <option value={90}>Last 90 days</option>
            </select>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Executions</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{analytics.summary.total_executions}</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
              <span className="text-2xl">📊</span>
            </div>
          </div>
        </div>

        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Success Rate</p>
              <p className="text-3xl font-bold text-green-600 mt-2">{analytics.summary.success_rate}%</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              <span className="text-2xl">✅</span>
            </div>
          </div>
          <div className="mt-2 text-xs text-gray-500">
            {analytics.summary.success_count} succeeded, {analytics.summary.failure_count} failed
          </div>
        </div>

        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Avg Duration</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{analytics.summary.avg_duration_seconds.toFixed(1)}s</p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
              <span className="text-2xl">⏱️</span>
            </div>
          </div>
          <div className="mt-2 text-xs text-gray-500">
            Min: {analytics.duration_stats.min}s, Max: {analytics.duration_stats.max}s
          </div>
        </div>

        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Currently Running</p>
              <p className="text-3xl font-bold text-blue-600 mt-2">{analytics.summary.running_count}</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
              <span className="text-2xl">🔄</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white shadow rounded-lg">
        <div className="border-b border-gray-200">
          <nav className="flex -mb-px">
            {['overview', 'trends', 'errors'].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`py-4 px-6 text-sm font-medium border-b-2 ${
                  activeTab === tab
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {/* Overview Tab */}
          {activeTab === 'overview' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Status Distribution */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Status Distribution</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={statusData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {statusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[entry.name] || '#6b7280'} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              {/* Duration Statistics */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Duration Statistics</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                    <span className="text-sm text-gray-600">Minimum</span>
                    <span className="text-lg font-bold text-gray-900">{analytics.duration_stats.min}s</span>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-blue-50 rounded-lg">
                    <span className="text-sm text-gray-600">Average</span>
                    <span className="text-lg font-bold text-blue-600">{analytics.duration_stats.avg}s</span>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-purple-50 rounded-lg">
                    <span className="text-sm text-gray-600">Median</span>
                    <span className="text-lg font-bold text-purple-600">{analytics.duration_stats.median}s</span>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                    <span className="text-sm text-gray-600">Maximum</span>
                    <span className="text-lg font-bold text-gray-900">{analytics.duration_stats.max}s</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Trends Tab */}
          {activeTab === 'trends' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Daily Execution Trends</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={analytics.daily_trends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="total" stroke="#3b82f6" name="Total" strokeWidth={2} />
                    <Line type="monotone" dataKey="succeeded" stroke="#10b981" name="Succeeded" strokeWidth={2} />
                    <Line type="monotone" dataKey="failed" stroke="#ef4444" name="Failed" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Daily Executions (Bar Chart)</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={analytics.daily_trends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="succeeded" stackId="a" fill="#10b981" name="Succeeded" />
                    <Bar dataKey="failed" stackId="a" fill="#ef4444" name="Failed" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Errors Tab */}
          {activeTab === 'errors' && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Error Analysis</h3>
              {errors && errors.error_groups && errors.error_groups.length > 0 ? (
                <div className="space-y-4">
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <p className="text-sm text-red-800">
                      Found <strong>{errors.total_errors}</strong> unique error patterns across <strong>{errors.total_failed_executions}</strong> failed executions
                    </p>
                  </div>

                  {errors.error_groups.map((error, idx) => (
                    <div key={idx} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900">Error #{idx + 1}</h4>
                          <p className="text-sm text-red-600 mt-1 break-all">{error.error_message}</p>
                        </div>
                        <span className="ml-4 px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm font-medium">
                          {error.count} occurrences
                        </span>
                      </div>

                      <div className="mt-3 text-xs text-gray-600">
                        <div>First seen: {error.first_seen ? new Date(error.first_seen).toLocaleString() : 'Unknown'}</div>
                        <div>Last seen: {error.last_seen ? new Date(error.last_seen).toLocaleString() : 'Unknown'}</div>
                      </div>

                      {error.affected_executions && error.affected_executions.length > 0 && (
                        <details className="mt-3">
                          <summary className="text-sm text-blue-600 cursor-pointer hover:text-blue-800">
                            View affected executions ({error.affected_executions.length} shown)
                          </summary>
                          <ul className="mt-2 space-y-1">
                            {error.affected_executions.map((exec, i) => (
                              <li key={i} className="text-xs text-gray-600 ml-4">
                                • {exec.execution_id} - {new Date(exec.start_time).toLocaleString()}
                              </li>
                            ))}
                          </ul>
                        </details>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <p className="text-lg">No errors found</p>
                  <p className="text-sm mt-2">All executions completed successfully!</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AnalyticsPage;
