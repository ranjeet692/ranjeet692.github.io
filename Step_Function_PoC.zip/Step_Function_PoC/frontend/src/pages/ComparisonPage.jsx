import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const ComparisonPage = () => {
  const [searchParams] = useSearchParams();
  const [comparisons, setComparisons] = useState([]);
  const [loading, setLoading] = useState(true);
  const [availableExecutions, setAvailableExecutions] = useState([]);
  const [selectedExecutions, setSelectedExecutions] = useState([]);
  const [showSelector, setShowSelector] = useState(true);

  useEffect(() => {
    const arns = searchParams.get('arns');
    if (arns) {
      setShowSelector(false);
      loadComparisons(arns.split(','));
    } else {
      loadAvailableExecutions();
      setLoading(false);
    }
  }, [searchParams]);

  const loadAvailableExecutions = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/workflows/list`, {
        params: { page: 1, page_size: 50 }
      });
      setAvailableExecutions(response.data.executions);
    } catch (error) {
      console.error('Failed to load executions:', error);
    }
  };

  const loadComparisons = async (arns) => {
    try {
      setLoading(true);
      const response = await axios.post(`${API_URL}/api/workflows/compare-executions`, arns);
      setComparisons(response.data.comparisons);
    } catch (error) {
      console.error('Failed to load comparisons:', error);
      alert('Failed to load execution comparisons');
    } finally {
      setLoading(false);
    }
  };

  const toggleExecutionSelection = (execution) => {
    setSelectedExecutions(prev => {
      const exists = prev.find(e => e.execution_arn === execution.execution_arn);
      if (exists) {
        return prev.filter(e => e.execution_arn !== execution.execution_arn);
      } else {
        if (prev.length >= 5) {
          alert('You can compare up to 5 executions at a time');
          return prev;
        }
        return [...prev, execution];
      }
    });
  };

  const handleCompareNow = () => {
    if (selectedExecutions.length < 2) {
      alert('Please select at least 2 executions to compare');
      return;
    }
    const arns = selectedExecutions.map(e => e.execution_arn);
    setShowSelector(false);
    loadComparisons(arns);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'RUNNING': return 'bg-blue-100 text-blue-800';
      case 'SUCCEEDED': return 'bg-green-100 text-green-800';
      case 'FAILED': return 'bg-red-100 text-red-800';
      case 'TIMED_OUT': return 'bg-orange-100 text-orange-800';
      case 'ABORTED': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (showSelector && comparisons.length === 0) {
    return (
      <div className="space-y-6">
        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Execution Comparison</h1>
              <p className="text-sm text-gray-500 mt-2">Select 2-5 executions to compare their performance</p>
            </div>
            {selectedExecutions.length > 0 && (
              <button
                onClick={handleCompareNow}
                className="px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 font-medium"
              >
                Compare Selected ({selectedExecutions.length})
              </button>
            )}
          </div>

          {availableExecutions.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-600 text-lg">No executions available</p>
              <p className="text-sm text-gray-500 mt-2">Start a workflow first to see executions here</p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">
                  💡 <strong>Tip:</strong> Select between 2 and 5 executions from the list below to compare their performance metrics, duration, and results.
                </p>
              </div>

              <div className="border rounded-lg overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Select
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Execution ID
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Started
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Duration
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {availableExecutions.map((execution) => (
                      <tr
                        key={execution.execution_arn}
                        className={`hover:bg-gray-50 cursor-pointer ${
                          selectedExecutions.some(e => e.execution_arn === execution.execution_arn)
                            ? 'bg-blue-50'
                            : ''
                        }`}
                        onClick={() => toggleExecutionSelection(execution)}
                      >
                        <td className="px-6 py-4 whitespace-nowrap">
                          <input
                            type="checkbox"
                            checked={selectedExecutions.some(e => e.execution_arn === execution.execution_arn)}
                            onChange={() => toggleExecutionSelection(execution)}
                            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                          />
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">{execution.execution_id}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(execution.status)}`}>
                            {execution.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(execution.start_time).toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {execution.end_time
                            ? `${((new Date(execution.end_time) - new Date(execution.start_time)) / 1000).toFixed(1)}s`
                            : 'Running...'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (comparisons.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-600">No executions to compare</p>
        <p className="text-sm text-gray-500 mt-2">Select executions from the Executions page to compare</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Execution Comparison</h1>
          <button
            onClick={() => {
              setShowSelector(true);
              setComparisons([]);
              setSelectedExecutions([]);
              loadAvailableExecutions();
            }}
            className="px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700"
          >
            ← Change Selection
          </button>
        </div>

        {/* Comparison Table */}
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Metric
                </th>
                {comparisons.map((comp, idx) => (
                  <th key={idx} className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Execution {idx + 1}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {/* Execution ID */}
              <tr>
                <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">Execution ID</td>
                {comparisons.map((comp, idx) => (
                  <td key={idx} className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                    {comp.execution_id}
                  </td>
                ))}
              </tr>

              {/* Status */}
              <tr className="bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">Status</td>
                {comparisons.map((comp, idx) => (
                  <td key={idx} className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(comp.status)}`}>
                      {comp.status}
                    </span>
                  </td>
                ))}
              </tr>

              {/* Duration */}
              <tr>
                <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">Duration (seconds)</td>
                {comparisons.map((comp, idx) => {
                  const fastest = Math.min(...comparisons.filter(c => c.duration_seconds).map(c => c.duration_seconds));
                  const isFastest = comp.duration_seconds === fastest && comp.duration_seconds;
                  return (
                    <td key={idx} className="px-6 py-4 whitespace-nowrap">
                      <span className={`text-sm ${isFastest ? 'font-bold text-green-600' : 'text-gray-700'}`}>
                        {comp.duration_seconds ? comp.duration_seconds.toFixed(2) : 'N/A'}
                        {isFastest && ' 🏆'}
                      </span>
                    </td>
                  );
                })}
              </tr>

              {/* Start Time */}
              <tr className="bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">Start Time</td>
                {comparisons.map((comp, idx) => (
                  <td key={idx} className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                    {new Date(comp.start_time).toLocaleString()}
                  </td>
                ))}
              </tr>

              {/* Total Events */}
              <tr>
                <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">Total Events</td>
                {comparisons.map((comp, idx) => (
                  <td key={idx} className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                    {comp.total_events}
                  </td>
                ))}
              </tr>

              {/* Error */}
              <tr className="bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">Error</td>
                {comparisons.map((comp, idx) => (
                  <td key={idx} className="px-6 py-4 whitespace-nowrap text-sm">
                    {comp.error ? (
                      <span className="text-red-600">{comp.error}</span>
                    ) : (
                      <span className="text-gray-400">None</span>
                    )}
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>

        {/* Detailed Comparison Cards */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {comparisons.map((comp, idx) => (
            <div key={idx} className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-gray-900">Execution {idx + 1}</h3>
                <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(comp.status)}`}>
                  {comp.status}
                </span>
              </div>

              <div className="space-y-3">
                <div>
                  <div className="text-xs text-gray-600">ID</div>
                  <div className="text-sm font-medium text-gray-900 truncate">{comp.execution_id}</div>
                </div>

                <div>
                  <div className="text-xs text-gray-600">Duration</div>
                  <div className="text-2xl font-bold text-gray-900">
                    {comp.duration_seconds ? `${comp.duration_seconds.toFixed(1)}s` : 'N/A'}
                  </div>
                </div>

                <div>
                  <div className="text-xs text-gray-600">Started</div>
                  <div className="text-sm text-gray-700">{new Date(comp.start_time).toLocaleString()}</div>
                </div>

                {comp.stop_time && (
                  <div>
                    <div className="text-xs text-gray-600">Ended</div>
                    <div className="text-sm text-gray-700">{new Date(comp.stop_time).toLocaleString()}</div>
                  </div>
                )}

                <div>
                  <div className="text-xs text-gray-600">Total Events</div>
                  <div className="text-sm font-medium text-gray-900">{comp.total_events}</div>
                </div>

                {/* Input Preview */}
                <div>
                  <details className="text-xs">
                    <summary className="text-gray-600 cursor-pointer hover:text-gray-900">View Input</summary>
                    <pre className="mt-2 bg-gray-100 p-2 rounded overflow-auto max-h-32 text-xs">
                      {JSON.stringify(comp.input, null, 2)}
                    </pre>
                  </details>
                </div>

                {/* Output Preview */}
                {comp.output && (
                  <div>
                    <details className="text-xs">
                      <summary className="text-gray-600 cursor-pointer hover:text-gray-900">View Output</summary>
                      <pre className="mt-2 bg-gray-100 p-2 rounded overflow-auto max-h-32 text-xs">
                        {JSON.stringify(comp.output, null, 2)}
                      </pre>
                    </details>
                  </div>
                )}

                {comp.error && (
                  <div className="p-2 bg-red-50 border border-red-200 rounded">
                    <div className="text-xs text-red-900 font-medium">Error:</div>
                    <div className="text-xs text-red-700 mt-1">{comp.error}</div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Performance Insights */}
        <div className="mt-8 p-6 bg-blue-50 border border-blue-200 rounded-lg">
          <h3 className="font-bold text-blue-900 mb-4">Performance Insights</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <div className="text-sm text-blue-700">Success Rate</div>
              <div className="text-2xl font-bold text-blue-900">
                {((comparisons.filter(c => c.status === 'SUCCEEDED').length / comparisons.length) * 100).toFixed(0)}%
              </div>
            </div>
            <div>
              <div className="text-sm text-blue-700">Average Duration</div>
              <div className="text-2xl font-bold text-blue-900">
                {(comparisons.filter(c => c.duration_seconds).reduce((acc, c) => acc + c.duration_seconds, 0) /
                  comparisons.filter(c => c.duration_seconds).length || 0).toFixed(1)}s
              </div>
            </div>
            <div>
              <div className="text-sm text-blue-700">Total Executions</div>
              <div className="text-2xl font-bold text-blue-900">{comparisons.length}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ComparisonPage;
