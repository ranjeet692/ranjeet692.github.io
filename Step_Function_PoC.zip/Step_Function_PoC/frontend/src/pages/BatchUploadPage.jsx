import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import FileUpload from '../components/FileUpload';
import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const BatchUploadPage = () => {
  const navigate = useNavigate();
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [workflows, setWorkflows] = useState([]);
  const [selectedWorkflow, setSelectedWorkflow] = useState('');
  const [workflowConfig, setWorkflowConfig] = useState({
    enableOCR: true,
    enableNER: true,
    enablePII: true,
    chunkLargeFiles: true,
    chunkSizeMB: 50
  });
  const [notificationEmail, setNotificationEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showConfig, setShowConfig] = useState(false);

  useEffect(() => {
    fetchWorkflows();
  }, []);

  const fetchWorkflows = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/workflows/templates`);
      // API returns {total: number, workflows: array}
      const workflowsData = response.data.workflows || response.data;
      const workflowsArray = Array.isArray(workflowsData) ? workflowsData : [];
      setWorkflows(workflowsArray);

      // Pre-select the LocalStack distributed map workflow if available
      const localStackWorkflow = workflowsArray.find(
        w => w.id === 'distributed_map_batch_workflow_localstack'
      );
      if (localStackWorkflow) {
        setSelectedWorkflow(localStackWorkflow.id);
      }
    } catch (err) {
      console.error('Error fetching workflows:', err);
      setWorkflows([]); // Ensure workflows is always an array
      setError('Failed to load workflow templates');
    }
  };

  const handleUploadComplete = (files) => {
    setUploadedFiles(files);
  };

  const handleExecuteWorkflow = async () => {
    if (!selectedWorkflow) {
      setError('Please select a workflow template');
      return;
    }

    if (uploadedFiles.length === 0) {
      setError('Please upload files first');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      // Prepare input based on workflow type
      const workflowInput = prepareWorkflowInput();

      // Execute workflow
      const response = await axios.post(
        `${API_URL}/api/workflows/templates/${selectedWorkflow}/execute`,
        workflowInput
      );

      console.log('Workflow execution started:', response.data);

      // Navigate to execution monitor
      const executionArn = response.data.execution_arn;
      navigate(`/executions/${encodeURIComponent(executionArn)}/monitor`);
    } catch (err) {
      console.error('Error executing workflow:', err);
      setError(err.response?.data?.detail || err.message);
    } finally {
      setLoading(false);
    }
  };

  const prepareWorkflowInput = () => {
    // For LocalStack distributed map workflow
    if (selectedWorkflow === 'distributed_map_batch_workflow_localstack') {
      return {
        files: uploadedFiles.map(file => ({
          bucket: file.bucket,
          file_key: file.key,
          file_id: file.id || file.key.split('/').pop()
        })),
        expectedFileCount: uploadedFiles.length,
        processingConfig: {
          enableOCR: workflowConfig.enableOCR,
          enableNER: workflowConfig.enableNER,
          enablePII: workflowConfig.enablePII,
          chunkLargeFiles: workflowConfig.chunkLargeFiles,
          chunkSizeMB: workflowConfig.chunkSizeMB
        },
        notificationEmails: notificationEmail ? [notificationEmail] : []
      };
    }

    // For production distributed map workflow (uses manifest)
    if (selectedWorkflow === 'distributed_map_batch_workflow') {
      // Would need to generate manifest first
      return {
        manifestBucket: uploadedFiles[0]?.bucket || 'batch-processing',
        manifestKey: 'manifests/upload-batch.csv',
        resultsBucket: 'batch-processing-results',
        expectedFileCount: uploadedFiles.length,
        processingConfig: {
          enableOCR: workflowConfig.enableOCR,
          enableNER: workflowConfig.enableNER,
          enablePII: workflowConfig.enablePII,
          chunkLargeFiles: workflowConfig.chunkLargeFiles,
          chunkSizeMB: workflowConfig.chunkSizeMB
        },
        notificationEmails: notificationEmail ? [notificationEmail] : []
      };
    }

    // Generic workflow input
    return {
      files: uploadedFiles.map(file => ({
        bucket: file.bucket,
        key: file.key
      }))
    };
  };

  const selectedWorkflowObj = Array.isArray(workflows)
    ? workflows.find(w => w.id === selectedWorkflow)
    : null;

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Batch File Processing</h1>
        <p className="text-gray-600 mt-2">
          Upload files and execute batch processing workflows
        </p>
      </div>

      {/* Error Message */}
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
          <div className="flex items-start gap-3">
            <svg className="w-5 h-5 text-red-600 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <div className="flex-1">
              <p className="text-red-800 font-medium">Error</p>
              <p className="text-red-600 text-sm mt-1">{error}</p>
            </div>
            <button
              onClick={() => setError(null)}
              className="text-red-600 hover:text-red-800"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* File Upload Section */}
          <div className="bg-white rounded-lg shadow border border-gray-200">
            <div className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Upload Files</h2>
              <FileUpload onUploadComplete={handleUploadComplete} />

              {uploadedFiles.length > 0 && (
                <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <p className="text-green-800 font-medium">
                    {uploadedFiles.length} file{uploadedFiles.length !== 1 ? 's' : ''} uploaded successfully
                  </p>
                  <div className="mt-2 max-h-40 overflow-y-auto">
                    <ul className="text-sm text-green-700 space-y-1">
                      {uploadedFiles.map((file, index) => (
                        <li key={index} className="flex items-center gap-2">
                          <svg className="w-4 h-4 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          <span className="font-mono text-xs truncate">{file.key}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Workflow Selection */}
          <div className="bg-white rounded-lg shadow border border-gray-200">
            <div className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Select Workflow</h2>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Workflow Template
                  </label>
                  <select
                    value={selectedWorkflow}
                    onChange={(e) => setSelectedWorkflow(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select a workflow...</option>
                    {workflows.map((workflow) => (
                      <option key={workflow.id} value={workflow.id}>
                        {workflow.name || workflow.id}
                      </option>
                    ))}
                  </select>
                </div>

                {selectedWorkflowObj && (
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h3 className="font-medium text-blue-900 mb-2">Workflow Details</h3>
                    <dl className="space-y-2 text-sm">
                      <div>
                        <dt className="text-blue-700 font-medium">Type</dt>
                        <dd className="text-blue-900">{selectedWorkflowObj.type || 'STANDARD'}</dd>
                      </div>
                      {selectedWorkflowObj.description && (
                        <div>
                          <dt className="text-blue-700 font-medium">Description</dt>
                          <dd className="text-blue-900">{selectedWorkflowObj.description}</dd>
                        </div>
                      )}
                    </dl>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Processing Configuration */}
          <div className="bg-white rounded-lg shadow border border-gray-200">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-900">Configuration</h2>
                <button
                  onClick={() => setShowConfig(!showConfig)}
                  className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                >
                  {showConfig ? 'Hide' : 'Show'}
                </button>
              </div>

              {showConfig && (
                <div className="space-y-4">
                  <div className="space-y-3">
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={workflowConfig.enableOCR}
                        onChange={(e) => setWorkflowConfig({ ...workflowConfig, enableOCR: e.target.checked })}
                        className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                      <span className="text-sm text-gray-700">Enable OCR</span>
                    </label>

                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={workflowConfig.enableNER}
                        onChange={(e) => setWorkflowConfig({ ...workflowConfig, enableNER: e.target.checked })}
                        className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                      <span className="text-sm text-gray-700">Enable NER (Named Entity Recognition)</span>
                    </label>

                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={workflowConfig.enablePII}
                        onChange={(e) => setWorkflowConfig({ ...workflowConfig, enablePII: e.target.checked })}
                        className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                      <span className="text-sm text-gray-700">Enable PII Detection</span>
                    </label>

                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={workflowConfig.chunkLargeFiles}
                        onChange={(e) => setWorkflowConfig({ ...workflowConfig, chunkLargeFiles: e.target.checked })}
                        className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                      <span className="text-sm text-gray-700">Chunk Large Files</span>
                    </label>

                    {workflowConfig.chunkLargeFiles && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Chunk Size (MB)
                        </label>
                        <input
                          type="number"
                          value={workflowConfig.chunkSizeMB}
                          onChange={(e) => setWorkflowConfig({ ...workflowConfig, chunkSizeMB: parseInt(e.target.value) })}
                          min="1"
                          max="100"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Notification Email (optional)
                    </label>
                    <input
                      type="email"
                      value={notificationEmail}
                      onChange={(e) => setNotificationEmail(e.target.value)}
                      placeholder="your@email.com"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Execution Summary */}
          <div className="bg-white rounded-lg shadow border border-gray-200">
            <div className="p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Summary</h2>

              <dl className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <dt className="text-gray-600">Files</dt>
                  <dd className="font-medium text-gray-900">{uploadedFiles.length}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-gray-600">Workflow</dt>
                  <dd className="font-medium text-gray-900 text-right">
                    {selectedWorkflow ? (selectedWorkflowObj?.name || selectedWorkflow) : 'Not selected'}
                  </dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-gray-600">Total Size</dt>
                  <dd className="font-medium text-gray-900">
                    {(uploadedFiles.reduce((sum, file) => sum + (file.size || 0), 0) / (1024 * 1024)).toFixed(2)} MB
                  </dd>
                </div>
              </dl>

              <button
                onClick={handleExecuteWorkflow}
                disabled={loading || uploadedFiles.length === 0 || !selectedWorkflow}
                className="w-full mt-6 px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors font-medium"
              >
                {loading ? (
                  <span className="flex items-center justify-center gap-2">
                    <svg className="animate-spin h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Starting Workflow...
                  </span>
                ) : (
                  <span className="flex items-center justify-center gap-2">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    Execute Workflow
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* Help Section */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <h3 className="font-semibold text-yellow-900 mb-2 flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Quick Guide
            </h3>
            <ol className="space-y-2 text-sm text-yellow-800">
              <li className="flex items-start gap-2">
                <span className="font-semibold">1.</span>
                <span>Upload files using drag & drop or file selector</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold">2.</span>
                <span>Select a workflow template for processing</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold">3.</span>
                <span>Configure processing options (optional)</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold">4.</span>
                <span>Click Execute to start batch processing</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold">5.</span>
                <span>Monitor progress on the execution page</span>
              </li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BatchUploadPage;
