import React, { useState, useEffect } from 'react';
import axios from 'axios';
import WorkflowGraph from '../components/WorkflowGraph';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const StateMachinesPage = () => {
  const [stateMachines, setStateMachines] = useState([]);
  const [selectedMachine, setSelectedMachine] = useState(null);
  const [selectedMachineDetails, setSelectedMachineDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loadingDetails, setLoadingDetails] = useState(false);

  useEffect(() => {
    loadStateMachines();
  }, []);

  useEffect(() => {
    if (selectedMachine) {
      loadMachineDetails(selectedMachine.stateMachineArn);
    }
  }, [selectedMachine]);

  const loadStateMachines = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${API_URL}/api/workflows/state-machines`);
      setStateMachines(response.data.state_machines);
      if (response.data.state_machines.length > 0) {
        setSelectedMachine(response.data.state_machines[0]);
      }
    } catch (error) {
      console.error('Failed to load state machines:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadMachineDetails = async (arn) => {
    try {
      setLoadingDetails(true);
      setSelectedMachineDetails(null);
      const response = await axios.get(`${API_URL}/api/workflows/state-machine/${encodeURIComponent(arn)}`);
      setSelectedMachineDetails(response.data);
    } catch (error) {
      console.error('Failed to load state machine details:', error);
    } finally {
      setLoadingDetails(false);
    }
  };

  const handleDownloadDefinition = () => {
    if (!selectedMachineDetails?.definition) {
      alert('Definition not available');
      return;
    }

    try {
      const blob = new Blob([selectedMachineDetails.definition], {
        type: 'application/json',
      });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${selectedMachine.name}_definition.json`;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      alert(`Failed to download definition: ${error.message}`);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'ACTIVE': return 'bg-green-100 text-green-800';
      case 'DELETING': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg p-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">State Machines</h1>

        {stateMachines.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            No state machines found
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* State Machines List */}
            <div className="lg:col-span-1">
              <div className="space-y-2">
                {stateMachines.map((machine) => (
                  <button
                    key={machine.stateMachineArn}
                    onClick={() => setSelectedMachine(machine)}
                    className={`w-full text-left p-4 rounded-lg border-2 transition-all ${
                      selectedMachine?.stateMachineArn === machine.stateMachineArn
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="font-medium text-gray-900 mb-1">{machine.name}</div>
                    <div className="text-xs text-gray-500 mb-2 truncate">{machine.stateMachineArn}</div>
                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(machine.status)}`}>
                      {machine.status}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* State Machine Details */}
            <div className="lg:col-span-3">
              {selectedMachine ? (
                <div className="space-y-6">
                  {/* Machine Info */}
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h2 className="text-xl font-bold text-gray-900 mb-4">{selectedMachine.name}</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <div className="text-sm text-gray-600">Status</div>
                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(selectedMachine.status)}`}>
                          {selectedMachine.status}
                        </span>
                      </div>
                      <div>
                        <div className="text-sm text-gray-600">Type</div>
                        <div className="text-sm font-medium text-gray-900">{selectedMachine.type || 'STANDARD'}</div>
                      </div>
                      <div className="md:col-span-2">
                        <div className="text-sm text-gray-600">ARN</div>
                        <div className="text-xs text-gray-900 break-all">{selectedMachine.stateMachineArn}</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-600">Created</div>
                        <div className="text-sm text-gray-900">
                          {new Date(selectedMachine.creationDate).toLocaleString()}
                        </div>
                      </div>
                      {selectedMachine.roleArn && (
                        <div className="md:col-span-2">
                          <div className="text-sm text-gray-600">Role ARN</div>
                          <div className="text-xs text-gray-900 break-all">{selectedMachine.roleArn}</div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Workflow Visualization */}
                  <WorkflowGraph stateMachineArn={selectedMachine.stateMachineArn} />

                  {/* Definition JSON */}
                  <div className="bg-white border rounded-lg p-4">
                    <div className="flex justify-between items-center mb-2">
                      <details className="flex-1">
                        <summary className="text-lg font-medium text-gray-900 cursor-pointer hover:text-blue-600">
                          View Full Definition (JSON)
                        </summary>
                        <pre className="mt-4 bg-gray-100 p-4 rounded overflow-auto max-h-96 text-xs">
                          {loadingDetails ? (
                            'Loading definition...'
                          ) : selectedMachineDetails?.definition ? (
                            JSON.stringify(JSON.parse(selectedMachineDetails.definition), null, 2)
                          ) : (
                            'Definition not available'
                          )}
                        </pre>
                      </details>
                      {selectedMachineDetails?.definition && (
                        <button
                          onClick={handleDownloadDefinition}
                          className="ml-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm"
                          title="Download Definition"
                        >
                          📥 Download
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  Select a state machine to view details
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default StateMachinesPage;
