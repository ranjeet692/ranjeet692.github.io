#!/bin/bash

# Script to redeploy the processor Lambda function to LocalStack
# Usage: ./scripts/redeploy-processor.sh

set -e

echo "Redeploying processor Lambda function..."

# Create temp directory
TEMP_DIR=$(mktemp -d)
cd "$TEMP_DIR"

echo "Packaging processor Lambda..."

# Create package directory
mkdir -p processor_pkg

# Install dependencies if requirements.txt exists
BACKEND_PATH="/Users/ranjeetkumar/Workspace/Step_Function_PoC/backend"
if [ -f "${BACKEND_PATH}/lambdas/processor/requirements.txt" ]; then
    echo "Installing dependencies..."
    pip install -r "${BACKEND_PATH}/lambdas/processor/requirements.txt" -t processor_pkg/ -q
fi

# Copy handler
cp "${BACKEND_PATH}/lambdas/processor/handler.py" processor_pkg/processor.py

# Create zip
echo "Creating deployment package..."
cd processor_pkg
zip -r ../processor.zip . -q
cd ..

# Copy to LocalStack container
echo "Copying package to LocalStack..."
docker cp processor.zip llm-orchestration-localstack:/tmp/processor.zip

# Update Lambda function
echo "Updating Lambda function..."
docker exec llm-orchestration-localstack awslocal lambda update-function-code \
  --function-name document-processor \
  --zip-file fileb:///tmp/processor.zip

# Cleanup
cd /
rm -rf "$TEMP_DIR"

echo "✓ Processor Lambda function redeployed successfully!"
echo ""
echo "The Lambda will use the new code on the next invocation."
