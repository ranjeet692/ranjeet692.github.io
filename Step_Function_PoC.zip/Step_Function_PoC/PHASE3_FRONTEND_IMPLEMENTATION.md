# Phase 3 - Frontend UI Components Implementation

## Overview

This document describes the **Phase 3 Frontend UI Components** implementation for the Step Functions PoC project. Phase 3 builds upon the backend features from Phase 2 to provide a complete user interface for batch file processing with real-time monitoring.

---

## Features Implemented

### 1. File Upload Component with Drag & Drop
- **Component:** [FileUpload.jsx](frontend/src/components/FileUpload.jsx)
- **Features:**
  - Drag & drop file upload interface
  - Automatic multipart upload for files >10MB
  - Per-file progress tracking with visual indicators
  - Batch upload support
  - File validation and error handling
  - Upload cancellation capability

### 2. Real-Time Progress Dashboard
- **Component:** [ProgressDashboard.jsx](frontend/src/components/ProgressDashboard.jsx)
- **Features:**
  - Server-Sent Events (SSE) integration for live updates
  - Progress metrics display (percentage, items/sec, ETA)
  - Recharts line chart for progress visualization
  - Event timeline with color-coded event types
  - File-level tracking (processed/failed lists)
  - Auto-reconnect on connection loss

### 3. Execution Control Panel
- **Component:** [ExecutionControlPanel.jsx](frontend/src/components/ExecutionControlPanel.jsx)
- **Features:**
  - Stop execution with reason tracking
  - Resume from checkpoint with JSON data editor
  - Update parameters with JSON editor
  - Modal dialogs for each control action
  - Success/error feedback messages
  - Status-based button visibility

### 4. Integrated Execution Monitor Page
- **Page:** [ExecutionMonitorPage.jsx](frontend/src/pages/ExecutionMonitorPage.jsx)
- **Features:**
  - Tab-based navigation (Progress, Control, Details)
  - Integration of all three components
  - Execution details display (input/output JSON)
  - Auto-navigation on resume to new execution
  - Back navigation to executions list

### 5. Batch Upload Page
- **Page:** [BatchUploadPage.jsx](frontend/src/pages/BatchUploadPage.jsx)
- **Features:**
  - Complete batch processing workflow
  - Workflow template selection
  - Processing configuration options
  - Execution summary and statistics
  - Auto-navigation to monitor page on execution start
  - Quick guide for users

### 6. Updated Routing
- **File:** [App.jsx](frontend/src/App.jsx)
- **New Routes:**
  - `/batch-upload` - Batch file upload and execution
  - `/executions/:executionArn/monitor` - Real-time execution monitoring
- **Navigation:** Added "Batch Upload" link to main navigation

---

## Component Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                       BatchUploadPage                        │
│  ┌───────────────────────────────────────────────────────┐  │
│  │              FileUpload Component                     │  │
│  │  - Drag & drop zone                                   │  │
│  │  - Multipart upload for large files                   │  │
│  │  - Progress tracking                                  │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                              │
│  Workflow Selection + Configuration                         │
│  └──> Execute Workflow                                      │
│        └──> Navigate to ExecutionMonitorPage               │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                   ExecutionMonitorPage                       │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  Tab: Progress                                        │  │
│  │  ┌─────────────────────────────────────────────────┐  │  │
│  │  │        ProgressDashboard Component              │  │  │
│  │  │  - SSE connection for live updates              │  │  │
│  │  │  - Metrics (%, items/sec, ETA)                  │  │  │
│  │  │  - Progress chart (Recharts)                    │  │  │
│  │  │  - Event timeline                               │  │  │
│  │  └─────────────────────────────────────────────────┘  │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                              │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  Tab: Control                                         │  │
│  │  ┌─────────────────────────────────────────────────┐  │  │
│  │  │    ExecutionControlPanel Component              │  │  │
│  │  │  - Stop execution (with reason)                 │  │  │
│  │  │  - Resume from checkpoint (JSON editor)         │  │  │
│  │  │  - Update parameters (JSON editor)              │  │  │
│  │  └─────────────────────────────────────────────────┘  │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                              │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  Tab: Details                                         │  │
│  │  - Execution metadata                                 │  │
│  │  - Input/Output JSON                                  │  │
│  │  - Error/Cause display                                │  │
│  └───────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

---

## User Workflow

### Complete Batch Processing Flow

```
1. Navigate to /batch-upload
   ↓
2. Upload files via drag & drop
   - Small files (<10MB): Direct upload
   - Large files (>10MB): Multipart upload with progress
   ↓
3. Select workflow template
   - distributed_map_batch_workflow_localstack (recommended for local)
   - distributed_map_batch_workflow (for production)
   ↓
4. Configure processing options (optional)
   - Enable OCR
   - Enable NER (Named Entity Recognition)
   - Enable PII Detection
   - Chunk large files
   - Set notification email
   ↓
5. Click "Execute Workflow"
   ↓
6. Auto-navigate to /executions/{executionArn}/monitor
   ↓
7. Monitor Progress (Tab: Progress)
   - View real-time progress chart
   - See items/second throughput
   - Check estimated completion time
   - Review event timeline
   ↓
8. Control Execution (Tab: Control)
   - Stop execution if needed
   - Resume from checkpoint
   - Update parameters dynamically
   ↓
9. View Details (Tab: Details)
   - Check execution metadata
   - Review input/output JSON
   - Investigate errors/failures
```

---

## Technical Implementation Details

### FileUpload Component

**Multipart Upload Flow:**
```javascript
// 1. Initiate multipart upload
const initResponse = await axios.post(
  `${API_URL}/api/workflows/files/upload/multipart/initiate`,
  { bucket, key, file_size }
);

const { upload_id, presigned_urls } = initResponse.data;

// 2. Upload parts in parallel using presigned URLs
const uploadedParts = await Promise.all(
  presigned_urls.map(async (part) => {
    const chunk = file.slice(part.start_byte, part.end_byte + 1);
    const response = await fetch(part.url, {
      method: 'PUT',
      body: chunk
    });
    return {
      part_number: part.part_number,
      etag: response.headers.get('ETag')
    };
  })
);

// 3. Complete multipart upload
await axios.post(
  `${API_URL}/api/workflows/files/upload/multipart/complete`,
  { bucket, key, upload_id, parts: uploadedParts }
);
```

### ProgressDashboard Component

**SSE Integration:**
```javascript
const connectToStream = () => {
  const eventSource = new EventSource(
    `${API_URL}/api/workflows/progress/${executionId}/stream`
  );

  eventSource.onmessage = (event) => {
    const data = JSON.parse(event.data);

    if (data.type === 'progress') {
      setProgress(data.data);
      // Add to history for chart
      setProgressHistory(prev => [...prev, {
        time: new Date().toLocaleTimeString(),
        percentage: data.data.progress_percentage
      }]);
    } else if (data.type === 'completed') {
      eventSource.close();
    }
  };

  eventSource.onerror = () => {
    eventSource.close();
    // Auto-reconnect after 5 seconds
    setTimeout(() => {
      if (progress?.status === 'RUNNING') {
        connectToStream();
      }
    }, 5000);
  };
};
```

**Progress Metrics Calculation:**
```javascript
// Items per second
const itemsPerSecond = progress.items_per_second || 0;

// Estimated time remaining
const remainingItems = progress.total_items -
  (progress.completed_items + progress.failed_items);
const remainingSeconds = itemsPerSecond > 0
  ? remainingItems / itemsPerSecond
  : 0;
```

### ExecutionControlPanel Component

**Resume with Checkpoint:**
```javascript
const handleResume = async () => {
  const checkpoint = checkpointData ? JSON.parse(checkpointData) : null;

  const response = await axios.post(
    `${API_URL}/api/workflows/executions/${encodeURIComponent(executionArn)}/resume`,
    { checkpoint_data: checkpoint }
  );

  // Navigate to new execution
  if (response.data.new_execution_arn) {
    navigate(`/executions/${encodeURIComponent(response.data.new_execution_arn)}/monitor`);
  }
};
```

### BatchUploadPage Component

**Workflow Input Preparation:**
```javascript
const prepareWorkflowInput = () => {
  // For LocalStack distributed map workflow
  if (selectedWorkflow === 'distributed_map_batch_workflow_localstack') {
    return {
      files: uploadedFiles.map(file => ({
        bucket: file.bucket,
        file_key: file.key,
        file_id: file.id || file.key.split('/').pop()
      })),
      expectedFileCount: uploadedFiles.length,
      processingConfig: {
        enableOCR: workflowConfig.enableOCR,
        enableNER: workflowConfig.enableNER,
        enablePII: workflowConfig.enablePII,
        chunkLargeFiles: workflowConfig.chunkLargeFiles,
        chunkSizeMB: workflowConfig.chunkSizeMB
      },
      notificationEmails: notificationEmail ? [notificationEmail] : []
    };
  }
  // ... handle other workflow types
};
```

---

## Dependencies Added

### Frontend Dependencies

**Required npm packages:**
```json
{
  "dependencies": {
    "react": "^18.x",
    "react-dom": "^18.x",
    "react-router-dom": "^6.x",
    "axios": "^1.x",
    "recharts": "^2.x"
  }
}
```

**Installation:**
```bash
cd frontend
npm install recharts
```

---

## Testing

### Local Testing Instructions

**1. Start Backend Services:**
```bash
cd backend
docker compose up -d
```

**2. Start Frontend:**
```bash
cd frontend
npm install
npm start
```

**3. Access Application:**
- Open browser to `http://localhost:3000`
- Navigate to "Batch Upload" in the navigation bar

**4. Upload Files:**
- Drag files into the upload zone OR click to select files
- Wait for uploads to complete (multipart upload for large files)

**5. Execute Workflow:**
- Select workflow: "distributed_map_batch_workflow_localstack"
- Configure processing options (optional)
- Click "Execute Workflow"

**6. Monitor Execution:**
- Automatically navigated to execution monitor page
- Watch real-time progress updates
- View event timeline
- Check processing metrics

**7. Control Execution (Optional):**
- Switch to "Control" tab
- Stop execution if needed
- Resume from checkpoint with custom data
- Update parameters dynamically

### Manual Testing Checklist

- [ ] File upload via drag & drop
- [ ] File upload via click selection
- [ ] Multipart upload for large files (>10MB)
- [ ] Upload progress tracking
- [ ] Workflow selection
- [ ] Configuration options
- [ ] Workflow execution
- [ ] Auto-navigation to monitor page
- [ ] Real-time progress updates (SSE)
- [ ] Progress chart rendering
- [ ] Event timeline display
- [ ] Stop execution
- [ ] Resume from checkpoint
- [ ] Update parameters
- [ ] Navigation between tabs
- [ ] Back navigation to executions list

---

## Performance Considerations

### Frontend Optimizations

**1. SSE Connection Management:**
- Auto-close connection when execution completes
- Auto-reconnect on connection loss (5-second delay)
- Prevent memory leaks with cleanup on unmount

**2. Progress History:**
- Limit history to last 50 data points for chart
- Prevents memory issues with long-running executions

**3. Multipart Upload:**
- Parallel part uploads for improved throughput
- Chunk size: 5MB per part (configurable)
- Direct client-to-S3 upload (no server bandwidth usage)

**4. Component Rendering:**
- Use React.memo for heavy components (if needed)
- Debounce chart updates to 1 second
- Lazy load components with React.lazy (future enhancement)

---

## Known Limitations

### Current Limitations

1. **SSE Browser Compatibility:**
   - EventSource API not supported in Internet Explorer
   - Use polyfill for older browsers if needed

2. **Chart Performance:**
   - Chart may lag with very frequent updates (>100 updates/second)
   - Mitigated by 1-second update interval

3. **Large File Lists:**
   - BatchUploadPage may slow down with 1000+ files in list
   - Consider pagination for production

4. **Mobile Responsiveness:**
   - Current implementation optimized for desktop
   - Mobile layout needs improvements (future enhancement)

---

## Future Enhancements (Phase 4)

### Recommended Next Steps

1. **WebSocket Support:**
   - Replace SSE with WebSocket API for bidirectional communication
   - Better support for real-time updates and notifications

2. **Enhanced Charts:**
   - Add more chart types (bar, pie, area charts)
   - Historical comparison charts
   - Custom date range selection

3. **Advanced File Management:**
   - Bulk file selection from S3 browser
   - Direct S3 prefix scanning
   - File preview capability

4. **Notification System:**
   - Browser push notifications
   - Email notification configuration
   - Slack/Teams integration

5. **Error Recovery:**
   - Automatic retry mechanism
   - Failed file reprocessing
   - Checkpoint visualization

6. **Mobile Optimization:**
   - Responsive design improvements
   - Touch-optimized controls
   - Mobile-specific layouts

7. **Performance Monitoring:**
   - Component performance profiling
   - Bundle size optimization
   - Code splitting and lazy loading

---

## API Endpoints Used

### Progress Tracking
- `GET /api/workflows/progress/{execution_id}` - Get current progress
- `GET /api/workflows/progress/{execution_id}/stream` - SSE stream
- `GET /api/workflows/progress/{execution_id}/events` - Event timeline

### File Upload
- `POST /api/workflows/files/upload/batch` - Regular batch upload
- `POST /api/workflows/files/upload/multipart/initiate` - Start multipart upload
- `POST /api/workflows/files/upload/multipart/complete` - Complete multipart upload
- `POST /api/workflows/files/upload/multipart/abort` - Cancel multipart upload

### Execution Control
- `POST /api/workflows/executions/{arn}/stop` - Stop execution
- `POST /api/workflows/executions/{arn}/resume` - Resume from checkpoint
- `PUT /api/workflows/executions/{arn}/parameters` - Update parameters

### Workflow Management
- `GET /api/workflows/templates` - List workflow templates
- `POST /api/workflows/templates/{id}/execute` - Execute workflow
- `GET /api/workflows/status/{arn}` - Get execution status

---

## Files Created/Modified

### New Files Created

**Components:**
- `frontend/src/components/FileUpload.jsx` (329 lines)
- `frontend/src/components/ProgressDashboard.jsx` (447 lines)
- `frontend/src/components/ExecutionControlPanel.jsx` (296 lines)

**Pages:**
- `frontend/src/pages/ExecutionMonitorPage.jsx` (282 lines)
- `frontend/src/pages/BatchUploadPage.jsx` (489 lines)

**Documentation:**
- `PHASE3_FRONTEND_IMPLEMENTATION.md` (this file)

### Files Modified

- `frontend/src/App.jsx` - Added new routes and imports
- `frontend/src/components/Layout.jsx` - Added "Batch Upload" navigation link

---

## Conclusion

Phase 3 successfully delivers a complete frontend interface for batch file processing with real-time monitoring. The implementation provides:

- **Intuitive UI** for file upload and workflow execution
- **Real-time monitoring** with Server-Sent Events
- **Execution control** for stop/resume/parameter updates
- **Integrated experience** combining all features into cohesive pages

The frontend is now ready for integration testing with the Phase 2 backend services. Users can upload files, execute batch processing workflows, and monitor progress in real-time with full control over execution lifecycle.

---

## References

- **Phase 2 Implementation:** [PHASE2_IMPLEMENTATION.md](PHASE2_IMPLEMENTATION.md)
- **Distributed Map Implementation:** [DISTRIBUTED_MAP_IMPLEMENTATION.md](DISTRIBUTED_MAP_IMPLEMENTATION.md)
- **Implementation Plan:** [IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md)
- **React Router Documentation:** https://reactrouter.com/
- **Recharts Documentation:** https://recharts.org/
- **EventSource API:** https://developer.mozilla.org/en-US/docs/Web/API/EventSource
