#!/bin/bash

# Quick start script for local development
set -e

echo "=========================================="
echo "LLM Orchestration PoC - Quick Start"
echo "=========================================="

# Check if .env exists
if [ ! -f .env ]; then
    echo "Creating .env file from template..."
    cp .env.example .env
    echo "✓ .env file created"
else
    echo "✓ .env file already exists"
fi

echo ""
echo "Starting services with Docker Compose..."
docker compose up -d

echo ""
echo "Waiting for services to be ready..."
echo "  - LocalStack (AWS services)"
echo "  - Backend API"
echo "  - Frontend"

# Wait for LocalStack
echo ""
echo "Waiting for LocalStack to initialize (this may take 1-2 minutes)..."
sleep 10

# Check LocalStack health
MAX_RETRIES=30
RETRY_COUNT=0

while [ $RETRY_COUNT -lt $MAX_RETRIES ]; do
    if docker compose logs localstack 2>&1 | grep -q "Ready."; then
        echo "✓ LocalStack is ready!"
        break
    fi
    echo "  Still initializing... ($((RETRY_COUNT + 1))/$MAX_RETRIES)"
    sleep 5
    RETRY_COUNT=$((RETRY_COUNT + 1))
done

if [ $RETRY_COUNT -eq $MAX_RETRIES ]; then
    echo "⚠ Warning: LocalStack may not be fully initialized"
fi

# Wait for Backend
echo ""
echo "Waiting for Backend API..."
RETRY_COUNT=0
while [ $RETRY_COUNT -lt 20 ]; do
    if curl -s http://localhost:8000/health > /dev/null 2>&1; then
        echo "✓ Backend API is ready!"
        break
    fi
    echo "  Waiting for backend... ($((RETRY_COUNT + 1))/20)"
    sleep 3
    RETRY_COUNT=$((RETRY_COUNT + 1))
done

# Wait for Frontend
echo ""
echo "Waiting for Frontend..."
RETRY_COUNT=0
while [ $RETRY_COUNT -lt 20 ]; do
    if curl -s http://localhost:3000 > /dev/null 2>&1; then
        echo "✓ Frontend is ready!"
        break
    fi
    echo "  Waiting for frontend... ($((RETRY_COUNT + 1))/20)"
    sleep 3
    RETRY_COUNT=$((RETRY_COUNT + 1))
done

echo ""
echo "=========================================="
echo "🎉 All services are running!"
echo "=========================================="
echo ""
echo "Access the application:"
echo "  📊 Frontend Dashboard: http://localhost:3000"
echo "  📚 API Documentation:  http://localhost:8000/docs"
echo "  ❤️  Health Check:       http://localhost:8000/health"
echo ""
echo "View logs:"
echo "  docker compose logs -f backend"
echo "  docker compose logs -f localstack"
echo "  docker compose logs -f frontend"
echo ""
echo "Stop services:"
echo "  docker compose down"
echo ""
echo "=========================================="