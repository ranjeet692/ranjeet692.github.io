"""Setup test environment for distributed map workflow testing."""
import boto3
import json
from botocore.exceptions import ClientError


# LocalStack S3 client
s3_client = boto3.client(
    's3',
    endpoint_url='http://localhost:4566',
    region_name='us-east-1',
    aws_access_key_id='test',
    aws_secret_access_key='test'
)


def create_bucket(bucket_name):
    """Create S3 bucket if it doesn't exist."""
    try:
        s3_client.create_bucket(Bucket=bucket_name)
        print(f"✅ Created bucket: {bucket_name}")
        return True
    except ClientError as e:
        if e.response['Error']['Code'] == 'BucketAlreadyOwnedByYou':
            print(f"✓  Bucket already exists: {bucket_name}")
            return True
        else:
            print(f"❌ Failed to create bucket {bucket_name}: {e}")
            return False


def generate_file_list(count, bucket, prefix):
    """Generate a list of file references."""
    files = []
    for i in range(count):
        files.append({
            'bucket': bucket,
            'file_key': f'{prefix}/file_{i:06d}.pdf',
            'file_id': f'FILE-{i:06d}'
        })
    return files


def setup_test_buckets():
    """Create necessary test buckets."""
    print("\n=== Setting up S3 test buckets ===\n")

    buckets = [
        'test-batch-processing',
        'test-batch-processing-results',
        'batch-processing',
        'batch-processing-results'
    ]

    for bucket in buckets:
        create_bucket(bucket)


def create_test_input_files(bucket, count=10):
    """Create dummy test files in S3."""
    print(f"\n=== Creating {count} test files in {bucket} ===\n")

    for i in range(count):
        key = f'test-files/file_{i:06d}.pdf'
        try:
            s3_client.put_object(
                Bucket=bucket,
                Key=key,
                Body=f'Test file content {i}'.encode('utf-8'),
                ContentType='application/pdf'
            )
            if i % 10 == 0:
                print(f"  Created {i+1}/{count} files...")
        except ClientError as e:
            print(f"❌ Failed to create file {key}: {e}")
            return False

    print(f"✅ Created {count} test files")
    return True


def save_test_input_json(file_count, output_file='test_input.json'):
    """Save test input JSON for workflow execution."""
    print(f"\n=== Generating test input JSON for {file_count} files ===\n")

    files = generate_file_list(
        count=file_count,
        bucket='test-batch-processing',
        prefix='test-files'
    )

    input_data = {
        'files': files,
        'expectedFileCount': file_count,
        'processingConfig': {
            'enableOCR': True,
            'enableNER': True,
            'enablePII': True
        },
        'notificationEmails': ['test@example.com']
    }

    with open(output_file, 'w') as f:
        json.dump(input_data, f, indent=2)

    print(f"✅ Saved test input to {output_file}")
    print(f"   Files: {len(files)}")
    return input_data


if __name__ == "__main__":
    print("=" * 80)
    print("Distributed Map Workflow - Test Environment Setup")
    print("=" * 80)

    try:
        # Step 1: Create buckets
        setup_test_buckets()

        # Step 2: Create small set of actual test files (10 files)
        create_test_input_files('test-batch-processing', count=10)

        # Step 3: Generate test input JSON files for different batch sizes
        save_test_input_json(10, 'test_input_10.json')
        save_test_input_json(100, 'test_input_100.json')
        save_test_input_json(1000, 'test_input_1000.json')

        print("\n" + "=" * 80)
        print("✅ Test environment setup complete!")
        print("=" * 80)
        print("\nNext steps:")
        print("1. Run: python3 test_distributed_workflow_localstack.py")
        print("2. Or use the generated JSON files:")
        print("   - test_input_10.json (10 files)")
        print("   - test_input_100.json (100 files)")
        print("   - test_input_1000.json (1,000 files)")

    except Exception as e:
        print(f"\n❌ Setup failed: {str(e)}")
        import traceback
        traceback.print_exc()
