# LLM Document Processing Orchestration PoC

A comprehensive FastAPI + AWS Step Functions proof-of-concept for orchestrating large-scale document processing with LLM integration (simulating Bedrock/Claude workflows).

## 🎯 Project Overview

This project demonstrates enterprise-scale document processing orchestration using:

- **FastAPI** as the main API layer
- **AWS Step Functions** for workflow orchestration
- **Lambda Functions** for document processing (with simulated LLM operations)
- **S3** for file storage
- **DynamoDB** for state persistence
- **React.js** frontend with real-time WebSocket updates
- **LocalStack** for local AWS emulation

## 🏗️ Architecture

```
┌─────────────────┐
│   React UI      │  ← Real-time WebSocket updates
└────────┬────────┘
         │
┌────────┴────────┐
│   FastAPI       │  ← REST API + WebSocket server
└────────┬────────┘
         │
    ┌────┴────┐
    │         │
    ▼         ▼
┌─────────┐  ┌──────────────┐
│   S3    │  │ Step Functions│
└─────────┘  └──────┬───────┘
                    │
         ┌──────────┼──────────┐
         ▼          ▼          ▼
    ┌────────┐ ┌────────┐ ┌────────┐
    │Chunker │ │Processor│ │Aggregator│
    │ Lambda │ │ Lambda  │ │ Lambda   │
    └────────┘ └────────┘ └────────┘
                    │
                    ▼
              ┌──────────┐
              │ DynamoDB │  ← State tracking
              └──────────┘
```

## ✨ Key Features

### 1. Scalability & Performance
- **Parallel Processing**: Handle multiple files simultaneously
- **Chunking Strategy**: Split large files into processable chunks (configurable)
- **Concurrency Controls**: Max parallel executions and throttling
- **Batch Processing**: Efficient handling of 1,000+ files

### 2. Real-time Monitoring
- **WebSocket Connection**: Live progress updates
- **Streaming Output**: Real-time results from Lambda functions
- **Execution Dashboard**: Visual status tracking
- **Progress Indicators**: Per-file and per-chunk progress

### 3. Manual Controls
- ✅ Start workflow execution
- ⏸️ Pause execution (via Step Functions)
- ▶️ Resume paused execution
- ⏹️ Terminate/cancel execution
- 🔄 Retry failed executions

### 4. Resilience & Error Handling
- **Automatic Retries**: Configurable retry logic with exponential backoff
- **Error Catching**: Graceful handling of failures
- **State Persistence**: Resume from last successful state
- **Partial Completion**: Track and resume incomplete executions
- **Dead Letter Queue Ready**: Framework for handling permanent failures

### 5. Monitoring & Analytics
- **Execution History**: Complete audit trail
- **Metrics Dashboard**: Success rates, processing times
- **File Metadata Tracking**: Per-file and per-chunk status
- **Real-time Status Updates**: Live execution monitoring

## 🚀 Quick Start

### Prerequisites
- Docker & Docker Compose
- 8GB+ RAM recommended
- Ports 3000, 4566, 8000 available

### 1. Clone and Setup
```bash
cd llm-orchestration-poc
cp .env.example .env
```

### 2. Start LocalStack and Services
```bash
docker compose up -d
```

This will start:
- LocalStack (port 4566) - AWS services emulation
- Backend API (port 8000) - FastAPI application
- Frontend (port 3000) - React dashboard

### 3. Wait for Initialization
```bash
# Check LocalStack initialization
docker compose logs -f localstack

# Wait for "LocalStack initialization complete!" message
```

### 4. Access the Application
- **Frontend Dashboard**: http://localhost:3000
- **API Documentation**: http://localhost:8000/docs
- **API Health Check**: http://localhost:8000/health

## 📖 Usage Guide

### Starting a Workflow

1. **Select Files**:
   - Navigate to the dashboard
   - View available files from S3
   - Select one or more files to process

2. **Start Processing**:
   - Click "Start Processing"
   - Monitor real-time progress via WebSocket

3. **View Progress**:
   - Overall execution progress
   - Per-file completion status
   - Chunk-level processing details

### Managing Executions

- **View Executions**: See all current and past executions
- **Stop Running Execution**: Click "Stop" button on running execution
- **View Details**: Click on execution to see detailed progress
- **Check Status**: Real-time status updates via WebSocket

### API Endpoints

#### Start Workflow
```bash
curl -X POST http://localhost:8000/api/workflows/start \
  -H "Content-Type: application/json" \
  -d '{
    "files": [
      {"file_key": "sample_1.txt", "file_size": 1024}
    ],
    "max_concurrency": 10,
    "chunk_size_mb": 5
  }'
```

#### Get Execution Status
```bash
curl http://localhost:8000/api/workflows/status/{execution_arn}
```

#### Stop Execution
```bash
curl -X POST http://localhost:8000/api/workflows/stop \
  -H "Content-Type: application/json" \
  -d '{"execution_arn": "arn:aws:states:..."}'
```

#### List Executions
```bash
curl http://localhost:8000/api/workflows/list
```

#### Get Metrics
```bash
curl http://localhost:8000/api/workflows/metrics
```

### WebSocket Connection

Connect to execution updates:
```javascript
const ws = new WebSocket('ws://localhost:8000/ws/execution/{execution_id}');

ws.onmessage = (event) => {
  const message = JSON.parse(event.data);
  console.log('Update:', message);
};
```

## 🔧 Configuration

### Environment Variables

Edit `.env` file:

```bash
# AWS Configuration
AWS_REGION=us-east-1
USE_LOCALSTACK=true

# Processing Configuration
MAX_CONCURRENT_EXECUTIONS=10
CHUNK_SIZE_MB=5
BATCH_SIZE=50

# Simulation Configuration
MIN_PROCESSING_TIME=10
MAX_PROCESSING_TIME=600
ENABLE_STREAMING=true
```

### Adjusting Concurrency

Modify `MAX_CONCURRENT_EXECUTIONS` in `.env` or pass in API request:

```json
{
  "files": [...],
  "max_concurrency": 20
}
```

### Chunk Size Configuration

Set chunk size (in MB) for large file processing:

```json
{
  "files": [...],
  "chunk_size_mb": 10
}
```

## 🧪 Testing

### Test Lambda Functions Locally

```bash
# Test Chunker
cd backend/lambdas/chunker
python handler.py

# Test Processor
cd backend/lambdas/processor
python handler.py

# Test Aggregator
cd backend/lambdas/aggregator
python handler.py
```

### Upload Test Files

```bash
# Using AWS CLI with LocalStack
aws --endpoint-url=http://localhost:4566 s3 cp myfile.txt s3://document-processing-bucket/
```

### View DynamoDB State

```bash
# List execution states
aws --endpoint-url=http://localhost:4566 dynamodb scan \
  --table-name document-processing-state
```

## 📊 Monitoring

### View Logs

```bash
# Backend logs
docker compose logs -f backend

# LocalStack logs (Lambda executions)
docker compose logs -f localstack

# Frontend logs
docker compose logs -f frontend
```

### Check Step Functions Execution

```bash
# List executions
aws --endpoint-url=http://localhost:4566 stepfunctions list-executions \
  --state-machine-arn arn:aws:states:us-east-1:000000000000:stateMachine:DocumentProcessingWorkflow
```

## 🎓 Advanced Features

### Pause/Resume Workflow

Step Functions doesn't natively support pause/resume, but you can:

1. **Manual Pause**: Stop execution, save state in DynamoDB
2. **Resume**: Start new execution with saved state

### Retry Failed Executions

Failed executions can be retried:

```bash
curl -X POST http://localhost:8000/api/workflows/start \
  -H "Content-Type: application/json" \
  -d '{
    "files": [...],
    "resume_from_execution": "previous-execution-id"
  }'
```

### Custom Workflow Definition

Edit `backend/stepfunctions/workflow.json` to modify:
- Retry policies
- Error handling
- Parallel processing limits
- Timeout values

## 🚀 Deployment to AWS

### Prerequisites

1. AWS Account with appropriate permissions
2. AWS CLI configured
3. Update `.env`:
   ```bash
   USE_LOCALSTACK=false
   AWS_ENDPOINT_URL=  # Remove this line
   ```

### Deploy Infrastructure

```bash
# Deploy CloudFormation stack
aws cloudformation create-stack \
  --stack-name llm-orchestration \
  --template-body file://infrastructure/cloudformation/stack.yaml \
  --capabilities CAPABILITY_IAM
```

### Deploy Lambda Functions

```bash
# Package and deploy Lambdas
cd backend/lambdas/processor
zip -r function.zip handler.py
aws lambda update-function-code \
  --function-name document-processor \
  --zip-file fileb://function.zip
```

### Deploy Backend

```bash
# Build and push Docker image to ECR
docker build -t llm-orchestration-backend backend/
docker tag llm-orchestration-backend:latest {ECR_URL}:latest
docker push {ECR_URL}:latest

# Deploy to ECS/Fargate or EKS
```

### Deploy Frontend

```bash
# Build production bundle
cd frontend
npm run build

# Deploy to S3 + CloudFront
aws s3 sync build/ s3://your-frontend-bucket/
```

## 🔍 Troubleshooting

### LocalStack Not Starting

```bash
# Check Docker resources
docker stats

# Restart LocalStack
docker compose restart localstack
```

### Lambda Functions Not Found

```bash
# Check Lambda functions exist
aws --endpoint-url=http://localhost:4566 lambda list-functions

# Re-run initialization script
docker compose exec localstack /etc/localstack/init/ready.d/init-aws.sh
```

### WebSocket Connection Failed

- Check backend is running: `curl http://localhost:8000/health`
- Verify CORS settings in `backend/app/main.py`
- Check browser console for connection errors

### Execution Not Starting

- Verify S3 files exist
- Check Step Functions state machine exists
- Review backend logs for errors

## 📁 Project Structure

```
llm-orchestration-poc/
├── backend/
│   ├── app/
│   │   ├── api/              # API routes
│   │   ├── services/         # AWS service clients
│   │   ├── models/           # Pydantic schemas
│   │   ├── config.py         # Configuration
│   │   └── main.py           # FastAPI app
│   ├── lambdas/
│   │   ├── processor/        # Document processor
│   │   ├── chunker/          # File chunker
│   │   └── aggregator/       # Result aggregator
│   └── stepfunctions/
│       └── workflow.json     # State machine definition
├── frontend/
│   └── src/
│       ├── components/       # React components
│       ├── hooks/            # Custom hooks
│       └── App.jsx           # Main app
├── infrastructure/
│   ├── localstack/
│   │   └── init-aws.sh       # LocalStack setup
│   └── cloudformation/
│       └── stack.yaml        # AWS CloudFormation
├── docker-compose.yml
└── README.md
```

## 🤝 Contributing

This is a proof-of-concept project. For production use:

1. Add authentication/authorization
2. Implement comprehensive error handling
3. Add monitoring (CloudWatch, Prometheus, etc.)
4. Set up CI/CD pipelines
5. Add comprehensive testing
6. Implement security best practices

## 📝 License

MIT License - feel free to use this PoC as a foundation for your projects.

## 🎯 Next Steps

To enhance this PoC:

1. **Real LLM Integration**: Replace mock Lambda with actual Bedrock/Claude API calls
2. **Advanced Chunking**: Implement semantic chunking strategies
3. **Result Storage**: Save processed results to S3/database
4. **Cost Optimization**: Implement intelligent caching and batch processing
5. **Enhanced Monitoring**: Add CloudWatch dashboards and alarms
6. **API Gateway**: Add authentication and rate limiting
7. **Multi-tenant Support**: Implement tenant isolation
8. **Advanced Error Recovery**: Implement sophisticated retry and recovery logic

## 📞 Support

For questions or issues:
- Review API documentation at http://localhost:8000/docs
- Check logs: `docker compose logs`
- Review Step Functions execution history

---

**Note**: This is a development/PoC environment. For production deployment, additional security, monitoring, and optimization measures are required.