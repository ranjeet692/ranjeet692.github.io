"""Test script for distributed map batch workflow."""
import requests
import json
import time

API_URL = "http://localhost:8000"


def test_manifest_generation():
    """Test manifest generation with different file counts."""
    print("\n=== Testing Manifest Generation ===\n")

    test_cases = [
        {"file_count": 100, "desc": "Small batch (100 files)"},
        {"file_count": 1000, "desc": "Medium batch (1,000 files)"},
        {"file_count": 10000, "desc": "Large batch (10,000 files)"},
    ]

    for test_case in test_cases:
        file_count = test_case["file_count"]
        desc = test_case["desc"]

        print(f"\n--- {desc} ---")

        # Create test manifest
        response = requests.post(
            f"{API_URL}/api/workflows/manifests/test",
            params={
                "file_count": file_count,
                "bucket": "test-batch-processing",
                "prefix": f"test-files-{file_count}",
                "output_bucket": "test-batch-processing",
                "output_key": f"manifests/test-manifest-{file_count}.csv"
            }
        )

        if response.status_code == 200:
            result = response.json()
            print(f"✅ Manifest created: {result['manifestKey']}")
            print(f"   File count: {result['fileCount']}")
            print(f"   Generated at: {result['generatedAt']}")

            # Validate manifest
            validate_response = requests.post(
                f"{API_URL}/api/workflows/manifests/validate",
                params={
                    "manifest_bucket": result['manifestBucket'],
                    "manifest_key": result['manifestKey']
                }
            )

            if validate_response.status_code == 200:
                validation = validate_response.json()
                if validation['valid']:
                    print(f"✅ Manifest validated: {validation['fileCount']} files, {validation['format']} format")
                else:
                    print(f"❌ Manifest validation failed: {validation.get('error')}")
            else:
                print(f"❌ Validation request failed: {validate_response.status_code}")

        else:
            print(f"❌ Manifest creation failed: {response.status_code}")
            print(f"   Error: {response.text}")


def test_workflow_deployment():
    """Test deploying the distributed map workflow."""
    print("\n=== Testing Workflow Deployment ===\n")

    # Get workflow template info
    response = requests.get(f"{API_URL}/api/workflows/templates/distributed_map_batch_workflow")

    if response.status_code == 200:
        workflow = response.json()
        print(f"✅ Workflow template found: {workflow['workflow_id']}")
        print(f"   States: {len(workflow['definition']['States'])}")
        print(f"   Input schema: {json.dumps(workflow['input_schema']['example'], indent=2)}")

        # Deploy workflow
        deploy_response = requests.post(
            f"{API_URL}/api/workflows/templates/distributed_map_batch_workflow/deploy"
        )

        if deploy_response.status_code == 200:
            deployment = deploy_response.json()
            print(f"\n✅ Workflow deployed: {deployment['name']}")
            print(f"   Status: {deployment['status']}")
            print(f"   ARN: {deployment['stateMachineArn']}")
        else:
            print(f"\n❌ Deployment failed: {deploy_response.status_code}")
            print(f"   Error: {deploy_response.text}")

    else:
        print(f"❌ Failed to get workflow template: {response.status_code}")
        print(f"   Error: {response.text}")


def test_workflow_execution(file_count=100):
    """Test executing the distributed map workflow."""
    print(f"\n=== Testing Workflow Execution ({file_count} files) ===\n")

    # Prepare input data
    input_data = {
        "manifestBucket": "test-batch-processing",
        "manifestKey": f"manifests/test-manifest-{file_count}.csv",
        "resultsBucket": "test-batch-processing-results",
        "expectedFileCount": file_count,
        "processingConfig": {
            "enableOCR": True,
            "enableNER": True,
            "enablePII": True,
            "chunkLargeFiles": True,
            "chunkSizeMB": 50
        },
        "notificationEmails": ["test@example.com"]
    }

    # Start execution
    response = requests.post(
        f"{API_URL}/api/workflows/templates/distributed_map_batch_workflow/execute",
        params={"execution_name": f"test-distributed-{file_count}-{int(time.time())}"},
        json=input_data
    )

    if response.status_code == 200:
        execution = response.json()
        print(f"✅ Workflow execution started")
        print(f"   Execution ARN: {execution['executionArn']}")
        print(f"   Execution ID: {execution['executionId']}")
        print(f"   Start time: {execution['startDate']}")

        # Monitor execution status
        print("\n⏳ Monitoring execution status...")
        execution_arn = execution['executionArn']

        for i in range(10):
            time.sleep(2)

            status_response = requests.get(
                f"{API_URL}/api/workflows/status/{execution_arn}"
            )

            if status_response.status_code == 200:
                status = status_response.json()
                current_status = status['status']
                print(f"   [{i+1}/10] Status: {current_status}")

                if current_status in ['SUCCEEDED', 'FAILED', 'TIMED_OUT', 'ABORTED']:
                    print(f"\n✅ Execution completed with status: {current_status}")
                    if current_status == 'SUCCEEDED':
                        print(f"   Output: {json.dumps(status.get('output'), indent=2)}")
                    elif current_status == 'FAILED':
                        print(f"   Error: {status.get('error')}")
                        print(f"   Cause: {status.get('cause')}")
                    break
            else:
                print(f"   ❌ Failed to get status: {status_response.status_code}")
                break
        else:
            print("\n⏰ Execution still running after monitoring period")

    else:
        print(f"❌ Execution failed to start: {response.status_code}")
        print(f"   Error: {response.text}")


def list_available_workflows():
    """List all available workflow templates."""
    print("\n=== Available Workflow Templates ===\n")

    response = requests.get(f"{API_URL}/api/workflows/templates")

    if response.status_code == 200:
        data = response.json()
        workflows = data['workflows']

        print(f"Total workflows: {data['total']}\n")

        # Group by category
        by_category = {}
        for wf in workflows:
            category = wf['category']
            if category not in by_category:
                by_category[category] = []
            by_category[category].append(wf)

        for category, wfs in sorted(by_category.items()):
            print(f"{category.upper()}:")
            for wf in wfs:
                print(f"  • {wf['name']}")
                print(f"    ID: {wf['id']}")
                print(f"    Features: {', '.join(wf['features'])}")
                print(f"    Description: {wf['description'][:80]}...")
                print()

    else:
        print(f"❌ Failed to list workflows: {response.status_code}")
        print(f"   Error: {response.text}")


if __name__ == "__main__":
    print("=" * 80)
    print("Distributed Map Batch Workflow - Test Suite")
    print("=" * 80)

    try:
        # Test 1: List available workflows
        list_available_workflows()

        # Test 2: Generate manifests for different batch sizes
        test_manifest_generation()

        # Test 3: Deploy the distributed workflow
        test_workflow_deployment()

        # Test 4: Execute with small batch (100 files)
        test_workflow_execution(file_count=100)

        print("\n" + "=" * 80)
        print("✅ All tests completed!")
        print("=" * 80)

    except requests.exceptions.ConnectionError:
        print("\n❌ Error: Cannot connect to API server at http://localhost:8000")
        print("   Please ensure the backend server is running:")
        print("   cd backend && uvicorn app.main:app --reload")
    except Exception as e:
        print(f"\n❌ Unexpected error: {str(e)}")
        import traceback
        traceback.print_exc()
