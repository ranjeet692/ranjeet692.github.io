cd Step Functions_Poc
./start.sh
# Open http://localhost:3000
```

### 📁 Key Files

**Documentation:**
- `GETTING_STARTED.md` - Start here!
- `QUICKSTART.md` - 5-minute guide
- `README.md` - Complete documentation
- `PROJECT_SUMMARY.md` - Technical details

**Configuration:**
- `.env.example` - Configuration template
- `docker-compose.yml` - Service orchestration
- `start.sh` - Quick start script
- `deploy.sh` - AWS deployment

**Backend:**
- `backend/app/main.py` - FastAPI application
- `backend/stepfunctions/workflow.json` - State machine
- `backend/lambdas/` - Processing functions

**Frontend:**
- `frontend/src/components/Dashboard.jsx` - Main UI
- `frontend/src/hooks/useWebSocket.js` - Real-time updates

## ✨ Key Features

- **Scalability**: Handle 1,000+ files with parallel processing
- **Real-time**: WebSocket updates every 2 seconds
- **Chunking**: Automatic splitting of large files
- **Resilience**: Automatic retries and error handling
- **Monitoring**: Live progress and metrics dashboard
- **Controls**: Start, stop, and monitor workflows
- **State Persistence**: DynamoDB tracking
- **Local Development**: Complete LocalStack setup
- **Production Ready**: CloudFormation and deployment scripts

## 🎯 What It Does

1. **Upload files** to S3 (sample files included)
2. **Chunk large files** into processable segments
3. **Process in parallel** using Lambda functions
4. **Simulate LLM processing** (10-600 seconds with streaming)
5. **Aggregate results** per file
6. **Track state** in DynamoDB
7. **Update real-time** via WebSocket

## 📊 Architecture
```
React Dashboard → FastAPI → Step Functions → Lambda Functions
                              ↓              ↓
                           DynamoDB      S3 Storage