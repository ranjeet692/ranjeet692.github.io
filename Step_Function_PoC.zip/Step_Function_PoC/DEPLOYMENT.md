# Step Functions PoC - Deployment Guide

## 🎯 Complete Feature Set

This PoC implements a comprehensive AWS Step Functions management dashboard with the following features:

### ✅ Implemented Features

1. **Dashboard (Home Page)**
   - Real-time metrics and statistics
   - Recent executions list
   - File upload and workflow initiation
   - Live progress monitoring with WebSocket
   - Expandable file sections with output data

2. **Executions Management**
   - List all executions with filtering and search
   - Status filters (RUNNING, SUCCEEDED, FAILED, etc.)
   - Pagination support
   - Bulk selection for comparison
   - Actions: Stop, Retry, Export, View Details

3. **Execution Details Page**
   - Beautiful timeline visualization of execution events
   - Step-by-step execution history
   - Real-time progress tracking
   - Input/Output data viewing
   - **Performance Analysis tab** - Bottleneck detection, state timing breakdown
   - Export to JSON/CSV
   - Stop/Retry controls

4. **Analytics Dashboard** ⭐ NEW
   - Comprehensive metrics and KPIs
   - Time-range selection (1-90 days)
   - Interactive charts (Line, Bar, Pie)
   - Daily trends visualization
   - Success rate tracking
   - Duration statistics
   - Error analysis with grouping
   - Affected executions tracking

5. **Advanced Search** ⭐ NEW
   - Multi-criteria filtering
   - Status, date range, duration filters
   - Content search in input/output
   - Real-time results
   - Applied filters display

6. **Performance Profiler** ⭐ NEW
   - State-by-state performance breakdown
   - Bottleneck identification
   - Execution time percentage analysis
   - Optimization recommendations
   - Visual performance indicators

7. **Visual Workflow Graph**
   - Interactive state machine visualization
   - Click states to view details
   - Color-coded state types
   - Resource and configuration viewing

8. **Execution Comparison**
   - Side-by-side comparison of up to 5 executions
   - Performance metrics
   - Success rate analysis
   - Duration comparisons
   - Direct execution selection interface

9. **State Machine Management**
   - List all state machines
   - View definitions
   - Visual workflow representation
   - JSON definition viewer
   - Download definition as JSON

### 🎨 Pages Structure

```
/                       - Dashboard (Home) with Progress Monitoring
/executions             - Executions List & Management
/executions/:id         - Execution Details with Timeline & Performance
/analytics              - Analytics Dashboard with Charts ⭐ NEW
/search                 - Advanced Search Interface ⭐ NEW
/comparison             - Side-by-side Execution Comparison
/state-machines         - State Machine Management & Visualization
```

## 🚀 Deployment Instructions

### Prerequisites
- Docker Desktop running
- Node.js 16+ (for frontend development)
- Python 3.11+ (backend is containerized)

### Step 1: Start Docker Desktop
Make sure Docker Desktop is running on your machine.

### Step 2: Start All Services

```bash
cd /Users/ranjeetkumar/Workspace/Step_Function_PoC

# Start all services (LocalStack, Backend, Frontend)
docker compose up -d

# Wait for LocalStack to initialize (about 30-40 seconds)
sleep 40

# Check if all services are running
docker compose ps
```

### Step 3: Verify Services

- **LocalStack**: http://localhost:4566
- **Backend API**: http://localhost:8000
- **Frontend**: http://localhost:3000
- **API Docs**: http://localhost:8000/docs

### Step 4: Test the Application

1. Open your browser to http://localhost:3000
2. You should see the Step Functions PoC Dashboard
3. Navigate through the pages using the top menu

## 📋 Available API Endpoints

### Workflow Operations
- `POST /api/workflows/start` - Start a new execution
- `GET /api/workflows/list` - List all executions
- `GET /api/workflows/status/{arn}` - Get execution status
- `POST /api/workflows/stop` - Stop a running execution
- `POST /api/workflows/retry/{arn}` - Retry a failed execution
- `GET /api/workflows/history/{arn}` - Get execution history
- `GET /api/workflows/execution/{arn}/input` - Get execution input
- `GET /api/workflows/execution/{arn}/export` - Export execution data

### State Machine Operations
- `GET /api/workflows/state-machines` - List state machines
- `GET /api/workflows/state-machine/{arn}` - Get state machine details
- `GET /api/workflows/state-machine-for-execution/{arn}` - Get SM for execution

### Analytics & Insights ⭐ NEW
- `GET /api/workflows/analytics/overview?days={days}` - Comprehensive analytics dashboard
- `GET /api/workflows/analytics/errors?limit={limit}` - Error analysis and grouping
- `GET /api/workflows/analytics/performance?execution_arn={arn}` - Performance profiling

### Advanced Search ⭐ NEW
- `GET /api/workflows/search/advanced` - Multi-criteria execution search
  - Parameters: status, start_date, end_date, min_duration, max_duration, search_input, search_output

### Analysis Operations
- `POST /api/workflows/compare-executions` - Compare multiple executions
- `GET /api/workflows/metrics` - Get system metrics

### Progress Monitoring
- `WS /api/ws/execution/{id}` - WebSocket for real-time progress

## 🔧 Development

### Backend Development

```bash
# The backend runs in Docker, but for local development:
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Frontend Development

```bash
cd frontend
npm install
npm start
```

### Redeploy Processor Lambda (After Code Changes)

```bash
./scripts/redeploy-processor.sh
```

Or manually:
```bash
docker compose restart localstack
```

## 📊 Testing the Features

### 1. Start a Workflow
- Go to Dashboard (/)
- Select files to process
- Click "Start Workflow"
- Watch real-time progress with expandable file sections
- View processor and aggregator output data

### 2. View Execution Details
- Go to Executions (/executions)
- Click on any execution ID
- Explore all tabs:
  - **Timeline**: Step-by-step execution events
  - **Input/Output**: Execution data
  - **Progress**: Real-time chunk processing
  - **Performance**: Bottleneck analysis ⭐ NEW

### 3. Analytics Dashboard ⭐ NEW
- Navigate to Analytics (/analytics)
- Select time range (1-90 days)
- Explore 3 tabs:
  - **Overview**: Summary metrics and pie charts
  - **Trends**: Daily execution trends (line/bar charts)
  - **Errors**: Error analysis and affected executions

### 4. Advanced Search ⭐ NEW
- Go to Search page (/search)
- Apply multiple filters:
  - Status, date range, duration
  - Search in input/output content
- View filtered results with active filters display

### 5. Compare Executions
- Go to Executions page OR Comparison page
- Select 2-5 executions using checkboxes
- Click "Compare Selected"
- View side-by-side metrics, performance insights

### 6. View State Machines
- Go to State Machines page
- See visual workflow representation
- Click on states to view details
- Download definition as JSON

### 7. Performance Analysis ⭐ NEW
- Open any completed execution
- Go to "Performance" tab
- Review:
  - State performance breakdown
  - Bottleneck warnings
  - Optimization recommendations

### 8. Stop/Retry Executions
- Find a RUNNING execution
- Click the stop button (⏹️)
- For FAILED executions, click retry button (🔄)

### 9. Export Data
- On execution details page
- Click "Export JSON"
- Data downloads automatically

## 🎨 UI Features

### Dashboard
- 📊 Real-time metrics cards
- 📈 Recent executions list
- 📁 File upload interface
- 🔴 Live progress monitoring
- 📂 Expandable file sections with chunk details

### Executions Page
- 🔍 Search by execution ID
- 🎯 Filter by status
- ✅ Multi-select for comparison
- ⏹️ Stop running executions
- 🔄 Retry failed executions
- 👁️ View detailed timeline
- 📥 Export to JSON/CSV

### Execution Details
- ⏱️ Beautiful timeline with icons
- 📋 Event-by-event breakdown
- 📊 Real-time progress bars
- 🎯 Status cards
- 📁 Input/Output viewers
- 🔄 Automatic refresh

### Workflow Graph
- 🎨 Visual state machine representation
- 🎯 Click-to-view state details
- 🎨 Color-coded state types
- 📜 JSON definition viewer

### Comparison
- 📊 Side-by-side metrics table
- 🏆 Fastest execution highlighting
- 📈 Performance insights
- 💾 Detailed comparison cards

## 🐛 Troubleshooting

### Services Not Starting

```bash
# Check Docker is running
docker ps

# Restart all services
docker compose down
docker compose up -d

# View logs
docker compose logs -f
```

### LocalStack Issues

```bash
# Check LocalStack logs
docker logs llm-orchestration-localstack

# Restart just LocalStack
docker compose restart localstack
```

### Frontend Not Loading

```bash
# Check if frontend is running
docker logs llm-orchestration-frontend

# Rebuild frontend
cd frontend
npm install
docker compose up -d --build frontend
```

### Backend API Errors

```bash
# Check backend logs
docker logs llm-orchestration-backend

# Restart backend
docker compose restart backend
```

## 📝 Architecture

```
┌─────────────────┐
│   React Frontend│
│   (Port 3000)   │
└────────┬────────┘
         │
         │ HTTP/WebSocket
         ▼
┌─────────────────┐
│  FastAPI Backend│
│   (Port 8000)   │
└────────┬────────┘
         │
         │ AWS SDK
         ▼
┌─────────────────┐      ┌─────────────┐
│   LocalStack    │◄────►│  DynamoDB   │
│  Step Functions │      │   Tables    │
│   (Port 4566)   │      │             │
└────────┬────────┘      └─────────────┘
         │
         │ Invokes
         ▼
┌─────────────────┐
│ Lambda Functions│
│  - Chunker      │
│  - Processor    │
│  - Aggregator   │
└─────────────────┘
```

## 🎓 Key Technologies

- **Frontend**: React, React Router, Tailwind CSS, Recharts
- **Backend**: FastAPI, Python 3.11, Boto3
- **Infrastructure**: Docker, LocalStack
- **AWS Services**: Step Functions, Lambda, S3, DynamoDB
- **Real-time**: WebSockets for live progress

## 🔐 Security Notes

This is a **PoC/Development** environment:
- Uses LocalStack (not real AWS)
- Default credentials are hardcoded
- No authentication/authorization
- Not production-ready

For production:
- Use real AWS credentials
- Implement authentication (JWT, OAuth)
- Add authorization checks
- Use environment variables for secrets
- Enable HTTPS
- Add rate limiting

## 📚 Additional Resources

- [AWS Step Functions Documentation](https://docs.aws.amazon.com/step-functions/)
- [LocalStack Documentation](https://docs.localstack.cloud/)
- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [React Router Documentation](https://reactrouter.com/)

## 🎉 Congratulations!

You now have a fully functional AWS Step Functions management dashboard with:
- ✅ Complete execution lifecycle management
- ✅ Real-time progress monitoring
- ✅ Visual workflow representation
- ✅ Execution comparison and analysis
- ✅ Export capabilities
- ✅ Professional UI/UX

Happy exploring! 🚀
