"""Configuration management for the application."""
import os
from typing import Optional
from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    """Application settings."""
    
    # AWS Configuration
    aws_region: str = os.getenv("AWS_REGION", "us-east-1")
    aws_access_key_id: str = os.getenv("AWS_ACCESS_KEY_ID", "test")
    aws_secret_access_key: str = os.getenv("AWS_SECRET_ACCESS_KEY", "test")
    aws_endpoint_url: Optional[str] = os.getenv("AWS_ENDPOINT_URL")
    use_localstack: bool = os.getenv("USE_LOCALSTACK", "true").lower() == "true"
    
    # S3 Configuration
    s3_bucket_name: str = os.getenv("S3_BUCKET_NAME", "document-processing-bucket")
    s3_processed_bucket: str = os.getenv("S3_PROCESSED_BUCKET", "document-processing-results")
    
    # Step Functions Configuration
    state_machine_arn: str = os.getenv(
        "STATE_MACHINE_ARN",
        "arn:aws:states:us-east-1:000000000000:stateMachine:DocumentProcessingWorkflow"
    )
    
    # DynamoDB Configuration
    dynamodb_table_name: str = os.getenv("DYNAMODB_TABLE_NAME", "document-processing-state")
    dynamodb_execution_history_table: str = os.getenv(
        "DYNAMODB_EXECUTION_HISTORY_TABLE",
        "execution-history"
    )
    
    # Lambda Configuration
    lambda_processor_name: str = os.getenv("LAMBDA_PROCESSOR_NAME", "document-processor")
    lambda_chunker_name: str = os.getenv("LAMBDA_CHUNKER_NAME", "document-chunker")
    lambda_aggregator_name: str = os.getenv("LAMBDA_AGGREGATOR_NAME", "result-aggregator")
    
    # Processing Configuration
    max_concurrent_executions: int = int(os.getenv("MAX_CONCURRENT_EXECUTIONS", "10"))
    chunk_size_mb: int = int(os.getenv("CHUNK_SIZE_MB", "5"))
    max_file_size_mb: int = int(os.getenv("MAX_FILE_SIZE_MB", "100"))
    batch_size: int = int(os.getenv("BATCH_SIZE", "50"))
    
    # API Configuration
    backend_port: int = int(os.getenv("BACKEND_PORT", "8000"))
    backend_host: str = os.getenv("BACKEND_HOST", "0.0.0.0")
    frontend_url: str = os.getenv("FRONTEND_URL", "http://localhost:3000")
    
    # WebSocket Configuration
    ws_heartbeat_interval: int = int(os.getenv("WS_HEARTBEAT_INTERVAL", "30"))
    ws_max_connections: int = int(os.getenv("WS_MAX_CONNECTIONS", "100"))
    
    # Simulation Configuration
    min_processing_time: int = int(os.getenv("MIN_PROCESSING_TIME", "10"))
    max_processing_time: int = int(os.getenv("MAX_PROCESSING_TIME", "600"))
    enable_streaming: bool = os.getenv("ENABLE_STREAMING", "true").lower() == "true"
    
    class Config:
        env_file = ".env"
        case_sensitive = False


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()