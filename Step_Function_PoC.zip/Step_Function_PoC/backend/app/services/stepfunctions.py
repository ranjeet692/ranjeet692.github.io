"""Step Functions service client."""
import json
import uuid
from typing import Dict, Any, List, Optional
from datetime import datetime
import boto3
from botocore.exceptions import ClientError
from app.config import get_settings
from app.models.schemas import ExecutionStatus, ExecutionStatusResponse


class StepFunctionsService:
    """Service for interacting with AWS Step Functions."""
    
    def __init__(self):
        """Initialize the Step Functions client."""
        self.settings = get_settings()
        
        client_config = {
            'region_name': self.settings.aws_region,
        }
        
        if self.settings.use_localstack and self.settings.aws_endpoint_url:
            client_config['endpoint_url'] = self.settings.aws_endpoint_url
            client_config['aws_access_key_id'] = self.settings.aws_access_key_id
            client_config['aws_secret_access_key'] = self.settings.aws_secret_access_key
        
        self.client = boto3.client('stepfunctions', **client_config)
    
    async def start_execution(
        self,
        files: List[Dict[str, Any]],
        execution_name: Optional[str] = None,
        max_concurrency: int = 10,
        chunk_size_mb: int = 5
    ) -> Dict[str, Any]:
        """
        Start a new Step Functions execution.
        
        Args:
            files: List of file information dictionaries
            execution_name: Optional custom execution name
            max_concurrency: Maximum concurrent file processing
            chunk_size_mb: Chunk size in megabytes
        
        Returns:
            Execution details including ARN and execution ID
        """
        if not execution_name:
            execution_name = f"exec-{uuid.uuid4()}"
        
        # Prepare input for Step Functions
        execution_input = {
            'files': files,
            'config': {
                'max_concurrency': max_concurrency,
                'chunk_size': chunk_size_mb * 1024 * 1024,  # Convert to bytes
                'timestamp': datetime.utcnow().isoformat()
            }
        }
        
        try:
            response = self.client.start_execution(
                stateMachineArn=self.settings.state_machine_arn,
                name=execution_name,
                input=json.dumps(execution_input)
            )
            
            return {
                'execution_arn': response['executionArn'],
                'execution_id': execution_name,
                'start_time': response['startDate'],
                'status': 'RUNNING'
            }
        except ClientError as e:
            raise Exception(f"Failed to start execution: {str(e)}")
    
    async def describe_execution(self, execution_arn: str) -> ExecutionStatusResponse:
        """
        Get execution status and details.
        
        Args:
            execution_arn: ARN of the execution
        
        Returns:
            Execution status response
        """
        try:
            response = self.client.describe_execution(executionArn=execution_arn)
            
            execution_id = execution_arn.split(':')[-1]
            
            return ExecutionStatusResponse(
                execution_arn=response['executionArn'],
                execution_id=execution_id,
                status=ExecutionStatus(response['status']),
                start_time=response['startDate'],
                stop_time=response.get('stopDate'),
                input=json.loads(response.get('input', '{}')),
                output=json.loads(response.get('output', '{}')) if response.get('output') else None,
                error=response.get('error')
            )
        except ClientError as e:
            raise Exception(f"Failed to describe execution: {str(e)}")
    
    async def stop_execution(
        self,
        execution_arn: str,
        error: str = "Execution stopped by user",
        cause: str = "User requested termination"
    ) -> Dict[str, Any]:
        """
        Stop a running execution.
        
        Args:
            execution_arn: ARN of the execution to stop
            error: Error message
            cause: Cause of termination
        
        Returns:
            Stop execution response
        """
        try:
            response = self.client.stop_execution(
                executionArn=execution_arn,
                error=error,
                cause=cause
            )
            return {
                'stop_time': response['stopDate'],
                'status': 'ABORTED'
            }
        except ClientError as e:
            raise Exception(f"Failed to stop execution: {str(e)}")
    
    async def list_executions(
        self,
        status_filter: Optional[str] = None,
        max_results: int = 100
    ) -> List[Dict[str, Any]]:
        """
        List executions for the state machine.
        
        Args:
            status_filter: Optional status filter (RUNNING, SUCCEEDED, FAILED, etc.)
            max_results: Maximum number of results
        
        Returns:
            List of execution summaries
        """
        try:
            params = {
                'stateMachineArn': self.settings.state_machine_arn,
                'maxResults': max_results
            }
            
            if status_filter:
                params['statusFilter'] = status_filter
            
            response = self.client.list_executions(**params)
            
            return response.get('executions', [])
        except ClientError as e:
            raise Exception(f"Failed to list executions: {str(e)}")
    
    async def get_execution_history(
        self,
        execution_arn: str,
        max_results: int = 100
    ) -> List[Dict[str, Any]]:
        """
        Get execution history events.
        
        Args:
            execution_arn: ARN of the execution
            max_results: Maximum number of events
        
        Returns:
            List of execution history events
        """
        try:
            response = self.client.get_execution_history(
                executionArn=execution_arn,
                maxResults=max_results,
                reverseOrder=False
            )
            
            return response.get('events', [])
        except ClientError as e:
            raise Exception(f"Failed to get execution history: {str(e)}")
    
    async def send_task_success(
        self,
        task_token: str,
        output: Dict[str, Any]
    ) -> None:
        """
        Send task success for callback pattern.
        
        Args:
            task_token: Task token from Step Functions
            output: Task output
        """
        try:
            self.client.send_task_success(
                taskToken=task_token,
                output=json.dumps(output)
            )
        except ClientError as e:
            raise Exception(f"Failed to send task success: {str(e)}")
    
    async def send_task_failure(
        self,
        task_token: str,
        error: str,
        cause: str
    ) -> None:
        """
        Send task failure for callback pattern.
        
        Args:
            task_token: Task token from Step Functions
            error: Error code
            cause: Error cause
        """
        try:
            self.client.send_task_failure(
                taskToken=task_token,
                error=error,
                cause=cause
            )
        except ClientError as e:
            raise Exception(f"Failed to send task failure: {str(e)}")