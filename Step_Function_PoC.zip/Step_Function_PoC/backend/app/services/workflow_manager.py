"""Workflow Manager for deploying and managing multiple Step Functions workflows."""
import json
import os
from pathlib import Path
from typing import Dict, List, Optional
import boto3
from botocore.exceptions import ClientError


class WorkflowManager:
    """Manages multiple Step Functions workflow definitions."""

    def __init__(self):
        """Initialize the Workflow Manager."""
        self.sfn_client = boto3.client(
            'stepfunctions',
            endpoint_url='http://localstack:4566',
            region_name='us-east-1',
            aws_access_key_id='test',
            aws_secret_access_key='test'
        )
        self.workflows_dir = Path(__file__).parent.parent.parent / 'stepfunctions' / 'workflows'
        self.role_arn = 'arn:aws:iam::000000000000:role/stepfunctions-execution-role'

    def get_available_workflows(self) -> List[Dict[str, str]]:
        """
        Get list of available workflow definitions.

        Returns:
            List of workflow metadata
        """
        workflows = []

        # Add default workflow
        workflows.append({
            'id': 'document-processing',
            'name': 'Document Processing (Default)',
            'description': 'Standard document processing with chunking and parallel processing',
            'file': 'workflow.json',
            'category': 'default',
            'complexity': 'medium',
            'features': ['Map', 'Parallel', 'Error Handling']
        })

        # Scan workflows directory for additional workflows
        if self.workflows_dir.exists():
            for workflow_file in self.workflows_dir.glob('*.json'):
                workflow_id = workflow_file.stem

                # Read workflow to get comment
                try:
                    with open(workflow_file, 'r') as f:
                        workflow_def = json.load(f)
                        description = workflow_def.get('Comment', 'No description')
                except Exception as e:
                    description = f'Error reading workflow: {str(e)}'

                # Categorize workflows
                category = 'advanced'
                complexity = 'high'
                features = []

                if 'parallel' in workflow_id.lower():
                    category = 'parallel'
                    features = ['Parallel', 'Multiple Branches', 'Error Handling']
                elif 'conditional' in workflow_id.lower() or 'choice' in workflow_id.lower():
                    category = 'conditional'
                    features = ['Choice', 'Conditional Logic', 'Multiple Paths']
                elif 'batch' in workflow_id.lower() or 'etl' in workflow_id.lower():
                    category = 'batch'
                    features = ['Map', 'Batch Processing', 'ETL', 'Comprehensive Error Handling']
                elif 'wait' in workflow_id.lower() or 'callback' in workflow_id.lower():
                    category = 'timing'
                    features = ['Wait', 'Timeout', 'Dynamic Scheduling', 'Heartbeat']
                elif 'activity' in workflow_id.lower():
                    category = 'activity'
                    features = ['Activity Tasks', 'Human-in-the-Loop', 'Manual Approval', 'Escalation']
                elif 'hr' in workflow_id.lower() or 'resume' in workflow_id.lower():
                    category = 'ai-agents'
                    features = ['Multi-Agent', 'NER', 'PII Detection', 'OCR', 'AI Matching', 'File Processing']
                elif 'distributed' in workflow_id.lower():
                    category = 'distributed'
                    features = ['Distributed Map', 'S3 ItemReader', 'Massive Scale', 'ResultWriter', 'Batch Processing', 'Chunking']

                workflows.append({
                    'id': workflow_id,
                    'name': workflow_id.replace('_', ' ').title(),
                    'description': description,
                    'file': workflow_file.name,
                    'category': category,
                    'complexity': complexity,
                    'features': features
                })

        return workflows

    def get_workflow_definition(self, workflow_id: str) -> Optional[Dict]:
        """
        Get workflow definition by ID.

        Args:
            workflow_id: Workflow identifier

        Returns:
            Workflow definition dict or None
        """
        if workflow_id == 'document-processing':
            # Default workflow
            workflow_path = Path(__file__).parent.parent.parent / 'stepfunctions' / 'workflow.json'
        else:
            # Custom workflow from workflows directory
            workflow_path = self.workflows_dir / f'{workflow_id}.json'

        if not workflow_path.exists():
            return None

        try:
            with open(workflow_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error reading workflow {workflow_id}: {e}")
            return None

    def deploy_workflow(self, workflow_id: str, name: Optional[str] = None) -> Dict:
        """
        Deploy a workflow to Step Functions.

        Args:
            workflow_id: Workflow identifier
            name: Optional custom name for the state machine

        Returns:
            Deployment result with ARN
        """
        workflow_def = self.get_workflow_definition(workflow_id)
        if not workflow_def:
            raise ValueError(f"Workflow {workflow_id} not found")

        # Generate state machine name
        if not name:
            name = workflow_id.replace('_', '-').title() + 'Workflow'

        # Convert definition to string
        definition_str = json.dumps(workflow_def)

        try:
            # Check if state machine already exists
            try:
                list_response = self.sfn_client.list_state_machines()
                existing = next(
                    (sm for sm in list_response.get('stateMachines', [])
                     if sm['name'] == name),
                    None
                )

                if existing:
                    # Update existing state machine
                    response = self.sfn_client.update_state_machine(
                        stateMachineArn=existing['stateMachineArn'],
                        definition=definition_str
                    )
                    return {
                        'status': 'updated',
                        'stateMachineArn': existing['stateMachineArn'],
                        'name': name,
                        'updateDate': response.get('updateDate')
                    }
            except ClientError:
                pass

            # Create new state machine
            response = self.sfn_client.create_state_machine(
                name=name,
                definition=definition_str,
                roleArn=self.role_arn,
                type='STANDARD'
            )

            return {
                'status': 'created',
                'stateMachineArn': response['stateMachineArn'],
                'name': name,
                'creationDate': response.get('creationDate')
            }

        except ClientError as e:
            raise Exception(f"Failed to deploy workflow: {str(e)}")

    def start_workflow_execution(
        self,
        workflow_id: str,
        input_data: Dict,
        execution_name: Optional[str] = None
    ) -> Dict:
        """
        Start execution of a specific workflow.

        Args:
            workflow_id: Workflow identifier
            input_data: Input data for execution
            execution_name: Optional execution name

        Returns:
            Execution details
        """
        # First ensure workflow is deployed
        deployment = self.deploy_workflow(workflow_id)
        state_machine_arn = deployment['stateMachineArn']

        # Generate execution name if not provided
        if not execution_name:
            import time
            execution_name = f"{workflow_id}-{int(time.time())}"

        # Start execution
        try:
            response = self.sfn_client.start_execution(
                stateMachineArn=state_machine_arn,
                name=execution_name,
                input=json.dumps(input_data)
            )

            return {
                'executionArn': response['executionArn'],
                'executionId': execution_name,
                'startDate': response.get('startDate'),
                'workflowId': workflow_id,
                'stateMachineArn': state_machine_arn
            }

        except ClientError as e:
            raise Exception(f"Failed to start workflow execution: {str(e)}")

    def get_workflow_schema(self, workflow_id: str) -> Dict:
        """
        Get input schema/requirements for a workflow.

        Args:
            workflow_id: Workflow identifier

        Returns:
            Schema definition
        """
        # Define schemas for each workflow type
        schemas = {
            'document-processing': {
                'required': ['files'],
                'properties': {
                    'files': {
                        'type': 'array',
                        'items': {
                            'type': 'object',
                            'properties': {
                                'file_key': {'type': 'string'},
                                'bucket': {'type': 'string'}
                            }
                        }
                    }
                },
                'example': {
                    'files': [
                        {
                            'file_key': 'documents/sample.pdf',
                            'bucket': 'my-bucket'
                        }
                    ]
                }
            },
            'parallel_processing': {
                'required': ['files'],
                'properties': {
                    'files': {
                        'type': 'array',
                        'items': {
                            'type': 'object',
                            'properties': {
                                'file_key': {'type': 'string', 'description': 'S3 key or file path'},
                                'bucket': {'type': 'string', 'description': 'S3 bucket name'}
                            }
                        },
                        'description': 'Files to process with multiple extraction agents (text, NER, PII)'
                    }
                },
                'example': {
                    'files': [
                        {
                            'file_key': 'documents/contract.pdf',
                            'bucket': 'my-documents'
                        },
                        {
                            'file_key': 'documents/invoice.pdf',
                            'bucket': 'my-documents'
                        }
                    ]
                }
            },
            'conditional_workflow': {
                'required': ['file'],
                'properties': {
                    'file': {
                        'type': 'object',
                        'properties': {
                            'file_key': {'type': 'string'},
                            'bucket': {'type': 'string'}
                        },
                        'description': 'File to process - will be routed based on type (PDF, Image, DOCX, etc.)'
                    },
                    'priority': {'type': 'string', 'enum': ['low', 'medium', 'high'], 'description': 'Processing priority'},
                    'qualityScore': {'type': 'number', 'description': 'Expected quality threshold'}
                },
                'example': {
                    'file': {
                        'file_key': 'documents/scanned-invoice.pdf',
                        'bucket': 'my-documents'
                    },
                    'priority': 'high',
                    'qualityScore': 0.85
                }
            },
            'batch_etl_workflow': {
                'required': ['dataSources'],
                'properties': {
                    'dataSources': {
                        'type': 'array',
                        'items': {'type': 'object'}
                    },
                    'extractConfig': {'type': 'object'},
                    'transformRules': {'type': 'object'}
                },
                'example': {
                    'dataSources': [
                        {'source': 'db1', 'table': 'users'},
                        {'source': 'db2', 'table': 'orders'}
                    ],
                    'extractConfig': {'batchSize': 1000},
                    'transformRules': {'lowercase': True}
                }
            },
            'wait_and_callback_workflow': {
                'required': [],
                'properties': {
                    'retryCount': {'type': 'number', 'default': 0},
                    'processingTime': {'type': 'number'},
                    'optimizationWaitTime': {'type': 'number'},
                    'scheduledTimestamp': {'type': 'string'}
                },
                'example': {
                    'retryCount': 0,
                    'processingTime': 45,
                    'optimizationWaitTime': 10,
                    'scheduledTimestamp': '2025-01-01T12:00:00Z'
                }
            },
            'activity_workflow': {
                'required': [],
                'properties': {
                    'requestId': {'type': 'string'},
                    'requestType': {'type': 'string'},
                    'priority': {'type': 'string', 'enum': ['low', 'medium', 'high', 'critical']},
                    'reworkCount': {'type': 'number', 'default': 0},
                    'timestamp': {'type': 'string'}
                },
                'example': {
                    'requestId': 'REQ-2025-001',
                    'requestType': 'document_approval',
                    'priority': 'high',
                    'reworkCount': 0,
                    'timestamp': '2025-01-08T10:00:00Z'
                }
            },
            'hr_resume_screening_workflow': {
                'required': ['jobDescription', 'resumes'],
                'properties': {
                    'jobDescription': {
                        'type': 'object',
                        'properties': {
                            'file_key': {'type': 'string'},
                            'bucket': {'type': 'string'}
                        },
                        'description': 'Job description file (PDF, DOCX, or TXT)'
                    },
                    'resumes': {
                        'type': 'array',
                        'items': {
                            'type': 'object',
                            'properties': {
                                'file_key': {'type': 'string'},
                                'bucket': {'type': 'string'},
                                'candidate_id': {'type': 'string'}
                            }
                        },
                        'description': 'Array of resume files to screen'
                    },
                    'topCandidatesCount': {'type': 'number', 'default': 10, 'description': 'Number of top candidates to shortlist'},
                    'notificationEmails': {
                        'type': 'array',
                        'items': {'type': 'string'},
                        'description': 'Email addresses to notify with results'
                    }
                },
                'example': {
                    'jobDescription': {
                        'file_key': 'jobs/senior-software-engineer.pdf',
                        'bucket': 'hr-documents'
                    },
                    'resumes': [
                        {
                            'file_key': 'resumes/2025/candidate_001.pdf',
                            'bucket': 'hr-documents',
                            'candidate_id': 'CAND-001'
                        },
                        {
                            'file_key': 'resumes/2025/candidate_002.pdf',
                            'bucket': 'hr-documents',
                            'candidate_id': 'CAND-002'
                        },
                        {
                            'file_key': 'resumes/2025/candidate_003.pdf',
                            'bucket': 'hr-documents',
                            'candidate_id': 'CAND-003'
                        }
                    ],
                    'topCandidatesCount': 10,
                    'notificationEmails': ['hr@company.com', 'hiring-manager@company.com']
                }
            },
            'distributed_map_batch_workflow': {
                'required': ['manifestBucket', 'manifestKey', 'resultsBucket'],
                'properties': {
                    'manifestBucket': {
                        'type': 'string',
                        'description': 'S3 bucket containing the manifest file'
                    },
                    'manifestKey': {
                        'type': 'string',
                        'description': 'S3 key of CSV manifest file with columns: bucket, file_key, file_id'
                    },
                    'resultsBucket': {
                        'type': 'string',
                        'description': 'S3 bucket to store processing results'
                    },
                    'expectedFileCount': {
                        'type': 'number',
                        'description': 'Expected number of files in manifest for validation'
                    },
                    'processingConfig': {
                        'type': 'object',
                        'properties': {
                            'enableOCR': {'type': 'boolean', 'default': True},
                            'enableNER': {'type': 'boolean', 'default': True},
                            'enablePII': {'type': 'boolean', 'default': True},
                            'chunkLargeFiles': {'type': 'boolean', 'default': True},
                            'chunkSizeMB': {'type': 'number', 'default': 50}
                        },
                        'description': 'Configuration for multi-agent processing'
                    },
                    'notificationEmails': {
                        'type': 'array',
                        'items': {'type': 'string'},
                        'description': 'Email addresses to notify on completion'
                    }
                },
                'example': {
                    'manifestBucket': 'batch-processing',
                    'manifestKey': 'manifests/batch-2025-01/files-manifest.csv',
                    'resultsBucket': 'batch-processing-results',
                    'expectedFileCount': 50000,
                    'processingConfig': {
                        'enableOCR': True,
                        'enableNER': True,
                        'enablePII': True,
                        'chunkLargeFiles': True,
                        'chunkSizeMB': 50
                    },
                    'notificationEmails': ['data-team@company.com', 'ops@company.com']
                }
            },
            'distributed_map_batch_workflow_localstack': {
                'required': ['files'],
                'properties': {
                    'files': {
                        'type': 'array',
                        'items': {
                            'type': 'object',
                            'properties': {
                                'bucket': {'type': 'string'},
                                'file_key': {'type': 'string'},
                                'file_id': {'type': 'string'}
                            }
                        },
                        'description': 'Array of files to process in batch'
                    },
                    'expectedFileCount': {
                        'type': 'number',
                        'description': 'Expected number of files for validation'
                    },
                    'processingConfig': {
                        'type': 'object',
                        'properties': {
                            'enableOCR': {'type': 'boolean', 'default': True},
                            'enableNER': {'type': 'boolean', 'default': True},
                            'enablePII': {'type': 'boolean', 'default': True}
                        },
                        'description': 'Configuration for multi-agent processing'
                    },
                    'notificationEmails': {
                        'type': 'array',
                        'items': {'type': 'string'},
                        'description': 'Email addresses to notify on completion'
                    }
                },
                'example': {
                    'files': [
                        {
                            'bucket': 'test-batch-processing',
                            'file_key': 'test-files/file_000001.pdf',
                            'file_id': 'FILE-000001'
                        },
                        {
                            'bucket': 'test-batch-processing',
                            'file_key': 'test-files/file_000002.pdf',
                            'file_id': 'FILE-000002'
                        },
                        {
                            'bucket': 'test-batch-processing',
                            'file_key': 'test-files/file_000003.pdf',
                            'file_id': 'FILE-000003'
                        }
                    ],
                    'expectedFileCount': 100,
                    'processingConfig': {
                        'enableOCR': True,
                        'enableNER': True,
                        'enablePII': True
                    },
                    'notificationEmails': ['test@example.com']
                }
            }
        }

        return schemas.get(workflow_id, {
            'required': [],
            'properties': {},
            'example': {}
        })
