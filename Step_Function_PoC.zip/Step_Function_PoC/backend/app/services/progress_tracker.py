"""Progress tracking service for real-time workflow monitoring."""
import boto3
from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta
from botocore.exceptions import ClientError
from app.models.progress import (
    ProgressEvent,
    ExecutionProgress,
    ProgressEventType,
    ProgressUpdateRequest
)


class ProgressTracker:
    """Service for tracking and broadcasting workflow execution progress."""

    def __init__(self):
        """Initialize the progress tracker."""
        # DynamoDB client for storing progress
        self.dynamodb = boto3.client(
            'dynamodb',
            endpoint_url='http://localstack:4566',
            region_name='us-east-1',
            aws_access_key_id='test',
            aws_secret_access_key='test'
        )

        # Table names
        self.progress_table = 'ExecutionProgress'
        self.events_table = 'ProgressEvents'

        # Initialize tables
        self._ensure_tables_exist()

    def _ensure_tables_exist(self):
        """Create DynamoDB tables if they don't exist."""
        try:
            # Create ExecutionProgress table
            try:
                self.dynamodb.create_table(
                    TableName=self.progress_table,
                    KeySchema=[
                        {'AttributeName': 'execution_id', 'KeyType': 'HASH'}
                    ],
                    AttributeDefinitions=[
                        {'AttributeName': 'execution_id', 'AttributeType': 'S'}
                    ],
                    BillingMode='PAY_PER_REQUEST'
                )
                print(f"Created table: {self.progress_table}")
            except ClientError as e:
                if e.response['Error']['Code'] != 'ResourceInUseException':
                    raise

            # Create ProgressEvents table
            try:
                self.dynamodb.create_table(
                    TableName=self.events_table,
                    KeySchema=[
                        {'AttributeName': 'execution_id', 'KeyType': 'HASH'},
                        {'AttributeName': 'timestamp', 'KeyType': 'RANGE'}
                    ],
                    AttributeDefinitions=[
                        {'AttributeName': 'execution_id', 'AttributeType': 'S'},
                        {'AttributeName': 'timestamp', 'AttributeType': 'S'}
                    ],
                    BillingMode='PAY_PER_REQUEST'
                )
                print(f"Created table: {self.events_table}")
            except ClientError as e:
                if e.response['Error']['Code'] != 'ResourceInUseException':
                    raise

        except Exception as e:
            print(f"Error creating tables: {e}")

    async def initialize_execution(
        self,
        execution_id: str,
        execution_arn: str,
        workflow_id: str,
        total_items: int = 0
    ) -> ExecutionProgress:
        """Initialize progress tracking for a new execution."""
        now = datetime.utcnow()

        progress = ExecutionProgress(
            execution_id=execution_id,
            execution_arn=execution_arn,
            workflow_id=workflow_id,
            status='RUNNING',
            start_time=now,
            total_items=total_items,
            completed_items=0,
            failed_items=0,
            progress_percentage=0.0,
            last_updated=now
        )

        # Store in DynamoDB
        try:
            self.dynamodb.put_item(
                TableName=self.progress_table,
                Item={
                    'execution_id': {'S': execution_id},
                    'execution_arn': {'S': execution_arn},
                    'workflow_id': {'S': workflow_id},
                    'status': {'S': 'RUNNING'},
                    'start_time': {'S': now.isoformat()},
                    'total_items': {'N': str(total_items)},
                    'completed_items': {'N': '0'},
                    'failed_items': {'N': '0'},
                    'progress_percentage': {'N': '0.0'},
                    'last_updated': {'S': now.isoformat()}
                }
            )
        except Exception as e:
            print(f"Error storing progress: {e}")

        # Emit event
        await self.emit_event(
            execution_id=execution_id,
            event_type=ProgressEventType.EXECUTION_STARTED,
            message=f"Execution started: {execution_id}",
            metadata={'total_items': total_items}
        )

        return progress

    async def update_progress(
        self,
        request: ProgressUpdateRequest
    ) -> ExecutionProgress:
        """Update execution progress."""
        execution_id = request.execution_id

        # Get current progress
        progress = await self.get_progress(execution_id)

        if not progress:
            raise ValueError(f"Execution {execution_id} not found")

        # Update counters
        if request.items_completed is not None:
            progress.completed_items += request.items_completed
        if request.items_failed is not None:
            progress.failed_items += request.items_failed

        # Update current state
        if request.state_name:
            progress.current_state = request.state_name
        if request.batch_id:
            progress.current_batch = int(request.batch_id) if request.batch_id.isdigit() else None

        # Calculate progress percentage
        if progress.total_items > 0:
            progress.progress_percentage = (
                (progress.completed_items + progress.failed_items) / progress.total_items * 100
            )

        # Calculate performance metrics
        elapsed = (datetime.utcnow() - progress.start_time).total_seconds()
        if elapsed > 0:
            progress.items_per_second = progress.completed_items / elapsed

            # Estimate completion time
            if progress.items_per_second > 0:
                remaining_items = progress.total_items - (progress.completed_items + progress.failed_items)
                remaining_seconds = remaining_items / progress.items_per_second
                progress.estimated_completion_time = datetime.utcnow() + timedelta(seconds=remaining_seconds)

        # Track file-level progress
        if request.file_id:
            if request.event_type == ProgressEventType.FILE_COMPLETED:
                if request.file_id not in progress.files_processed:
                    progress.files_processed.append(request.file_id)
            elif request.event_type == ProgressEventType.FILE_FAILED:
                if request.file_id not in progress.files_failed:
                    progress.files_failed.append(request.file_id)

        progress.last_updated = datetime.utcnow()

        # Store updated progress
        try:
            self.dynamodb.update_item(
                TableName=self.progress_table,
                Key={'execution_id': {'S': execution_id}},
                UpdateExpression='SET completed_items = :c, failed_items = :f, '
                                'progress_percentage = :p, current_state = :s, '
                                'items_per_second = :ips, last_updated = :lu',
                ExpressionAttributeValues={
                    ':c': {'N': str(progress.completed_items)},
                    ':f': {'N': str(progress.failed_items)},
                    ':p': {'N': str(progress.progress_percentage)},
                    ':s': {'S': progress.current_state or ''},
                    ':ips': {'N': str(progress.items_per_second)},
                    ':lu': {'S': progress.last_updated.isoformat()}
                }
            )
        except Exception as e:
            print(f"Error updating progress: {e}")

        # Emit progress event
        await self.emit_event(
            execution_id=execution_id,
            event_type=request.event_type,
            state_name=request.state_name,
            file_id=request.file_id,
            batch_id=request.batch_id,
            message=request.message,
            metadata=request.metadata,
            progress_percentage=progress.progress_percentage
        )

        return progress

    async def get_progress(self, execution_id: str) -> Optional[ExecutionProgress]:
        """Get current progress for an execution."""
        try:
            response = self.dynamodb.get_item(
                TableName=self.progress_table,
                Key={'execution_id': {'S': execution_id}}
            )

            if 'Item' not in response:
                return None

            item = response['Item']

            # Parse DynamoDB item
            progress = ExecutionProgress(
                execution_id=item['execution_id']['S'],
                execution_arn=item['execution_arn']['S'],
                workflow_id=item['workflow_id']['S'],
                status=item['status']['S'],
                start_time=datetime.fromisoformat(item['start_time']['S']),
                total_items=int(item['total_items']['N']),
                completed_items=int(item['completed_items']['N']),
                failed_items=int(item['failed_items']['N']),
                progress_percentage=float(item['progress_percentage']['N']),
                current_state=item.get('current_state', {}).get('S'),
                items_per_second=float(item.get('items_per_second', {}).get('N', '0')),
                last_updated=datetime.fromisoformat(item['last_updated']['S'])
            )

            return progress

        except Exception as e:
            print(f"Error getting progress: {e}")
            return None

    async def emit_event(
        self,
        execution_id: str,
        event_type: ProgressEventType,
        state_name: Optional[str] = None,
        file_id: Optional[str] = None,
        batch_id: Optional[str] = None,
        message: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        progress_percentage: Optional[float] = None
    ):
        """Emit a progress event."""
        now = datetime.utcnow()

        event = ProgressEvent(
            execution_id=execution_id,
            event_type=event_type,
            timestamp=now,
            state_name=state_name,
            file_id=file_id,
            batch_id=batch_id,
            message=message,
            metadata=metadata,
            progress_percentage=progress_percentage
        )

        # Store event
        try:
            item = {
                'execution_id': {'S': execution_id},
                'timestamp': {'S': now.isoformat()},
                'event_type': {'S': event_type.value},
            }

            if state_name:
                item['state_name'] = {'S': state_name}
            if file_id:
                item['file_id'] = {'S': file_id}
            if batch_id:
                item['batch_id'] = {'S': batch_id}
            if message:
                item['message'] = {'S': message}
            if progress_percentage is not None:
                item['progress_percentage'] = {'N': str(progress_percentage)}

            self.dynamodb.put_item(
                TableName=self.events_table,
                Item=item
            )
        except Exception as e:
            print(f"Error storing event: {e}")

        # TODO: Broadcast to WebSocket subscribers
        # This would integrate with API Gateway WebSocket API
        # For now, events are stored in DynamoDB

        return event

    async def get_recent_events(
        self,
        execution_id: str,
        limit: int = 50
    ) -> List[ProgressEvent]:
        """Get recent progress events for an execution."""
        try:
            response = self.dynamodb.query(
                TableName=self.events_table,
                KeyConditionExpression='execution_id = :eid',
                ExpressionAttributeValues={
                    ':eid': {'S': execution_id}
                },
                ScanIndexForward=False,  # Descending order (newest first)
                Limit=limit
            )

            events = []
            for item in response.get('Items', []):
                event = ProgressEvent(
                    execution_id=item['execution_id']['S'],
                    event_type=ProgressEventType(item['event_type']['S']),
                    timestamp=datetime.fromisoformat(item['timestamp']['S']),
                    state_name=item.get('state_name', {}).get('S'),
                    file_id=item.get('file_id', {}).get('S'),
                    batch_id=item.get('batch_id', {}).get('S'),
                    message=item.get('message', {}).get('S'),
                    progress_percentage=float(item.get('progress_percentage', {}).get('N', '0'))
                )
                events.append(event)

            return events

        except Exception as e:
            print(f"Error getting events: {e}")
            return []

    async def complete_execution(
        self,
        execution_id: str,
        status: str = 'SUCCEEDED'
    ):
        """Mark execution as completed."""
        now = datetime.utcnow()

        try:
            self.dynamodb.update_item(
                TableName=self.progress_table,
                Key={'execution_id': {'S': execution_id}},
                UpdateExpression='SET #status = :s, end_time = :et, last_updated = :lu',
                ExpressionAttributeNames={'#status': 'status'},
                ExpressionAttributeValues={
                    ':s': {'S': status},
                    ':et': {'S': now.isoformat()},
                    ':lu': {'S': now.isoformat()}
                }
            )
        except Exception as e:
            print(f"Error completing execution: {e}")

        # Emit completion event
        event_type = (
            ProgressEventType.EXECUTION_COMPLETED if status == 'SUCCEEDED'
            else ProgressEventType.EXECUTION_FAILED
        )

        await self.emit_event(
            execution_id=execution_id,
            event_type=event_type,
            message=f"Execution {status.lower()}: {execution_id}"
        )
