"""Multipart file upload service for large files."""
import boto3
from typing import Dict, Any, Optional
from botocore.exceptions import ClientError


class MultipartUploader:
    """Service for handling multipart file uploads to S3."""

    def __init__(self):
        """Initialize the multipart uploader."""
        self.s3_client = boto3.client(
            's3',
            endpoint_url='http://localstack:4566',
            region_name='us-east-1',
            aws_access_key_id='test',
            aws_secret_access_key='test'
        )

        # Minimum part size: 5MB (AWS requirement)
        self.min_part_size = 5 * 1024 * 1024
        # Maximum part size: 100MB (for efficient uploads)
        self.max_part_size = 100 * 1024 * 1024

    def initiate_multipart_upload(
        self,
        bucket: str,
        key: str,
        content_type: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """
        Initiate a multipart upload.

        Args:
            bucket: S3 bucket name
            key: S3 object key
            content_type: Content type of the file
            metadata: Optional metadata to attach

        Returns:
            Upload details including upload_id
        """
        try:
            extra_args = {}
            if content_type:
                extra_args['ContentType'] = content_type
            if metadata:
                extra_args['Metadata'] = metadata

            response = self.s3_client.create_multipart_upload(
                Bucket=bucket,
                Key=key,
                **extra_args
            )

            return {
                'upload_id': response['UploadId'],
                'bucket': bucket,
                'key': key,
                'status': 'initiated'
            }

        except ClientError as e:
            raise Exception(f"Failed to initiate multipart upload: {str(e)}")

    def generate_presigned_upload_part_url(
        self,
        bucket: str,
        key: str,
        upload_id: str,
        part_number: int,
        expiration: int = 3600
    ) -> str:
        """
        Generate presigned URL for uploading a part.

        Args:
            bucket: S3 bucket name
            key: S3 object key
            upload_id: Multipart upload ID
            part_number: Part number (1-indexed)
            expiration: URL expiration in seconds

        Returns:
            Presigned URL
        """
        try:
            url = self.s3_client.generate_presigned_url(
                'upload_part',
                Params={
                    'Bucket': bucket,
                    'Key': key,
                    'UploadId': upload_id,
                    'PartNumber': part_number
                },
                ExpiresIn=expiration
            )
            return url

        except ClientError as e:
            raise Exception(f"Failed to generate presigned URL: {str(e)}")

    def upload_part(
        self,
        bucket: str,
        key: str,
        upload_id: str,
        part_number: int,
        data: bytes
    ) -> Dict[str, Any]:
        """
        Upload a single part.

        Args:
            bucket: S3 bucket name
            key: S3 object key
            upload_id: Multipart upload ID
            part_number: Part number (1-indexed)
            data: Part data

        Returns:
            Part details including ETag
        """
        try:
            response = self.s3_client.upload_part(
                Bucket=bucket,
                Key=key,
                UploadId=upload_id,
                PartNumber=part_number,
                Body=data
            )

            return {
                'part_number': part_number,
                'etag': response['ETag'],
                'size': len(data)
            }

        except ClientError as e:
            raise Exception(f"Failed to upload part: {str(e)}")

    def complete_multipart_upload(
        self,
        bucket: str,
        key: str,
        upload_id: str,
        parts: list
    ) -> Dict[str, Any]:
        """
        Complete a multipart upload.

        Args:
            bucket: S3 bucket name
            key: S3 object key
            upload_id: Multipart upload ID
            parts: List of uploaded parts with ETag

        Returns:
            Upload completion details
        """
        try:
            # Format parts for completion
            parts_list = [
                {'PartNumber': part['part_number'], 'ETag': part['etag']}
                for part in sorted(parts, key=lambda x: x['part_number'])
            ]

            response = self.s3_client.complete_multipart_upload(
                Bucket=bucket,
                Key=key,
                UploadId=upload_id,
                MultipartUpload={'Parts': parts_list}
            )

            return {
                'bucket': bucket,
                'key': key,
                'location': response.get('Location'),
                'etag': response.get('ETag'),
                'status': 'completed'
            }

        except ClientError as e:
            raise Exception(f"Failed to complete multipart upload: {str(e)}")

    def abort_multipart_upload(
        self,
        bucket: str,
        key: str,
        upload_id: str
    ) -> Dict[str, Any]:
        """
        Abort a multipart upload.

        Args:
            bucket: S3 bucket name
            key: S3 object key
            upload_id: Multipart upload ID

        Returns:
            Abort confirmation
        """
        try:
            self.s3_client.abort_multipart_upload(
                Bucket=bucket,
                Key=key,
                UploadId=upload_id
            )

            return {
                'bucket': bucket,
                'key': key,
                'upload_id': upload_id,
                'status': 'aborted'
            }

        except ClientError as e:
            raise Exception(f"Failed to abort multipart upload: {str(e)}")

    def calculate_parts(
        self,
        file_size: int,
        part_size: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Calculate optimal part configuration for a file.

        Args:
            file_size: Total file size in bytes
            part_size: Desired part size (optional)

        Returns:
            Part configuration
        """
        # Use provided part size or calculate optimal
        if part_size is None:
            # For files < 100MB, use single part
            if file_size < self.max_part_size:
                part_size = file_size
            else:
                # Calculate part size to stay under 10,000 parts (AWS limit)
                part_size = max(self.min_part_size, file_size // 9999)

        # Ensure part size meets AWS requirements
        if part_size < self.min_part_size and file_size > self.min_part_size:
            part_size = self.min_part_size

        num_parts = (file_size + part_size - 1) // part_size

        return {
            'file_size': file_size,
            'part_size': part_size,
            'num_parts': num_parts,
            'parts': [
                {
                    'part_number': i + 1,
                    'start_byte': i * part_size,
                    'end_byte': min((i + 1) * part_size, file_size) - 1,
                    'size': min(part_size, file_size - i * part_size)
                }
                for i in range(num_parts)
            ]
        }
