"""DynamoDB service client for state tracking."""
from typing import Dict, Any, List, Optional
from datetime import datetime
import boto3
from botocore.exceptions import ClientError
from decimal import Decimal
from app.config import get_settings


class DynamoDBService:
    """Service for interacting with DynamoDB for state persistence."""
    
    def __init__(self):
        """Initialize the DynamoDB client."""
        self.settings = get_settings()
        
        client_config = {
            'region_name': self.settings.aws_region,
        }
        
        if self.settings.use_localstack and self.settings.aws_endpoint_url:
            client_config['endpoint_url'] = self.settings.aws_endpoint_url
            client_config['aws_access_key_id'] = self.settings.aws_access_key_id
            client_config['aws_secret_access_key'] = self.settings.aws_secret_access_key
        
        self.dynamodb = boto3.resource('dynamodb', **client_config)
        self.state_table = self.dynamodb.Table(self.settings.dynamodb_table_name)
        self.history_table = self.dynamodb.Table(self.settings.dynamodb_execution_history_table)
    
    def _convert_floats_to_decimal(self, obj: Any) -> Any:
        """Convert floats to Decimal for DynamoDB compatibility."""
        if isinstance(obj, float):
            return Decimal(str(obj))
        elif isinstance(obj, dict):
            return {k: self._convert_floats_to_decimal(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._convert_floats_to_decimal(item) for item in obj]
        return obj
    
    def _convert_decimal_to_float(self, obj: Any) -> Any:
        """Convert Decimal to float for JSON serialization."""
        if isinstance(obj, Decimal):
            return float(obj)
        elif isinstance(obj, dict):
            return {k: self._convert_decimal_to_float(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._convert_decimal_to_float(item) for item in obj]
        return obj
    
    async def save_execution_state(
        self,
        execution_id: str,
        file_id: str,
        state: Dict[str, Any]
    ) -> None:
        """
        Save execution state for a file.
        
        Args:
            execution_id: Unique execution identifier
            file_id: File identifier
            state: State data to save
        """
        try:
            item = {
                'execution_id': execution_id,
                'file_id': file_id,
                'state': self._convert_floats_to_decimal(state),
                'updated_at': datetime.utcnow().isoformat(),
                'timestamp': Decimal(str(datetime.utcnow().timestamp()))
            }
            
            self.state_table.put_item(Item=item)
        except ClientError as e:
            raise Exception(f"Failed to save execution state: {str(e)}")
    
    async def get_execution_state(
        self,
        execution_id: str,
        file_id: str
    ) -> Optional[Dict[str, Any]]:
        """
        Get execution state for a file.
        
        Args:
            execution_id: Unique execution identifier
            file_id: File identifier
        
        Returns:
            State data or None if not found
        """
        try:
            response = self.state_table.get_item(
                Key={
                    'execution_id': execution_id,
                    'file_id': file_id
                }
            )
            
            item = response.get('Item')
            if item:
                return self._convert_decimal_to_float(item.get('state'))
            return None
        except ClientError as e:
            raise Exception(f"Failed to get execution state: {str(e)}")
    
    async def get_all_execution_states(
        self,
        execution_id: str
    ) -> List[Dict[str, Any]]:
        """
        Get all file states for an execution.
        
        Args:
            execution_id: Unique execution identifier
        
        Returns:
            List of file states
        """
        try:
            response = self.state_table.query(
                KeyConditionExpression='execution_id = :eid',
                ExpressionAttributeValues={
                    ':eid': execution_id
                }
            )
            
            items = response.get('Items', [])
            return [self._convert_decimal_to_float(item) for item in items]
        except ClientError as e:
            raise Exception(f"Failed to get all execution states: {str(e)}")
    
    async def delete_execution_state(
        self,
        execution_id: str,
        file_id: str
    ) -> None:
        """
        Delete execution state for a file.
        
        Args:
            execution_id: Unique execution identifier
            file_id: File identifier
        """
        try:
            self.state_table.delete_item(
                Key={
                    'execution_id': execution_id,
                    'file_id': file_id
                }
            )
        except ClientError as e:
            raise Exception(f"Failed to delete execution state: {str(e)}")
    
    async def save_execution_history(
        self,
        execution_id: str,
        execution_data: Dict[str, Any]
    ) -> None:
        """
        Save execution history record.
        
        Args:
            execution_id: Unique execution identifier
            execution_data: Execution metadata and results
        """
        try:
            item = {
                'execution_id': execution_id,
                'timestamp': Decimal(str(datetime.utcnow().timestamp())),
                'data': self._convert_floats_to_decimal(execution_data),
                'created_at': datetime.utcnow().isoformat()
            }
            
            self.history_table.put_item(Item=item)
        except ClientError as e:
            raise Exception(f"Failed to save execution history: {str(e)}")
    
    async def get_execution_history(
        self,
        execution_id: str
    ) -> List[Dict[str, Any]]:
        """
        Get execution history for an execution.
        
        Args:
            execution_id: Unique execution identifier
        
        Returns:
            List of history records
        """
        try:
            response = self.history_table.query(
                KeyConditionExpression='execution_id = :eid',
                ExpressionAttributeValues={
                    ':eid': execution_id
                },
                ScanIndexForward=False  # Most recent first
            )
            
            items = response.get('Items', [])
            return [self._convert_decimal_to_float(item) for item in items]
        except ClientError as e:
            raise Exception(f"Failed to get execution history: {str(e)}")
    
    async def list_recent_executions(
        self,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """
        List recent executions.
        
        Args:
            limit: Maximum number of executions to return
        
        Returns:
            List of execution records
        """
        try:
            response = self.history_table.scan(
                Limit=limit
            )
            
            items = response.get('Items', [])
            # Sort by timestamp descending
            items.sort(key=lambda x: x.get('timestamp', 0), reverse=True)
            
            return [self._convert_decimal_to_float(item) for item in items[:limit]]
        except ClientError as e:
            raise Exception(f"Failed to list recent executions: {str(e)}")
    
    async def update_chunk_progress(
        self,
        execution_id: str,
        file_id: str,
        chunk_id: str,
        progress: Dict[str, Any]
    ) -> None:
        """
        Update progress for a specific chunk.
        
        Args:
            execution_id: Unique execution identifier
            file_id: File identifier
            chunk_id: Chunk identifier
            progress: Progress data
        """
        try:
            current_state = await self.get_execution_state(execution_id, file_id)
            
            if not current_state:
                current_state = {
                    'chunks': {},
                    'status': 'in_progress'
                }
            
            if 'chunks' not in current_state:
                current_state['chunks'] = {}
            
            current_state['chunks'][chunk_id] = progress
            current_state['updated_at'] = datetime.utcnow().isoformat()
            
            await self.save_execution_state(execution_id, file_id, current_state)
        except Exception as e:
            raise Exception(f"Failed to update chunk progress: {str(e)}")
    
    async def get_metrics(self) -> Dict[str, Any]:
        """
        Get system-wide metrics.
        
        Returns:
            Dictionary of metrics
        """
        try:
            # Scan history table for metrics
            response = self.history_table.scan()
            items = response.get('Items', [])
            
            total_executions = len(items)
            completed = sum(1 for item in items 
                          if item.get('data', {}).get('status') == 'SUCCEEDED')
            failed = sum(1 for item in items 
                        if item.get('data', {}).get('status') == 'FAILED')
            
            return {
                'total_executions': total_executions,
                'completed_executions': completed,
                'failed_executions': failed,
                'success_rate': (completed / total_executions * 100) if total_executions > 0 else 0
            }
        except ClientError as e:
            raise Exception(f"Failed to get metrics: {str(e)}")