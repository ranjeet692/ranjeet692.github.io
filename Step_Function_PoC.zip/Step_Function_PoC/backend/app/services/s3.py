"""S3 service client."""
from typing import List, Dict, Any, Optional
import boto3
from botocore.exceptions import ClientError
from app.config import get_settings
from app.models.schemas import FileInput


class S3Service:
    """Service for interacting with AWS S3."""
    
    def __init__(self):
        """Initialize the S3 client."""
        self.settings = get_settings()
        
        client_config = {
            'region_name': self.settings.aws_region,
        }
        
        if self.settings.use_localstack and self.settings.aws_endpoint_url:
            client_config['endpoint_url'] = self.settings.aws_endpoint_url
            client_config['aws_access_key_id'] = self.settings.aws_access_key_id
            client_config['aws_secret_access_key'] = self.settings.aws_secret_access_key
        
        self.client = boto3.client('s3', **client_config)
        self.bucket_name = self.settings.s3_bucket_name
        self.processed_bucket = self.settings.s3_processed_bucket
    
    async def list_files(
        self,
        prefix: str = "",
        max_keys: int = 1000
    ) -> List[FileInput]:
        """
        List files in the S3 bucket.
        
        Args:
            prefix: Optional prefix to filter files
            max_keys: Maximum number of files to return
        
        Returns:
            List of FileInput objects
        """
        try:
            response = self.client.list_objects_v2(
                Bucket=self.bucket_name,
                Prefix=prefix,
                MaxKeys=max_keys
            )
            
            files = []
            for obj in response.get('Contents', []):
                files.append(FileInput(
                    file_key=obj['Key'],
                    file_size=obj['Size'],
                    metadata={
                        'last_modified': obj['LastModified'].isoformat(),
                        'etag': obj['ETag']
                    }
                ))
            
            return files
        except ClientError as e:
            raise Exception(f"Failed to list files: {str(e)}")
    
    async def get_file_metadata(self, file_key: str) -> Dict[str, Any]:
        """
        Get metadata for a specific file.
        
        Args:
            file_key: S3 key of the file
        
        Returns:
            File metadata dictionary
        """
        try:
            response = self.client.head_object(
                Bucket=self.bucket_name,
                Key=file_key
            )
            
            return {
                'file_key': file_key,
                'size': response['ContentLength'],
                'content_type': response.get('ContentType'),
                'last_modified': response['LastModified'].isoformat(),
                'metadata': response.get('Metadata', {})
            }
        except ClientError as e:
            raise Exception(f"Failed to get file metadata: {str(e)}")
    
    async def download_file(
        self,
        file_key: str,
        local_path: str
    ) -> None:
        """
        Download a file from S3.
        
        Args:
            file_key: S3 key of the file
            local_path: Local path to save the file
        """
        try:
            self.client.download_file(
                self.bucket_name,
                file_key,
                local_path
            )
        except ClientError as e:
            raise Exception(f"Failed to download file: {str(e)}")
    
    async def upload_file(
        self,
        local_path: str,
        file_key: str,
        metadata: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """
        Upload a file to S3.
        
        Args:
            local_path: Local path of the file
            file_key: S3 key to upload to
            metadata: Optional metadata to attach
        
        Returns:
            Upload response
        """
        try:
            extra_args = {}
            if metadata:
                extra_args['Metadata'] = metadata
            
            self.client.upload_file(
                local_path,
                self.bucket_name,
                file_key,
                ExtraArgs=extra_args
            )
            
            return {
                'bucket': self.bucket_name,
                'key': file_key,
                'status': 'uploaded'
            }
        except ClientError as e:
            raise Exception(f"Failed to upload file: {str(e)}")
    
    async def copy_to_processed(
        self,
        source_key: str,
        destination_key: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Copy a file to the processed bucket.
        
        Args:
            source_key: Source S3 key
            destination_key: Optional destination key (defaults to source_key)
        
        Returns:
            Copy response
        """
        if not destination_key:
            destination_key = source_key
        
        try:
            self.client.copy_object(
                CopySource={
                    'Bucket': self.bucket_name,
                    'Key': source_key
                },
                Bucket=self.processed_bucket,
                Key=destination_key
            )
            
            return {
                'source_bucket': self.bucket_name,
                'source_key': source_key,
                'destination_bucket': self.processed_bucket,
                'destination_key': destination_key,
                'status': 'copied'
            }
        except ClientError as e:
            raise Exception(f"Failed to copy file: {str(e)}")
    
    async def delete_file(self, file_key: str) -> Dict[str, Any]:
        """
        Delete a file from S3.
        
        Args:
            file_key: S3 key of the file to delete
        
        Returns:
            Delete response
        """
        try:
            self.client.delete_object(
                Bucket=self.bucket_name,
                Key=file_key
            )
            
            return {
                'bucket': self.bucket_name,
                'key': file_key,
                'status': 'deleted'
            }
        except ClientError as e:
            raise Exception(f"Failed to delete file: {str(e)}")
    
    async def get_presigned_url(
        self,
        file_key: str,
        expiration: int = 3600
    ) -> str:
        """
        Generate a presigned URL for file access.
        
        Args:
            file_key: S3 key of the file
            expiration: URL expiration time in seconds
        
        Returns:
            Presigned URL
        """
        try:
            url = self.client.generate_presigned_url(
                'get_object',
                Params={
                    'Bucket': self.bucket_name,
                    'Key': file_key
                },
                ExpiresIn=expiration
            )
            return url
        except ClientError as e:
            raise Exception(f"Failed to generate presigned URL: {str(e)}")