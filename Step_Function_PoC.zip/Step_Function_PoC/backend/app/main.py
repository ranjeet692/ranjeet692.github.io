"""Main FastAPI application."""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api import workflows, websocket
from app.config import get_settings

settings = get_settings()

# Create FastAPI application
app = FastAPI(
    title="LLM Document Processing Orchestration",
    description="FastAPI + AWS Step Functions PoC for large-scale document processing with LLM integration",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_url, "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(workflows.router)
app.include_router(websocket.router)


@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "name": "LLM Document Processing Orchestration API",
        "version": "1.0.0",
        "status": "running",
        "endpoints": {
            "docs": "/docs",
            "workflows": "/api/workflows",
            "websocket": "/ws/execution/{execution_id}"
        }
    }


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "timestamp": "2025-11-07T05:00:00Z"
    }


@app.on_event("startup")
async def startup_event():
    """Application startup tasks."""
    print("=" * 80)
    print("LLM Document Processing Orchestration API Starting...")
    print("=" * 80)
    print(f"Environment: {'LocalStack' if settings.use_localstack else 'AWS'}")
    print(f"AWS Region: {settings.aws_region}")
    print(f"S3 Bucket: {settings.s3_bucket_name}")
    print(f"State Machine: {settings.state_machine_arn}")
    print(f"Max Concurrent Executions: {settings.max_concurrent_executions}")
    print("=" * 80)


@app.on_event("shutdown")
async def shutdown_event():
    """Application shutdown tasks."""
    print("Shutting down LLM Document Processing Orchestration API...")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        app,
        host=settings.backend_host,
        port=settings.backend_port,
        log_level="info"
    )