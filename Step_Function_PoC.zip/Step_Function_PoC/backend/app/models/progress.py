"""Progress tracking models for real-time workflow monitoring."""
from typing import Optional, List, Dict, Any
from pydantic import BaseModel
from datetime import datetime
from enum import Enum


class ProgressEventType(str, Enum):
    """Types of progress events."""
    EXECUTION_STARTED = "execution_started"
    EXECUTION_COMPLETED = "execution_completed"
    EXECUTION_FAILED = "execution_failed"
    STATE_ENTERED = "state_entered"
    STATE_EXITED = "state_exited"
    FILE_STARTED = "file_started"
    FILE_COMPLETED = "file_completed"
    FILE_FAILED = "file_failed"
    BATCH_STARTED = "batch_started"
    BATCH_COMPLETED = "batch_completed"
    PROGRESS_UPDATE = "progress_update"


class ProgressEvent(BaseModel):
    """Progress event model."""
    execution_id: str
    event_type: ProgressEventType
    timestamp: datetime
    state_name: Optional[str] = None
    file_id: Optional[str] = None
    batch_id: Optional[str] = None
    message: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    progress_percentage: Optional[float] = None


class ExecutionProgress(BaseModel):
    """Execution progress tracking."""
    execution_id: str
    execution_arn: str
    workflow_id: str
    status: str
    start_time: datetime
    end_time: Optional[datetime] = None

    # Overall progress
    total_items: int = 0
    completed_items: int = 0
    failed_items: int = 0
    progress_percentage: float = 0.0

    # Current state
    current_state: Optional[str] = None
    current_batch: Optional[int] = None

    # Performance metrics
    items_per_second: float = 0.0
    estimated_completion_time: Optional[datetime] = None

    # File-level tracking
    files_processed: List[str] = []
    files_failed: List[str] = []

    # Metadata
    metadata: Dict[str, Any] = {}
    last_updated: datetime


class ProgressSubscription(BaseModel):
    """WebSocket subscription for progress updates."""
    execution_id: str
    connection_id: str
    subscribed_at: datetime
    filters: Optional[List[ProgressEventType]] = None


class ProgressUpdateRequest(BaseModel):
    """Request to update execution progress."""
    execution_id: str
    event_type: ProgressEventType
    state_name: Optional[str] = None
    file_id: Optional[str] = None
    batch_id: Optional[str] = None
    items_completed: Optional[int] = None
    items_failed: Optional[int] = None
    message: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class ProgressResponse(BaseModel):
    """Progress query response."""
    execution_id: str
    progress: ExecutionProgress
    recent_events: List[ProgressEvent] = []
