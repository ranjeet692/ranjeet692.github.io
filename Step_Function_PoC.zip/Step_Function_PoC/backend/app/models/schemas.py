"""Pydantic models for request/response schemas."""
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
from enum import Enum


class ExecutionStatus(str, Enum):
    """Execution status enumeration."""
    RUNNING = "RUNNING"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    TIMED_OUT = "TIMED_OUT"
    ABORTED = "ABORTED"
    PAUSED = "PAUSED"


class FileInput(BaseModel):
    """Input file specification."""
    file_key: str = Field(..., description="S3 key of the file")
    file_size: int = Field(..., description="File size in bytes")
    metadata: Optional[Dict[str, Any]] = Field(default=None, description="Additional metadata")


class WorkflowStartRequest(BaseModel):
    """Request to start a workflow execution."""
    files: List[FileInput] = Field(..., description="List of files to process")
    execution_name: Optional[str] = Field(default=None, description="Custom execution name")
    max_concurrency: Optional[int] = Field(default=10, description="Max concurrent file processing")
    chunk_size_mb: Optional[int] = Field(default=5, description="Chunk size in MB")


class WorkflowStartResponse(BaseModel):
    """Response after starting a workflow."""
    execution_arn: str = Field(..., description="ARN of the execution")
    execution_id: str = Field(..., description="Unique execution ID")
    start_time: datetime = Field(..., description="Execution start time")
    status: str = Field(..., description="Initial status")


class ExecutionControlRequest(BaseModel):
    """Request to control an execution (pause/resume/terminate)."""
    execution_arn: str = Field(..., description="ARN of the execution to control")


class ExecutionStatusResponse(BaseModel):
    """Execution status response."""
    execution_arn: str
    execution_id: str
    status: ExecutionStatus
    start_time: datetime
    stop_time: Optional[datetime] = None
    input: Optional[Dict[str, Any]] = None
    output: Optional[Dict[str, Any]] = None
    error: Optional[str] = None


class ChunkProgress(BaseModel):
    """Progress information for a chunk."""
    chunk_id: str
    file_key: str
    chunk_index: int
    total_chunks: int
    status: str
    progress_percentage: float
    partial_results: Optional[List[Dict[str, Any]]] = None


class FileProgress(BaseModel):
    """Progress information for a file."""
    file_key: str
    total_chunks: int
    completed_chunks: int
    failed_chunks: int
    status: str
    progress_percentage: float
    chunks: List[ChunkProgress] = []


class ExecutionProgress(BaseModel):
    """Overall execution progress."""
    execution_id: str
    total_files: int
    completed_files: int
    failed_files: int
    in_progress_files: int
    overall_progress: float
    files: List[FileProgress] = []


class WebSocketMessage(BaseModel):
    """WebSocket message format."""
    type: str = Field(..., description="Message type (progress, status, stream, error)")
    execution_id: str = Field(..., description="Associated execution ID")
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    data: Dict[str, Any] = Field(..., description="Message payload")


class ExecutionHistoryItem(BaseModel):
    """Execution history record."""
    execution_id: str
    execution_arn: str
    start_time: datetime
    end_time: Optional[datetime] = None
    status: ExecutionStatus
    total_files: int
    completed_files: int
    failed_files: int
    error_message: Optional[str] = None


class ExecutionListResponse(BaseModel):
    """List of executions."""
    executions: List[ExecutionHistoryItem]
    total_count: int
    page: int
    page_size: int


class S3FileListResponse(BaseModel):
    """List of files in S3 bucket."""
    files: List[FileInput]
    total_count: int
    bucket_name: str


class MetricsResponse(BaseModel):
    """System metrics and statistics."""
    total_executions: int
    running_executions: int
    completed_executions: int
    failed_executions: int
    total_files_processed: int
    average_processing_time: float
    success_rate: float


class StreamChunk(BaseModel):
    """Streaming output chunk."""
    chunk_id: str
    sequence: int
    content: str
    timestamp: datetime
    is_final: bool = False