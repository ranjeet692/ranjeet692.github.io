"""Utility for generating S3 manifest files for distributed map workflows."""
import csv
import json
import boto3
from typing import List, Dict, Optional
from io import StringIO
from datetime import datetime


class ManifestGenerator:
    """Generate CSV/JSON manifest files for S3 distributed map processing."""

    def __init__(self):
        """Initialize the Manifest Generator."""
        self.s3_client = boto3.client(
            's3',
            endpoint_url='http://localstack:4566',
            region_name='us-east-1',
            aws_access_key_id='test',
            aws_secret_access_key='test'
        )

    def generate_csv_manifest(
        self,
        files: List[Dict[str, str]],
        output_bucket: str,
        output_key: str
    ) -> Dict[str, any]:
        """
        Generate CSV manifest file and upload to S3.

        Args:
            files: List of file metadata dicts with keys: bucket, file_key, file_id
            output_bucket: S3 bucket to store the manifest
            output_key: S3 key for the manifest file

        Returns:
            Manifest metadata
        """
        # Create CSV content
        csv_buffer = StringIO()
        writer = csv.DictWriter(csv_buffer, fieldnames=['bucket', 'file_key', 'file_id'])

        # Write header
        writer.writeheader()

        # Write file entries
        for file_entry in files:
            writer.writerow({
                'bucket': file_entry.get('bucket', ''),
                'file_key': file_entry.get('file_key', ''),
                'file_id': file_entry.get('file_id', file_entry.get('file_key', ''))
            })

        # Upload to S3
        csv_content = csv_buffer.getvalue()
        self.s3_client.put_object(
            Bucket=output_bucket,
            Key=output_key,
            Body=csv_content.encode('utf-8'),
            ContentType='text/csv'
        )

        return {
            'manifestBucket': output_bucket,
            'manifestKey': output_key,
            'fileCount': len(files),
            'format': 'CSV',
            'generatedAt': datetime.utcnow().isoformat()
        }

    def generate_json_manifest(
        self,
        files: List[Dict[str, str]],
        output_bucket: str,
        output_key: str
    ) -> Dict[str, any]:
        """
        Generate JSON manifest file and upload to S3.

        Args:
            files: List of file metadata dicts
            output_bucket: S3 bucket to store the manifest
            output_key: S3 key for the manifest file

        Returns:
            Manifest metadata
        """
        # Create JSON content
        manifest_data = {
            'version': '1.0',
            'generatedAt': datetime.utcnow().isoformat(),
            'fileCount': len(files),
            'files': files
        }

        json_content = json.dumps(manifest_data, indent=2)

        # Upload to S3
        self.s3_client.put_object(
            Bucket=output_bucket,
            Key=output_key,
            Body=json_content.encode('utf-8'),
            ContentType='application/json'
        )

        return {
            'manifestBucket': output_bucket,
            'manifestKey': output_key,
            'fileCount': len(files),
            'format': 'JSON',
            'generatedAt': manifest_data['generatedAt']
        }

    def generate_manifest_from_s3_prefix(
        self,
        source_bucket: str,
        source_prefix: str,
        output_bucket: str,
        output_key: str,
        format: str = 'CSV',
        max_files: Optional[int] = None
    ) -> Dict[str, any]:
        """
        Generate manifest by listing files from S3 prefix.

        Args:
            source_bucket: S3 bucket to scan
            source_prefix: Prefix/folder to scan
            output_bucket: S3 bucket to store the manifest
            output_key: S3 key for the manifest file
            format: 'CSV' or 'JSON'
            max_files: Optional limit on number of files

        Returns:
            Manifest metadata
        """
        # List objects with pagination
        files = []
        paginator = self.s3_client.get_paginator('list_objects_v2')

        for page in paginator.paginate(Bucket=source_bucket, Prefix=source_prefix):
            if 'Contents' not in page:
                continue

            for obj in page['Contents']:
                # Skip directories
                if obj['Key'].endswith('/'):
                    continue

                files.append({
                    'bucket': source_bucket,
                    'file_key': obj['Key'],
                    'file_id': obj['Key'].replace('/', '_'),
                    'size': obj['Size'],
                    'lastModified': obj['LastModified'].isoformat()
                })

                # Check max files limit
                if max_files and len(files) >= max_files:
                    break

            if max_files and len(files) >= max_files:
                break

        # Generate manifest
        if format.upper() == 'JSON':
            return self.generate_json_manifest(files, output_bucket, output_key)
        else:
            return self.generate_csv_manifest(files, output_bucket, output_key)

    def create_test_manifest(
        self,
        file_count: int,
        bucket: str,
        prefix: str,
        output_bucket: str,
        output_key: str
    ) -> Dict[str, any]:
        """
        Create a test manifest with dummy file entries.

        Args:
            file_count: Number of dummy files to generate
            bucket: Bucket name for dummy files
            prefix: Prefix for dummy file keys
            output_bucket: S3 bucket to store the manifest
            output_key: S3 key for the manifest file

        Returns:
            Manifest metadata
        """
        files = []
        for i in range(file_count):
            files.append({
                'bucket': bucket,
                'file_key': f'{prefix}/file_{i:06d}.pdf',
                'file_id': f'FILE-{i:06d}'
            })

        return self.generate_csv_manifest(files, output_bucket, output_key)

    def validate_manifest(
        self,
        manifest_bucket: str,
        manifest_key: str
    ) -> Dict[str, any]:
        """
        Validate a manifest file.

        Args:
            manifest_bucket: S3 bucket containing the manifest
            manifest_key: S3 key of the manifest file

        Returns:
            Validation result
        """
        try:
            # Download manifest
            response = self.s3_client.get_object(
                Bucket=manifest_bucket,
                Key=manifest_key
            )
            content = response['Body'].read().decode('utf-8')

            # Determine format
            is_csv = manifest_key.endswith('.csv')

            if is_csv:
                # Parse CSV
                csv_reader = csv.DictReader(StringIO(content))
                rows = list(csv_reader)

                # Validate required columns
                required_columns = {'bucket', 'file_key'}
                if not required_columns.issubset(set(rows[0].keys() if rows else [])):
                    return {
                        'valid': False,
                        'error': f'Missing required columns. Expected: {required_columns}'
                    }

                return {
                    'valid': True,
                    'format': 'CSV',
                    'fileCount': len(rows),
                    'columns': list(rows[0].keys()) if rows else []
                }
            else:
                # Parse JSON
                data = json.loads(content)

                if 'files' not in data:
                    return {
                        'valid': False,
                        'error': 'Missing "files" array in JSON manifest'
                    }

                return {
                    'valid': True,
                    'format': 'JSON',
                    'fileCount': len(data['files']),
                    'version': data.get('version', 'unknown')
                }

        except Exception as e:
            return {
                'valid': False,
                'error': str(e)
            }
