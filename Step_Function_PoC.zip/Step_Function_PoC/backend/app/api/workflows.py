"""Workflow API endpoints."""
from typing import List, Optional
from fastapi import APIRouter, HTTPException, Query
from app.models.schemas import (
    WorkflowStartRequest,
    WorkflowStartResponse,
    ExecutionControlRequest,
    ExecutionStatusResponse,
    ExecutionListResponse,
    ExecutionHistoryItem,
    S3FileListResponse,
    MetricsResponse
)
from app.services.stepfunctions import StepFunctionsService
from app.services.s3 import S3Service
from app.services.dynamodb import DynamoDBService
from datetime import datetime

router = APIRouter(prefix="/api/workflows", tags=["workflows"])

# Service instances
sfn_service = StepFunctionsService()
s3_service = S3Service()
db_service = DynamoDBService()


@router.post("/start", response_model=WorkflowStartResponse)
async def start_workflow(request: WorkflowStartRequest):
    """
    Start a new document processing workflow.
    
    This endpoint initiates a Step Functions execution that will:
    1. Chunk files if they exceed the size limit
    2. Process chunks in parallel using Lambda
    3. Aggregate results
    """
    try:
        # Convert FileInput objects to dicts
        files = [file.model_dump() for file in request.files]
        
        # Start Step Functions execution
        result = await sfn_service.start_execution(
            files=files,
            execution_name=request.execution_name,
            max_concurrency=request.max_concurrency,
            chunk_size_mb=request.chunk_size_mb
        )
        
        # Save initial execution state
        await db_service.save_execution_history(
            execution_id=result['execution_id'],
            execution_data={
                'execution_arn': result['execution_arn'],
                'start_time': result['start_time'].isoformat(),
                'status': result['status'],
                'total_files': len(files),
                'input': request.model_dump()
            }
        )
        
        return WorkflowStartResponse(
            execution_arn=result['execution_arn'],
            execution_id=result['execution_id'],
            start_time=result['start_time'],
            status=result['status']
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/status/{execution_arn:path}", response_model=ExecutionStatusResponse)
async def get_execution_status(execution_arn: str):
    """
    Get the current status of a workflow execution.
    
    Returns detailed information about the execution including:
    - Current status (RUNNING, SUCCEEDED, FAILED, etc.)
    - Start and stop times
    - Input and output data
    - Error information if failed
    """
    try:
        status = await sfn_service.describe_execution(execution_arn)
        return status
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/stop")
async def stop_workflow(request: ExecutionControlRequest):
    """
    Stop a running workflow execution.
    
    This will terminate the Step Functions execution immediately,
    stopping all running Lambda functions.
    """
    try:
        result = await sfn_service.stop_execution(
            execution_arn=request.execution_arn
        )
        
        # Update execution history
        execution_id = request.execution_arn.split(':')[-1]
        await db_service.save_execution_history(
            execution_id=execution_id,
            execution_data={
                'execution_arn': request.execution_arn,
                'stop_time': result['stop_time'].isoformat(),
                'status': result['status'],
                'stopped_by': 'user'
            }
        )
        
        return {"status": "stopped", "execution_arn": request.execution_arn}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/list", response_model=ExecutionListResponse)
async def list_executions(
    status: Optional[str] = Query(None, description="Filter by status"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100)
):
    """
    List workflow executions with optional status filter.
    
    Returns paginated list of executions with their current status.
    """
    try:
        executions = await sfn_service.list_executions(
            status_filter=status,
            max_results=page_size * page
        )
        
        # Simple pagination
        start_idx = (page - 1) * page_size
        end_idx = start_idx + page_size
        page_executions = executions[start_idx:end_idx]
        
        execution_items = [
            ExecutionHistoryItem(
                execution_id=exec['name'],
                execution_arn=exec['executionArn'],
                start_time=exec['startDate'],
                end_time=exec.get('stopDate'),
                status=exec['status'],
                total_files=0,  # Would need to parse from input
                completed_files=0,
                failed_files=0
            )
            for exec in page_executions
        ]
        
        return ExecutionListResponse(
            executions=execution_items,
            total_count=len(executions),
            page=page,
            page_size=page_size
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/history/{execution_arn:path}")
async def get_execution_history(execution_arn: str):
    """
    Get detailed execution history with all state transitions.
    
    Returns a timeline of all events that occurred during execution.
    """
    try:
        history = await sfn_service.get_execution_history(execution_arn)
        return {"execution_arn": execution_arn, "events": history}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/files", response_model=S3FileListResponse)
async def list_s3_files(
    prefix: str = Query("", description="Filter files by prefix"),
    max_files: int = Query(100, ge=1, le=1000)
):
    """
    List files available in the S3 bucket for processing.
    
    Returns file metadata including size and last modified date.
    """
    try:
        files = await s3_service.list_files(prefix=prefix, max_keys=max_files)
        return S3FileListResponse(
            files=files,
            total_count=len(files),
            bucket_name=s3_service.bucket_name
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/metrics", response_model=MetricsResponse)
async def get_metrics():
    """
    Get system-wide processing metrics and statistics.

    Returns:
    - Total number of executions
    - Success/failure rates
    - Average processing times
    - Current system load
    """
    try:
        # Get all executions from Step Functions
        all_executions = await sfn_service.list_executions(max_results=1000)

        # Calculate metrics from Step Functions data
        total_executions = len(all_executions)
        running_executions = sum(1 for e in all_executions if e['status'] == 'RUNNING')
        succeeded_executions = sum(1 for e in all_executions if e['status'] == 'SUCCEEDED')
        failed_executions = sum(1 for e in all_executions if e['status'] in ['FAILED', 'TIMED_OUT', 'ABORTED'])

        # Calculate success rate
        completed_total = succeeded_executions + failed_executions
        success_rate = (succeeded_executions / completed_total * 100) if completed_total > 0 else 0.0

        return MetricsResponse(
            total_executions=total_executions,
            running_executions=running_executions,
            completed_executions=succeeded_executions,
            failed_executions=failed_executions,
            total_files_processed=0,  # Would need to aggregate from history
            average_processing_time=0.0,  # Would need to calculate
            success_rate=success_rate
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/execution-state/{execution_id}")
async def get_execution_state(execution_id: str):
    """
    Get detailed state information for a specific execution.
    
    Returns per-file and per-chunk progress information stored in DynamoDB.
    """
    try:
        states = await db_service.get_all_execution_states(execution_id)
        return {"execution_id": execution_id, "file_states": states}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))