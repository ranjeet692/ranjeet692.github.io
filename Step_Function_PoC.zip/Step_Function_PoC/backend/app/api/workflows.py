"""Workflow API endpoints."""
from typing import List, Optional
from fastapi import APIRouter, HTTPException, Query
from app.models.schemas import (
    WorkflowStartRequest,
    WorkflowStartResponse,
    ExecutionControlRequest,
    ExecutionStatusResponse,
    ExecutionListResponse,
    ExecutionHistoryItem,
    S3FileListResponse,
    MetricsResponse
)
from app.services.stepfunctions import StepFunctionsService
from app.services.s3 import S3Service
from app.services.dynamodb import DynamoDBService
from app.services.workflow_manager import WorkflowManager
from app.services.progress_tracker import ProgressTracker
from app.services.multipart_uploader import MultipartUploader
from app.utils.manifest_generator import ManifestGenerator
from app.models.progress import ProgressUpdateRequest, ProgressResponse
from datetime import datetime
from fastapi import UploadFile, File, Form, Body

router = APIRouter(prefix="/api/workflows", tags=["workflows"])

# Service instances
sfn_service = StepFunctionsService()
s3_service = S3Service()
db_service = DynamoDBService()
workflow_manager = WorkflowManager()
manifest_generator = ManifestGenerator()
progress_tracker = ProgressTracker()
multipart_uploader = MultipartUploader()


@router.post("/start", response_model=WorkflowStartResponse)
async def start_workflow(request: WorkflowStartRequest):
    """
    Start a new document processing workflow.
    
    This endpoint initiates a Step Functions execution that will:
    1. Chunk files if they exceed the size limit
    2. Process chunks in parallel using Lambda
    3. Aggregate results
    """
    try:
        # Convert FileInput objects to dicts
        files = [file.model_dump() for file in request.files]
        
        # Start Step Functions execution
        result = await sfn_service.start_execution(
            files=files,
            execution_name=request.execution_name,
            max_concurrency=request.max_concurrency,
            chunk_size_mb=request.chunk_size_mb
        )
        
        # Save initial execution state
        await db_service.save_execution_history(
            execution_id=result['execution_id'],
            execution_data={
                'execution_arn': result['execution_arn'],
                'start_time': result['start_time'].isoformat(),
                'status': result['status'],
                'total_files': len(files),
                'input': request.model_dump()
            }
        )
        
        return WorkflowStartResponse(
            execution_arn=result['execution_arn'],
            execution_id=result['execution_id'],
            start_time=result['start_time'],
            status=result['status']
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/status/{execution_arn:path}", response_model=ExecutionStatusResponse)
async def get_execution_status(execution_arn: str):
    """
    Get the current status of a workflow execution.
    
    Returns detailed information about the execution including:
    - Current status (RUNNING, SUCCEEDED, FAILED, etc.)
    - Start and stop times
    - Input and output data
    - Error information if failed
    """
    try:
        status = await sfn_service.describe_execution(execution_arn)
        return status
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/stop")
async def stop_workflow(request: ExecutionControlRequest):
    """
    Stop a running workflow execution.
    
    This will terminate the Step Functions execution immediately,
    stopping all running Lambda functions.
    """
    try:
        result = await sfn_service.stop_execution(
            execution_arn=request.execution_arn
        )
        
        # Update execution history
        execution_id = request.execution_arn.split(':')[-1]
        await db_service.save_execution_history(
            execution_id=execution_id,
            execution_data={
                'execution_arn': request.execution_arn,
                'stop_time': result['stop_time'].isoformat(),
                'status': result['status'],
                'stopped_by': 'user'
            }
        )
        
        return {"status": "stopped", "execution_arn": request.execution_arn}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/list", response_model=ExecutionListResponse)
async def list_executions(
    status: Optional[str] = Query(None, description="Filter by status"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100)
):
    """
    List workflow executions with optional status filter.
    
    Returns paginated list of executions with their current status.
    """
    try:
        executions = await sfn_service.list_executions(
            status_filter=status,
            max_results=page_size * page
        )
        
        # Simple pagination
        start_idx = (page - 1) * page_size
        end_idx = start_idx + page_size
        page_executions = executions[start_idx:end_idx]
        
        execution_items = [
            ExecutionHistoryItem(
                execution_id=exec['name'],
                execution_arn=exec['executionArn'],
                start_time=exec['startDate'],
                end_time=exec.get('stopDate'),
                status=exec['status'],
                total_files=0,  # Would need to parse from input
                completed_files=0,
                failed_files=0
            )
            for exec in page_executions
        ]
        
        return ExecutionListResponse(
            executions=execution_items,
            total_count=len(executions),
            page=page,
            page_size=page_size
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/history/{execution_arn:path}")
async def get_execution_history(execution_arn: str):
    """
    Get detailed execution history with all state transitions.
    
    Returns a timeline of all events that occurred during execution.
    """
    try:
        history = await sfn_service.get_execution_history(execution_arn)
        return {"execution_arn": execution_arn, "events": history}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/files", response_model=S3FileListResponse)
async def list_s3_files(
    prefix: str = Query("", description="Filter files by prefix"),
    max_files: int = Query(100, ge=1, le=1000)
):
    """
    List files available in the S3 bucket for processing.
    
    Returns file metadata including size and last modified date.
    """
    try:
        files = await s3_service.list_files(prefix=prefix, max_keys=max_files)
        return S3FileListResponse(
            files=files,
            total_count=len(files),
            bucket_name=s3_service.bucket_name
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/metrics", response_model=MetricsResponse)
async def get_metrics():
    """
    Get system-wide processing metrics and statistics.

    Returns:
    - Total number of executions
    - Success/failure rates
    - Average processing times
    - Current system load
    """
    try:
        # Get all executions from Step Functions
        all_executions = await sfn_service.list_executions(max_results=1000)

        # Calculate metrics from Step Functions data
        total_executions = len(all_executions)
        running_executions = sum(1 for e in all_executions if e['status'] == 'RUNNING')
        succeeded_executions = sum(1 for e in all_executions if e['status'] == 'SUCCEEDED')
        failed_executions = sum(1 for e in all_executions if e['status'] in ['FAILED', 'TIMED_OUT', 'ABORTED'])

        # Calculate success rate
        completed_total = succeeded_executions + failed_executions
        success_rate = (succeeded_executions / completed_total * 100) if completed_total > 0 else 0.0

        return MetricsResponse(
            total_executions=total_executions,
            running_executions=running_executions,
            completed_executions=succeeded_executions,
            failed_executions=failed_executions,
            total_files_processed=0,  # Would need to aggregate from history
            average_processing_time=0.0,  # Would need to calculate
            success_rate=success_rate
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/execution-state/{execution_id}")
async def get_execution_state(execution_id: str):
    """
    Get detailed state information for a specific execution.

    Returns per-file and per-chunk progress information stored in DynamoDB.
    """
    try:
        states = await db_service.get_all_execution_states(execution_id)
        return {"execution_id": execution_id, "file_states": states}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/retry/{execution_arn:path}")
async def retry_execution(execution_arn: str):
    """
    Retry a failed execution with the same input.

    Creates a new execution using the same input as the failed execution.
    """
    try:
        result = await sfn_service.redrive_execution(execution_arn)
        return {
            "message": "Execution retried successfully",
            "new_execution_arn": result['execution_arn'],
            "new_execution_id": result['execution_id'],
            "original_execution_arn": execution_arn
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/execution/{execution_arn:path}/input")
async def get_execution_input(execution_arn: str):
    """
    Get the input that was used to start an execution.
    """
    try:
        input_data = await sfn_service.get_execution_input(execution_arn)
        return {"execution_arn": execution_arn, "input": input_data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/state-machines")
async def list_state_machines():
    """
    List all available state machines.
    """
    try:
        state_machines = await sfn_service.list_state_machines()
        return {"state_machines": state_machines}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/state-machine/{state_machine_arn:path}")
async def get_state_machine(state_machine_arn: str):
    """
    Get details about a specific state machine.
    """
    try:
        state_machine = await sfn_service.describe_state_machine(state_machine_arn)
        return state_machine
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/state-machine-for-execution/{execution_arn:path}")
async def get_state_machine_for_execution(execution_arn: str):
    """
    Get the state machine definition used for a specific execution.
    """
    try:
        state_machine = await sfn_service.describe_state_machine_for_execution(execution_arn)
        return state_machine
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/compare-executions")
async def compare_executions(execution_arns: List[str]):
    """
    Compare multiple executions side-by-side.

    Returns execution details, history, and performance metrics for comparison.
    """
    try:
        comparisons = []
        for arn in execution_arns[:5]:  # Limit to 5 executions
            execution = await sfn_service.describe_execution(arn)
            history = await sfn_service.get_execution_history(arn)

            # Calculate execution duration
            duration = None
            if execution.stop_time and execution.start_time:
                duration = (execution.stop_time - execution.start_time).total_seconds()

            comparisons.append({
                "execution_arn": arn,
                "execution_id": execution.execution_id,
                "status": execution.status,
                "start_time": execution.start_time,
                "stop_time": execution.stop_time,
                "duration_seconds": duration,
                "total_events": len(history),
                "input": execution.input,
                "output": execution.output,
                "error": execution.error
            })

        return {"comparisons": comparisons}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/execution/{execution_arn:path}/export")
async def export_execution_data(execution_arn: str, format: str = Query("json", regex="^(json|csv)$")):
    """
    Export execution data in various formats.

    Supports JSON and CSV formats for analysis.
    """
    try:
        execution = await sfn_service.describe_execution(execution_arn)
        history = await sfn_service.get_execution_history(execution_arn)

        export_data = {
            "execution": {
                "arn": execution.execution_arn,
                "id": execution.execution_id,
                "status": execution.status,
                "start_time": execution.start_time.isoformat() if execution.start_time else None,
                "stop_time": execution.stop_time.isoformat() if execution.stop_time else None,
                "input": execution.input,
                "output": execution.output,
                "error": execution.error
            },
            "history": history,
            "exported_at": datetime.utcnow().isoformat()
        }

        if format == "csv":
            # For CSV, we'll convert the history events to a flat structure
            import csv
            import io

            output = io.StringIO()
            if history:
                keys = history[0].keys()
                writer = csv.DictWriter(output, fieldnames=keys)
                writer.writeheader()
                writer.writerows(history)

            return {"format": "csv", "data": output.getvalue()}

        return {"format": "json", "data": export_data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/analytics/overview")
async def get_analytics_overview(
    days: int = Query(7, ge=1, le=90, description="Number of days to analyze")
):
    """
    Get comprehensive analytics overview for executions.

    Returns metrics, trends, and insights for the specified time period.
    """
    try:
        from datetime import datetime, timedelta
        from collections import defaultdict

        # Get all executions across all state machines
        all_executions = await sfn_service.list_all_executions(max_results=1000)

        # Calculate date range
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)

        # Filter executions within date range
        # Convert datetime objects to ensure comparison works
        def parse_date(date_obj):
            if isinstance(date_obj, datetime):
                return date_obj
            return datetime.fromisoformat(str(date_obj).replace('Z', '+00:00'))

        executions = [
            e for e in all_executions
            if e.get('startDate') and
            parse_date(e['startDate']).replace(tzinfo=None) >= start_date
        ]

        # Calculate metrics
        total_executions = len(executions)
        status_counts = defaultdict(int)
        daily_executions = defaultdict(int)
        daily_success = defaultdict(int)
        daily_failure = defaultdict(int)
        durations = []

        for exec in executions:
            status = exec.get('status', 'UNKNOWN')
            status_counts[status] += 1

            # Daily trends
            if exec.get('startDate'):
                start = parse_date(exec['startDate'])
                date_key = start.strftime('%Y-%m-%d')
                daily_executions[date_key] += 1

                if status == 'SUCCEEDED':
                    daily_success[date_key] += 1
                elif status == 'FAILED':
                    daily_failure[date_key] += 1

            # Duration calculation
            if exec.get('startDate') and exec.get('stopDate'):
                start = parse_date(exec['startDate'])
                stop = parse_date(exec['stopDate'])
                duration = (stop - start).total_seconds()
                durations.append(duration)

        # Calculate success rate
        success_count = status_counts.get('SUCCEEDED', 0)
        failure_count = status_counts.get('FAILED', 0) + status_counts.get('TIMED_OUT', 0) + status_counts.get('ABORTED', 0)
        success_rate = (success_count / total_executions * 100) if total_executions > 0 else 0

        # Calculate average duration
        avg_duration = sum(durations) / len(durations) if durations else 0

        # Prepare daily trends data
        daily_trends = []
        current_date = start_date
        while current_date <= end_date:
            date_key = current_date.strftime('%Y-%m-%d')
            daily_trends.append({
                'date': date_key,
                'total': daily_executions.get(date_key, 0),
                'succeeded': daily_success.get(date_key, 0),
                'failed': daily_failure.get(date_key, 0)
            })
            current_date += timedelta(days=1)

        return {
            'period': {
                'start_date': start_date.isoformat(),
                'end_date': end_date.isoformat(),
                'days': days
            },
            'summary': {
                'total_executions': total_executions,
                'success_count': success_count,
                'failure_count': failure_count,
                'running_count': status_counts.get('RUNNING', 0),
                'success_rate': round(success_rate, 2),
                'avg_duration_seconds': round(avg_duration, 2)
            },
            'status_distribution': dict(status_counts),
            'daily_trends': daily_trends,
            'duration_stats': {
                'min': round(min(durations), 2) if durations else 0,
                'max': round(max(durations), 2) if durations else 0,
                'avg': round(avg_duration, 2),
                'median': round(sorted(durations)[len(durations)//2], 2) if durations else 0
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/analytics/errors")
async def get_error_analysis(limit: int = Query(100, ge=1, le=500)):
    """
    Analyze and group common errors across executions.

    Returns error patterns, frequencies, and affected executions.
    """
    try:
        from collections import defaultdict

        # Get all executions and filter failed ones
        all_executions = await sfn_service.list_all_executions(max_results=limit)
        failed_executions = [e for e in all_executions if e.get('status') in ['FAILED', 'TIMED_OUT', 'ABORTED']]

        error_groups = defaultdict(lambda: {'count': 0, 'executions': [], 'first_seen': None, 'last_seen': None})

        for exec in failed_executions[:limit]:
            # Get execution details for error information
            try:
                details = await sfn_service.describe_execution(exec['executionArn'])
                error_msg = details.error or 'Unknown error'

                # Group similar errors
                error_key = error_msg[:100]  # Group by first 100 chars
                error_groups[error_key]['count'] += 1
                error_groups[error_key]['executions'].append({
                    'execution_id': exec['name'],
                    'execution_arn': exec['executionArn'],
                    'start_time': exec.get('startDate')
                })

                # Track timestamps
                start_time = exec.get('startDate')
                if start_time:
                    if not error_groups[error_key]['first_seen'] or start_time < error_groups[error_key]['first_seen']:
                        error_groups[error_key]['first_seen'] = start_time
                    if not error_groups[error_key]['last_seen'] or start_time > error_groups[error_key]['last_seen']:
                        error_groups[error_key]['last_seen'] = start_time
            except Exception as e:
                print(f"Error analyzing execution {exec.get('name')}: {e}")
                continue

        # Convert to list and sort by frequency
        error_list = [
            {
                'error_message': error_msg,
                'count': data['count'],
                'first_seen': data['first_seen'],
                'last_seen': data['last_seen'],
                'affected_executions': data['executions'][:5]  # Limit to 5 examples
            }
            for error_msg, data in error_groups.items()
        ]
        error_list.sort(key=lambda x: x['count'], reverse=True)

        return {
            'total_errors': len(error_list),
            'total_failed_executions': len(failed_executions),
            'error_groups': error_list
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/analytics/performance")
async def get_performance_analysis(execution_arn: str = Query(..., description="Execution ARN to analyze")):
    """
    Analyze performance of a specific execution.

    Returns detailed performance metrics, bottlenecks, and state timings.
    """
    try:
        # Get execution details and history
        execution = await sfn_service.describe_execution(execution_arn)
        history = await sfn_service.get_execution_history(execution_arn)

        # Analyze state durations
        state_durations = {}
        state_entries = {}
        state_exits = {}

        for event in history:
            event_type = event.get('type', '')
            timestamp = event.get('timestamp')

            # Track state entered/exited events
            if 'StateEntered' in event_type:
                state_name = event.get('stateEnteredEventDetails', {}).get('name')
                if state_name:
                    state_entries[state_name] = timestamp
            elif 'StateExited' in event_type:
                state_name = event.get('stateExitedEventDetails', {}).get('name')
                if state_name and state_name in state_entries:
                    entry_time = datetime.fromisoformat(str(state_entries[state_name]).replace('Z', '+00:00'))
                    exit_time = datetime.fromisoformat(str(timestamp).replace('Z', '+00:00'))
                    duration = (exit_time - entry_time).total_seconds()

                    if state_name not in state_durations:
                        state_durations[state_name] = []
                    state_durations[state_name].append(duration)

        # Calculate statistics for each state
        state_stats = []
        total_duration = 0

        for state_name, durations in state_durations.items():
            avg_duration = sum(durations) / len(durations)
            total_duration += sum(durations)
            state_stats.append({
                'state_name': state_name,
                'executions': len(durations),
                'total_duration': round(sum(durations), 2),
                'avg_duration': round(avg_duration, 2),
                'min_duration': round(min(durations), 2),
                'max_duration': round(max(durations), 2)
            })

        # Sort by total duration (descending) to find bottlenecks
        state_stats.sort(key=lambda x: x['total_duration'], reverse=True)

        # Calculate percentage of total time for each state
        for stat in state_stats:
            stat['percentage'] = round((stat['total_duration'] / total_duration * 100), 2) if total_duration > 0 else 0

        # Identify bottlenecks (states taking >20% of total time)
        bottlenecks = [s for s in state_stats if s['percentage'] > 20]

        return {
            'execution_id': execution.execution_id,
            'execution_arn': execution_arn,
            'status': execution.status,
            'total_duration': round(total_duration, 2),
            'total_events': len(history),
            'state_performance': state_stats,
            'bottlenecks': bottlenecks,
            'recommendations': [
                f"Consider optimizing '{b['state_name']}' which takes {b['percentage']}% of execution time"
                for b in bottlenecks
            ]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/search/advanced")
async def advanced_search(
    status: Optional[str] = Query(None, description="Filter by status"),
    start_date: Optional[str] = Query(None, description="Start date (ISO format)"),
    end_date: Optional[str] = Query(None, description="End date (ISO format)"),
    min_duration: Optional[float] = Query(None, description="Minimum duration in seconds"),
    max_duration: Optional[float] = Query(None, description="Maximum duration in seconds"),
    search_input: Optional[str] = Query(None, description="Search in execution input"),
    search_output: Optional[str] = Query(None, description="Search in execution output"),
    limit: int = Query(50, ge=1, le=500)
):
    """
    Advanced search for executions with multiple filters.

    Supports filtering by status, date range, duration, and content search.
    """
    try:
        # Get executions
        all_executions = await sfn_service.list_executions(
            max_results=limit,
            status_filter=status
        )

        filtered_executions = []

        for exec in all_executions:
            # Date filter
            if start_date:
                start_dt = datetime.fromisoformat(start_date)
                exec_start = datetime.fromisoformat(str(exec.get('start_time')).replace('Z', '+00:00'))
                if exec_start < start_dt:
                    continue

            if end_date:
                end_dt = datetime.fromisoformat(end_date)
                exec_start = datetime.fromisoformat(str(exec.get('start_time')).replace('Z', '+00:00'))
                if exec_start > end_dt:
                    continue

            # Duration filter
            if (min_duration or max_duration) and exec.get('start_time') and exec.get('stop_time'):
                start = datetime.fromisoformat(str(exec['start_time']).replace('Z', '+00:00'))
                stop = datetime.fromisoformat(str(exec['stop_time']).replace('Z', '+00:00'))
                duration = (stop - start).total_seconds()

                if min_duration and duration < min_duration:
                    continue
                if max_duration and duration > max_duration:
                    continue

            # Content search (requires fetching full execution details)
            if search_input or search_output:
                try:
                    details = await sfn_service.describe_execution(exec['execution_arn'])

                    if search_input and search_input.lower() not in str(details.input).lower():
                        continue
                    if search_output and search_output.lower() not in str(details.output).lower():
                        continue
                except:
                    continue

            filtered_executions.append(exec)

        return {
            'total': len(filtered_executions),
            'executions': filtered_executions,
            'filters_applied': {
                'status': status,
                'start_date': start_date,
                'end_date': end_date,
                'min_duration': min_duration,
                'max_duration': max_duration,
                'search_input': search_input,
                'search_output': search_output
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/templates")
async def list_workflow_templates():
    """
    List all available workflow templates.

    Returns workflow templates with metadata including category, complexity, and features.
    """
    try:
        workflows = workflow_manager.get_available_workflows()
        return {
            "total": len(workflows),
            "workflows": workflows
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/templates/{workflow_id}")
async def get_workflow_template(workflow_id: str):
    """
    Get detailed information about a specific workflow template.

    Includes definition, schema, and usage examples.
    """
    try:
        definition = workflow_manager.get_workflow_definition(workflow_id)
        if not definition:
            raise HTTPException(status_code=404, detail=f"Workflow {workflow_id} not found")

        schema = workflow_manager.get_workflow_schema(workflow_id)

        return {
            "workflow_id": workflow_id,
            "definition": definition,
            "input_schema": schema,
            "example_input": schema.get("example", {})
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/templates/{workflow_id}/deploy")
async def deploy_workflow_template(workflow_id: str, name: Optional[str] = None):
    """
    Deploy a workflow template to Step Functions.

    Creates or updates a state machine from the template.
    """
    try:
        result = workflow_manager.deploy_workflow(workflow_id, name)
        return result
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/templates/{workflow_id}/execute")
async def execute_workflow_template(workflow_id: str, input_data: dict, execution_name: Optional[str] = None):
    """
    Deploy (if needed) and execute a workflow template.

    Automatically deploys the workflow if not already deployed, then starts execution.
    """
    try:
        result = workflow_manager.start_workflow_execution(
            workflow_id=workflow_id,
            input_data=input_data,
            execution_name=execution_name
        )
        return result
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/files/upload/batch")
async def upload_files_batch(
    files: List[UploadFile] = File(...),
    bucket: str = Form(...),
    prefix: str = Form("uploads")
):
    """
    Upload multiple files to S3 in batch.

    Supports uploading up to 100 files at once for workflow processing.
    """
    try:
        uploaded_files = []

        for file in files:
            # Generate S3 key
            s3_key = f"{prefix}/{file.filename}"

            # Read file content
            content = await file.read()

            # Upload to S3
            await s3_service.upload_file(
                bucket=bucket,
                key=s3_key,
                content=content
            )

            uploaded_files.append({
                'bucket': bucket,
                'file_key': s3_key,
                'file_id': file.filename,
                'size': len(content)
            })

        return {
            'uploaded': len(uploaded_files),
            'files': uploaded_files
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/files/validate-batch")
async def validate_files_batch(files: List[dict]):
    """
    Validate a batch of file references before processing.

    Checks if files exist in S3 and returns validation results.
    """
    try:
        validation_results = []

        for file_ref in files:
            bucket = file_ref.get('bucket')
            key = file_ref.get('file_key')

            if not bucket or not key:
                validation_results.append({
                    'file': file_ref,
                    'valid': False,
                    'error': 'Missing bucket or file_key'
                })
                continue

            try:
                # Check if file exists
                file_exists = await s3_service.file_exists(bucket, key)

                if file_exists:
                    # Get file metadata
                    metadata = await s3_service.get_file_metadata(bucket, key)
                    validation_results.append({
                        'file': file_ref,
                        'valid': True,
                        'size': metadata.get('size', 0),
                        'last_modified': metadata.get('last_modified')
                    })
                else:
                    validation_results.append({
                        'file': file_ref,
                        'valid': False,
                        'error': 'File not found in S3'
                    })
            except Exception as e:
                validation_results.append({
                    'file': file_ref,
                    'valid': False,
                    'error': str(e)
                })

        valid_count = sum(1 for r in validation_results if r['valid'])
        invalid_count = len(validation_results) - valid_count

        return {
            'total': len(validation_results),
            'valid': valid_count,
            'invalid': invalid_count,
            'results': validation_results
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/manifests/generate")
async def generate_manifest(
    files: Optional[List[dict]] = None,
    source_bucket: Optional[str] = None,
    source_prefix: Optional[str] = None,
    output_bucket: str = Query(...),
    output_key: str = Query(...),
    format: str = Query('CSV', regex='^(CSV|JSON)$'),
    max_files: Optional[int] = None
):
    """
    Generate an S3 manifest file for distributed map processing.

    Either provide explicit file list OR source_bucket + source_prefix to scan.
    """
    try:
        if files:
            # Generate from explicit file list
            if format.upper() == 'JSON':
                result = manifest_generator.generate_json_manifest(
                    files=files,
                    output_bucket=output_bucket,
                    output_key=output_key
                )
            else:
                result = manifest_generator.generate_csv_manifest(
                    files=files,
                    output_bucket=output_bucket,
                    output_key=output_key
                )
        elif source_bucket and source_prefix:
            # Generate from S3 prefix scan
            result = manifest_generator.generate_manifest_from_s3_prefix(
                source_bucket=source_bucket,
                source_prefix=source_prefix,
                output_bucket=output_bucket,
                output_key=output_key,
                format=format,
                max_files=max_files
            )
        else:
            raise HTTPException(
                status_code=400,
                detail="Must provide either 'files' array OR 'source_bucket' + 'source_prefix'"
            )

        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/manifests/validate")
async def validate_manifest(
    manifest_bucket: str = Query(...),
    manifest_key: str = Query(...)
):
    """
    Validate a manifest file for distributed map processing.

    Checks format, required columns, and file count.
    """
    try:
        result = manifest_generator.validate_manifest(
            manifest_bucket=manifest_bucket,
            manifest_key=manifest_key
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/manifests/test")
async def create_test_manifest(
    file_count: int = Query(..., ge=1, le=100000),
    bucket: str = Query(...),
    prefix: str = Query('test-files'),
    output_bucket: str = Query(...),
    output_key: str = Query(...)
):
    """
    Create a test manifest with dummy file entries.

    Useful for testing distributed map workflows without uploading actual files.
    """
    try:
        result = manifest_generator.create_test_manifest(
            file_count=file_count,
            bucket=bucket,
            prefix=prefix,
            output_bucket=output_bucket,
            output_key=output_key
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/progress/{execution_id}")
async def get_execution_progress(execution_id: str):
    """
    Get real-time progress for a workflow execution.

    Returns current progress metrics, statistics, and recent events.
    """
    try:
        # Get progress data
        progress = await progress_tracker.get_progress(execution_id)

        if not progress:
            raise HTTPException(status_code=404, detail=f"Execution {execution_id} not found")

        # Get recent events
        recent_events = await progress_tracker.get_recent_events(execution_id, limit=20)

        return ProgressResponse(
            execution_id=execution_id,
            progress=progress,
            recent_events=recent_events
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/progress/update")
async def update_execution_progress(request: ProgressUpdateRequest):
    """
    Update execution progress (internal endpoint for workflow callbacks).

    This endpoint is called by workflow states to report progress.
    """
    try:
        progress = await progress_tracker.update_progress(request)
        return {"status": "updated", "progress": progress}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/progress/{execution_id}/events")
async def get_progress_events(
    execution_id: str,
    limit: int = Query(50, ge=1, le=1000)
):
    """
    Get progress events for an execution.

    Returns a timeline of all progress events.
    """
    try:
        events = await progress_tracker.get_recent_events(execution_id, limit=limit)
        return {
            "execution_id": execution_id,
            "event_count": len(events),
            "events": events
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/progress/{execution_id}/stream")
async def stream_execution_progress(execution_id: str):
    """
    Server-Sent Events (SSE) endpoint for real-time progress streaming.

    This provides a persistent connection for receiving progress updates.
    """
    from fastapi.responses import StreamingResponse
    import asyncio
    import json

    async def event_generator():
        """Generate SSE events for progress updates."""
        try:
            # Send initial progress
            progress = await progress_tracker.get_progress(execution_id)
            if progress:
                yield f"data: {json.dumps({'type': 'progress', 'data': progress.dict()})}\n\n"

            # Poll for updates every 2 seconds
            last_update = datetime.utcnow()

            while True:
                await asyncio.sleep(2)

                # Get updated progress
                progress = await progress_tracker.get_progress(execution_id)

                if not progress:
                    yield f"data: {json.dumps({'type': 'error', 'message': 'Execution not found'})}\n\n"
                    break

                # Check if there are new updates
                if progress.last_updated > last_update:
                    last_update = progress.last_updated

                    yield f"data: {json.dumps({'type': 'progress', 'data': progress.dict()})}\n\n"

                # Stop if execution is complete
                if progress.status in ['SUCCEEDED', 'FAILED', 'TIMED_OUT', 'ABORTED']:
                    yield f"data: {json.dumps({'type': 'completed', 'status': progress.status})}\n\n"
                    break

        except asyncio.CancelledError:
            # Client disconnected
            pass
        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        }
    )


@router.post("/files/upload/multipart/initiate")
async def initiate_multipart_upload(
    bucket: str = Form(...),
    key: str = Form(...),
    file_size: int = Form(...),
    content_type: Optional[str] = Form(None)
):
    """
    Initiate a multipart upload for large files.

    Returns upload_id and part configuration for client-side uploading.
    """
    try:
        # Initiate multipart upload
        upload_details = multipart_uploader.initiate_multipart_upload(
            bucket=bucket,
            key=key,
            content_type=content_type
        )

        # Calculate part configuration
        part_config = multipart_uploader.calculate_parts(file_size=file_size)

        # Generate presigned URLs for each part
        presigned_urls = []
        for part in part_config['parts']:
            url = multipart_uploader.generate_presigned_upload_part_url(
                bucket=bucket,
                key=key,
                upload_id=upload_details['upload_id'],
                part_number=part['part_number']
            )
            presigned_urls.append({
                'part_number': part['part_number'],
                'url': url,
                'start_byte': part['start_byte'],
                'end_byte': part['end_byte'],
                'size': part['size']
            })

        return {
            'upload_id': upload_details['upload_id'],
            'bucket': bucket,
            'key': key,
            'part_config': part_config,
            'presigned_urls': presigned_urls
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/files/upload/multipart/complete")
async def complete_multipart_upload(
    bucket: str = Body(...),
    key: str = Body(...),
    upload_id: str = Body(...),
    parts: list = Body(...)
):
    """
    Complete a multipart upload.

    Args:
        bucket: S3 bucket name
        key: S3 object key
        upload_id: Multipart upload ID
        parts: List of uploaded parts with ETags
    """
    try:
        result = multipart_uploader.complete_multipart_upload(
            bucket=bucket,
            key=key,
            upload_id=upload_id,
            parts=parts
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/files/upload/multipart/abort")
async def abort_multipart_upload(
    bucket: str = Body(...),
    key: str = Body(...),
    upload_id: str = Body(...)
):
    """
    Abort a multipart upload.

    Cancels the upload and frees up S3 storage.
    """
    try:
        result = multipart_uploader.abort_multipart_upload(
            bucket=bucket,
            key=key,
            upload_id=upload_id
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/executions/{execution_arn:path}/stop")
async def stop_execution(execution_arn: str, reason: Optional[str] = Body(None)):
    """
    Stop a running workflow execution.

    Args:
        execution_arn: Full ARN of the execution
        reason: Optional reason for stopping
    """
    try:
        result = await sfn_service.stop_execution(
            execution_arn=execution_arn,
            error="ExecutionStopped",
            cause=reason or "Stopped by user request"
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/executions/{execution_arn:path}/resume")
async def resume_execution(
    execution_arn: str,
    checkpoint_data: Optional[dict] = Body(None)
):
    """
    Resume a stopped execution from checkpoint.

    Note: This requires the workflow to support resume functionality.
    For now, this starts a new execution with checkpoint data.
    """
    try:
        # Get the original execution details
        execution = await sfn_service.describe_execution(execution_arn)

        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")

        # Parse the original input
        import json
        original_input = json.loads(execution.input) if isinstance(execution.input, str) else execution.input

        # Merge with checkpoint data
        if checkpoint_data:
            original_input['checkpoint'] = checkpoint_data
            original_input['resume'] = True

        # Start a new execution with checkpoint
        state_machine_arn = execution_arn.rsplit(':', 1)[0].replace(':execution:', ':stateMachine:')

        new_execution = sfn_service.client.start_execution(
            stateMachineArn=state_machine_arn,
            name=f"{execution.execution_id}-resume-{int(datetime.utcnow().timestamp())}",
            input=json.dumps(original_input)
        )

        return {
            'status': 'resumed',
            'original_execution_arn': execution_arn,
            'new_execution_arn': new_execution['executionArn'],
            'new_execution_id': new_execution['executionArn'].split(':')[-1],
            'start_date': new_execution.get('startDate')
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/executions/{execution_arn:path}/parameters")
async def update_execution_parameters(
    execution_arn: str,
    parameters: dict = Body(...)
):
    """
    Update parameters for a running execution.

    Note: This feature requires workflow states to poll for parameter updates.
    For now, this stores parameters in DynamoDB for the workflow to read.
    """
    try:
        # Store updated parameters in DynamoDB
        execution_id = execution_arn.split(':')[-1]

        await db_service.save_execution_history(
            execution_id=execution_id,
            execution_data={
                'updated_parameters': parameters,
                'parameter_update_time': datetime.utcnow().isoformat()
            }
        )

        return {
            'status': 'updated',
            'execution_arn': execution_arn,
            'parameters': parameters,
            'message': 'Parameters stored. Workflow must poll for updates.'
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
