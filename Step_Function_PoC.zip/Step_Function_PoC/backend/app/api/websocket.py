"""WebSocket API for real-time execution updates."""
import asyncio
import json
from typing import Dict, Set
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from datetime import datetime
from app.services.stepfunctions import StepFunctionsService
from app.services.dynamodb import DynamoDBService
from app.models.schemas import WebSocketMessage

router = APIRouter()

# Active WebSocket connections
active_connections: Dict[str, Set[WebSocket]] = {}

sfn_service = StepFunctionsService()
db_service = DynamoDBService()


class ConnectionManager:
    """Manage WebSocket connections."""
    
    def __init__(self):
        self.active_connections: Dict[str, Set[WebSocket]] = {}
    
    async def connect(self, websocket: WebSocket, execution_id: str):
        """Connect a WebSocket for a specific execution."""
        await websocket.accept()
        
        if execution_id not in self.active_connections:
            self.active_connections[execution_id] = set()
        
        self.active_connections[execution_id].add(websocket)
        print(f"Client connected to execution {execution_id}. Total connections: {len(self.active_connections[execution_id])}")
    
    def disconnect(self, websocket: WebSocket, execution_id: str):
        """Disconnect a WebSocket."""
        if execution_id in self.active_connections:
            self.active_connections[execution_id].discard(websocket)
            
            if not self.active_connections[execution_id]:
                del self.active_connections[execution_id]
        
        print(f"Client disconnected from execution {execution_id}")
    
    async def send_message(self, message: dict, execution_id: str):
        """Send a message to all connected clients for an execution."""
        if execution_id not in self.active_connections:
            return
        
        disconnected = set()
        
        for connection in self.active_connections[execution_id]:
            try:
                await connection.send_json(message)
            except Exception as e:
                print(f"Error sending message: {e}")
                disconnected.add(connection)
        
        # Remove disconnected clients
        for connection in disconnected:
            self.disconnect(connection, execution_id)
    
    async def broadcast(self, message: dict):
        """Broadcast a message to all connected clients."""
        for execution_id in list(self.active_connections.keys()):
            await self.send_message(message, execution_id)


manager = ConnectionManager()


@router.websocket("/ws/execution/{execution_id}")
async def websocket_endpoint(websocket: WebSocket, execution_id: str):
    """
    WebSocket endpoint for real-time execution updates.
    
    Clients can connect to receive:
    - Execution status changes
    - Chunk processing progress
    - Streaming output from Lambda functions
    - Error notifications
    """
    await manager.connect(websocket, execution_id)
    
    try:
        # Start monitoring task
        monitor_task = asyncio.create_task(monitor_execution(execution_id, websocket))
        
        # Keep connection alive and handle incoming messages
        while True:
            try:
                # Receive messages from client (for heartbeat or commands)
                data = await asyncio.wait_for(websocket.receive_text(), timeout=30.0)
                message = json.loads(data)
                
                # Handle client messages
                if message.get('type') == 'ping':
                    await websocket.send_json({
                        'type': 'pong',
                        'timestamp': datetime.utcnow().isoformat()
                    })
                
            except asyncio.TimeoutError:
                # Send heartbeat
                await websocket.send_json({
                    'type': 'heartbeat',
                    'timestamp': datetime.utcnow().isoformat()
                })
                
    except WebSocketDisconnect:
        manager.disconnect(websocket, execution_id)
        monitor_task.cancel()
    except Exception as e:
        print(f"WebSocket error: {e}")
        manager.disconnect(websocket, execution_id)
        if 'monitor_task' in locals():
            monitor_task.cancel()


async def monitor_execution(execution_id: str, websocket: WebSocket):
    """
    Monitor an execution and send updates via WebSocket.
    
    Args:
        execution_id: Execution to monitor
        websocket: WebSocket connection
    """
    try:
        # Find execution ARN
        executions = await sfn_service.list_executions(max_results=100)
        execution_arn = None
        
        for exec in executions:
            if exec['name'] == execution_id:
                execution_arn = exec['executionArn']
                break
        
        if not execution_arn:
            await websocket.send_json({
                'type': 'error',
                'execution_id': execution_id,
                'timestamp': datetime.utcnow().isoformat(),
                'data': {'error': 'Execution not found'}
            })
            return
        
        # Poll for updates
        previous_status = None
        
        while True:
            try:
                # Get current execution status
                status = await sfn_service.describe_execution(execution_arn)
                
                # Send status update if changed
                if status.status != previous_status:
                    await manager.send_message({
                        'type': 'status',
                        'execution_id': execution_id,
                        'timestamp': datetime.utcnow().isoformat(),
                        'data': {
                            'status': status.status.value,
                            'start_time': status.start_time.isoformat(),
                            'stop_time': status.stop_time.isoformat() if status.stop_time else None
                        }
                    }, execution_id)
                    
                    previous_status = status.status
                
                # Get execution state from DynamoDB
                states = await db_service.get_all_execution_states(execution_id)
                
                if states:
                    # Calculate progress
                    total_files = len(states)
                    completed_files = sum(1 for s in states if s.get('state', {}).get('status') == 'completed')
                    
                    await manager.send_message({
                        'type': 'progress',
                        'execution_id': execution_id,
                        'timestamp': datetime.utcnow().isoformat(),
                        'data': {
                            'total_files': total_files,
                            'completed_files': completed_files,
                            'progress_percentage': (completed_files / total_files * 100) if total_files > 0 else 0,
                            'file_states': states[:10]  # Send sample of states
                        }
                    }, execution_id)
                
                # Break if execution is complete
                if status.status in ['SUCCEEDED', 'FAILED', 'TIMED_OUT', 'ABORTED']:
                    await manager.send_message({
                        'type': 'complete',
                        'execution_id': execution_id,
                        'timestamp': datetime.utcnow().isoformat(),
                        'data': {
                            'status': status.status.value,
                            'final_output': status.output
                        }
                    }, execution_id)
                    break
                
                # Wait before next poll
                await asyncio.sleep(2)
                
            except Exception as e:
                await manager.send_message({
                    'type': 'error',
                    'execution_id': execution_id,
                    'timestamp': datetime.utcnow().isoformat(),
                    'data': {'error': str(e)}
                }, execution_id)
                await asyncio.sleep(5)
    
    except asyncio.CancelledError:
        print(f"Monitoring cancelled for execution {execution_id}")
    except Exception as e:
        print(f"Error monitoring execution: {e}")


@router.websocket("/ws/stream")
async def stream_websocket():
    """
    Global WebSocket endpoint for streaming all executions.
    
    Clients can connect to receive updates from all active executions.
    """
    websocket = await websocket.accept()
    
    try:
        while True:
            data = await websocket.receive_text()
            # Handle global streaming logic
            await websocket.send_text(f"Echo: {data}")
    except WebSocketDisconnect:
        print("Global stream client disconnected")