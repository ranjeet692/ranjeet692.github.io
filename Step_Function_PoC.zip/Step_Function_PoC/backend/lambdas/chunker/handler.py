import json

def handler(event, context):
    print(f"Chunker received: {json.dumps(event)}")
    file_key = event.get('file_key', '')
    file_size = event.get('file_size', 0)
    chunk_size = event.get('chunk_size', 5242880)  # 5MB default
    
    num_chunks = max(1, (file_size + chunk_size - 1) // chunk_size)
    
    chunks = []
    for i in range(num_chunks):
        chunks.append({
            'chunk_id': f"{file_key}_chunk_{i}",
            'file_key': file_key,
            'chunk_index': i,
            'chunk_size': chunk_size,
            'offset': i * chunk_size,
            'total_chunks': num_chunks
        })
    
    return {
        'statusCode': 200,
        'chunks': chunks,
        'total_chunks': num_chunks,
        'file_key': file_key
    }