import json
import boto3
import os

s3_client = boto3.client(
    's3',
    endpoint_url=os.environ.get('AWS_ENDPOINT_URL', 'http://localstack:4566'),
    aws_access_key_id='test',
    aws_secret_access_key='test',
    region_name='us-east-1'
)

def handler(event, context):
    print(f"Chunker received: {json.dumps(event)}")
    
    source_bucket = event.get('source_bucket', 'document-processing-bucket')
    file_key = event.get('file_key', '')
    chunk_size = event.get('chunk_size', 5242880)  # 5MB default
    chunks_bucket = 'document-chunks'
    
    try:
        # Get file metadata
        response = s3_client.head_object(Bucket=source_bucket, Key=file_key)
        file_size = response['ContentLength']
        
        # Download the file
        file_obj = s3_client.get_object(Bucket=source_bucket, Key=file_key)
        file_content = file_obj['Body'].read()
        
        num_chunks = max(1, (file_size + chunk_size - 1) // chunk_size)
        
        chunks = []
        for i in range(num_chunks):
            start = i * chunk_size
            end = min(start + chunk_size, file_size)
            chunk_data = file_content[start:end]
            
            # Save chunk to S3
            chunk_key = f"chunks/{file_key}/chunk_{i}.bin"
            s3_client.put_object(
                Bucket=chunks_bucket,
                Key=chunk_key,
                Body=chunk_data
            )
            
            chunk_s3_uri = f"s3://{chunks_bucket}/{chunk_key}"
            
            chunks.append({
                'chunk_id': f"{file_key}_chunk_{i}",
                'file_key': file_key,
                'chunk_index': i,
                'chunk_size': len(chunk_data),
                'offset': start,
                'total_chunks': num_chunks,
                's3_uri': chunk_s3_uri,
                's3_bucket': chunks_bucket,
                's3_key': chunk_key
            })
        
        print(f"Created {num_chunks} chunks for {file_key}")
        
        return {
            'statusCode': 200,
            'chunks': chunks,
            'total_chunks': num_chunks,
            'file_key': file_key,
            'source_bucket': source_bucket
        }
    except Exception as e:
        print(f"Error chunking file: {str(e)}")
        raise e