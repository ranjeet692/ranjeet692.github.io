"""Result aggregator Lambda function.

Aggregates results from all chunks of a file into a final result.
"""
import json


def handler(event, context):
    """
    Aggregate results from all file chunks.
    
    Event structure (array of chunk results):
    [
        {
            "chunk_id": "...",
            "file_key": "...",
            "entities_found": 25,
            "summary": {...},
            ...
        },
        ...
    ]
    
    Returns:
    {
        "statusCode": 200,
        "file_key": "...",
        "aggregated_results": {...}
    }
    """
    print(f"Aggregator received {len(event)} chunk results")
    
    if not event or len(event) == 0:
        return {
            'statusCode': 400,
            'error': 'No chunk results provided'
        }
    
    # Extract file key from first chunk
    file_key = event[0].get('file_key', 'unknown')
    
    # Aggregate statistics
    total_chunks = len(event)
    total_entities = 0
    total_processing_time = 0
    all_entities = []
    all_topics = set()
    chunk_summaries = []
    sentiments = []
    
    for chunk_result in event:
        # Accumulate entities
        entities_found = chunk_result.get('entities_found', 0)
        total_entities += entities_found
        
        # Collect entities
        chunk_entities = chunk_result.get('entities', [])
        all_entities.extend(chunk_entities)
        
        # Accumulate processing time
        processing_time = chunk_result.get('processing_time', 0)
        total_processing_time += processing_time
        
        # Collect summaries
        summary = chunk_result.get('summary', {})
        chunk_summaries.append({
            'chunk_id': chunk_result.get('chunk_id'),
            'chunk_index': chunk_result.get('chunk_index'),
            'summary': summary
        })
        
        # Collect topics
        topics = summary.get('key_topics', [])
        all_topics.update(topics)
        
        # Collect sentiments
        sentiment = summary.get('sentiment')
        if sentiment:
            sentiments.append(sentiment)
    
    # Determine overall sentiment
    sentiment_counts = {}
    for s in sentiments:
        sentiment_counts[s] = sentiment_counts.get(s, 0) + 1
    
    overall_sentiment = max(sentiment_counts, key=sentiment_counts.get) if sentiment_counts else 'neutral'
    
    # Create entity distribution
    entity_types = {}
    for entity in all_entities:
        entity_type = entity.get('type', 'UNKNOWN')
        entity_types[entity_type] = entity_types.get(entity_type, 0) + 1
    
    # Build aggregated results
    aggregated = {
        'file_key': file_key,
        'total_chunks': total_chunks,
        'total_entities': total_entities,
        'entity_distribution': entity_types,
        'unique_topics': list(all_topics),
        'overall_sentiment': overall_sentiment,
        'sentiment_distribution': sentiment_counts,
        'total_processing_time': total_processing_time,
        'average_processing_time_per_chunk': total_processing_time / total_chunks if total_chunks > 0 else 0,
        'chunk_summaries': chunk_summaries,
        'sample_entities': all_entities[:50],  # Top 50 entities
        'status': 'completed',
        'metadata': {
            'aggregation_complete': True,
            'chunks_processed': total_chunks,
            'lambda_request_id': context.request_id if context else 'local'
        }
    }
    
    # Generate final document summary
    document_summary = {
        'title': file_key.split('/')[-1],
        'total_entities': total_entities,
        'entity_types_found': len(entity_types),
        'topics_identified': len(all_topics),
        'overall_sentiment': overall_sentiment,
        'processing_time_seconds': total_processing_time,
        'chunks_processed': total_chunks
    }
    
    response = {
        'statusCode': 200,
        'file_key': file_key,
        'aggregated_results': aggregated,
        'document_summary': document_summary
    }
    
    print(f"Aggregation complete for {file_key}:")
    print(f"  - {total_chunks} chunks processed")
    print(f"  - {total_entities} total entities found")
    print(f"  - {len(all_topics)} unique topics identified")
    print(f"  - Overall sentiment: {overall_sentiment}")
    
    return response


# For local testing
if __name__ == "__main__":
    test_event = [
        {
            'chunk_id': 'test_file.txt_chunk_0',
            'file_key': 'documents/test_file.txt',
            'chunk_index': 0,
            'entities_found': 25,
            'processing_time': 45,
            'entities': [
                {'type': 'PERSON', 'text': 'John Doe', 'confidence': 0.95},
                {'type': 'ORGANIZATION', 'text': 'Acme Corp', 'confidence': 0.89}
            ],
            'summary': {
                'key_topics': ['business', 'technology', 'innovation'],
                'sentiment': 'positive'
            }
        },
        {
            'chunk_id': 'test_file.txt_chunk_1',
            'file_key': 'documents/test_file.txt',
            'chunk_index': 1,
            'entities_found': 18,
            'processing_time': 38,
            'entities': [
                {'type': 'LOCATION', 'text': 'New York', 'confidence': 0.92},
                {'type': 'DATE', 'text': '2025', 'confidence': 0.88}
            ],
            'summary': {
                'key_topics': ['finance', 'markets', 'technology'],
                'sentiment': 'neutral'
            }
        }
    ]
    
    class MockContext:
        request_id = 'test-request-id'
    
    result = handler(test_event, MockContext())
    print(json.dumps(result, indent=2))