import json
import boto3
import time
import os

s3_client = boto3.client(
    's3',
    endpoint_url=os.environ.get('AWS_ENDPOINT_URL', 'http://localstack:4566'),
    aws_access_key_id='test',
    aws_secret_access_key='test',
    region_name='us-east-1'
)

def handler(event, context):
    print(f"Aggregator received: {json.dumps(event)}")
    
    # Handle both list and dict inputs
    if isinstance(event, list):
        results = event
        file_key = results[0].get('file_key', 'unknown') if results and isinstance(results[0], dict) else 'unknown'
    else:
        results = event.get('results', []) if isinstance(event, dict) else []
        file_key = event.get('file_key', 'unknown') if isinstance(event, dict) else 'unknown'
    
    # Separate successful and failed chunks
    successful_chunks = []
    failed_chunks = []
    
    for result in results:
        if not isinstance(result, dict):
            continue
            
        if result.get('statusCode') == 200:
            successful_chunks.append({
                'chunk_id': result.get('chunk_id'),
                'chunk_index': result.get('chunk_index'),
                's3_uri': result.get('s3_uri'),
                'api_response': result.get('api_response'),
                'request_id': result.get('request_id'),
                'job_id': result.get('job_id'),
                'timestamp': result.get('processing_timestamp')
            })
        else:
            failed_chunks.append({
                'chunk_id': result.get('chunk_id'),
                'chunk_index': result.get('chunk_index'),
                'error': result.get('error'),
                'error_type': result.get('error_type')
            })
    
    # Compile aggregated results
    aggregated = {
        'file_key': file_key,
        'total_chunks': len(results),
        'successful_chunks': len(successful_chunks),
        'failed_chunks': len(failed_chunks),
        'status': 'completed' if len(failed_chunks) == 0 else 'partial_failure',
        'chunk_results': successful_chunks,
        'failures': failed_chunks,
        'aggregation_timestamp': time.time()
    }
    
    # Save aggregated results to S3
    results_key = f"results/{file_key}/aggregated_results_{int(time.time())}.json"
    try:
        s3_client.put_object(
            Bucket='document-processing-results',
            Key=results_key,
            Body=json.dumps(aggregated, indent=2),
            ContentType='application/json'
        )
        print(f"Saved aggregated results to s3://document-processing-results/{results_key}")
    except Exception as e:
        print(f"Warning: Could not save results to S3: {str(e)}")
    
    return {
        'statusCode': 200,
        'file_key': file_key,
        'aggregated_results': aggregated,
        'results_s3_uri': f"s3://document-processing-results/{results_key}"
    }