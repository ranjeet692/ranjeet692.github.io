import json
import boto3
import requests
import time
import os
from decimal import Decimal

s3_client = boto3.client(
    's3',
    endpoint_url=os.environ.get('AWS_ENDPOINT_URL', 'http://localstack:4566'),
    aws_access_key_id='test',
    aws_secret_access_key='test',
    region_name='us-east-1'
)

dynamodb = boto3.resource(
    'dynamodb',
    endpoint_url=os.environ.get('AWS_ENDPOINT_URL', 'http://localstack:4566'),
    aws_access_key_id='test',
    aws_secret_access_key='test',
    region_name='us-east-1'
)

state_table = dynamodb.Table('document-processing-state')

def update_progress(chunk_id, file_key, status, message, execution_id='unknown', job_id=None, attempt=None, max_attempts=None, output_data=None):
    """Update progress in DynamoDB for real-time tracking."""
    try:
        item = {
            'execution_id': execution_id,
            'file_id': file_key,
            'chunk_id': chunk_id,
            'status': status,
            'message': message,
            'timestamp': Decimal(str(time.time())),
            'updated_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        }

        if job_id:
            item['job_id'] = job_id
        if attempt is not None and max_attempts is not None:
            item['poll_attempt'] = attempt
            item['poll_max_attempts'] = max_attempts
            item['poll_progress'] = Decimal(str((attempt / max_attempts) * 100))
        if output_data:
            # Store the actual output data (truncate if too large for DynamoDB)
            output_str = json.dumps(output_data)
            if len(output_str) > 300000:  # DynamoDB item size limit is 400KB
                output_str = output_str[:300000] + '...[truncated]'
            item['output_data'] = output_str

        state_table.put_item(Item=item)
        print(f"Progress updated: {status} - {message}")
    except Exception as e:
        print(f"Failed to update progress: {str(e)}")

def poll_job_status(job_id, chunk_id, file_key, execution_id='unknown', job_type='extract', max_attempts=60, poll_interval=10):
    """
    Poll the job status API until completion or timeout.

    Args:
        job_id: The job ID to poll
        chunk_id: Chunk identifier for progress tracking
        file_key: File key for progress tracking
        execution_id: Step Functions execution ID
        job_type: Type of job ('extract', etc.)
        max_attempts: Maximum number of polling attempts (default: 60)
        poll_interval: Seconds between polls (default: 10)

    Returns:
        Final job result when completed
    """
    status_url = f"http://wbddocinteltech-development-alb-1625731440.ap-south-1.elb.amazonaws.com/v1/extract/jobs/{job_id}"

    print(f"Starting to poll job {job_id} (max {max_attempts} attempts, {poll_interval}s interval)")
    update_progress(chunk_id, file_key, 'polling', f'Starting to poll job {job_id}', execution_id=execution_id, job_id=job_id, attempt=0, max_attempts=max_attempts)

    for attempt in range(max_attempts):
        try:
            print(f"Polling attempt {attempt + 1}/{max_attempts} for job {job_id}")
            update_progress(chunk_id, file_key, 'polling', f'Polling attempt {attempt + 1}/{max_attempts}', execution_id=execution_id, job_id=job_id, attempt=attempt + 1, max_attempts=max_attempts)

            response = requests.get(status_url, timeout=30)
            response.raise_for_status()
            result = response.json()

            status = result.get('status', '').upper()
            print(f"Job {job_id} status: {status}")

            if status == 'COMPLETED' or status == 'SUCCEEDED':
                print(f"Job {job_id} completed successfully")
                update_progress(chunk_id, file_key, 'completed', f'Job {job_id} completed successfully', execution_id=execution_id, job_id=job_id, output_data=result)
                return result
            elif status == 'FAILED':
                error_msg = result.get('error', 'Job failed without error details')
                print(f"Job {job_id} failed: {error_msg}")
                update_progress(chunk_id, file_key, 'failed', f'Job failed: {error_msg}', execution_id=execution_id, job_id=job_id)
                raise Exception(f"Job processing failed: {error_msg}")
            elif status in ['QUEUED', 'PROCESSING', 'IN_PROGRESS']:
                # Job still in progress, continue polling
                update_progress(chunk_id, file_key, 'polling', f'Job {status}, attempt {attempt + 1}/{max_attempts}', execution_id=execution_id, job_id=job_id, attempt=attempt + 1, max_attempts=max_attempts)
                if attempt < max_attempts - 1:
                    print(f"Job {job_id} still {status}, waiting {poll_interval}s...")
                    time.sleep(poll_interval)
                else:
                    update_progress(chunk_id, file_key, 'timeout', f'Job timed out after {max_attempts * poll_interval}s', execution_id=execution_id, job_id=job_id)
                    raise Exception(f"Job {job_id} timed out after {max_attempts * poll_interval}s")
            else:
                print(f"Unknown status '{status}' for job {job_id}, continuing to poll...")
                update_progress(chunk_id, file_key, 'polling', f'Unknown status: {status}', execution_id=execution_id, job_id=job_id, attempt=attempt + 1, max_attempts=max_attempts)
                if attempt < max_attempts - 1:
                    time.sleep(poll_interval)

        except requests.exceptions.RequestException as e:
            print(f"Error polling job {job_id}: {str(e)}")
            update_progress(chunk_id, file_key, 'error', f'Polling error: {str(e)}', execution_id=execution_id, job_id=job_id, attempt=attempt + 1, max_attempts=max_attempts)
            if attempt < max_attempts - 1:
                print(f"Retrying in {poll_interval}s...")
                time.sleep(poll_interval)
            else:
                raise Exception(f"Failed to poll job status after {max_attempts} attempts: {str(e)}")

    raise Exception(f"Job {job_id} did not complete within timeout period")

def handler(event, context):
    print(f"Processor received: {json.dumps(event)}")

    # Handle both old and new input formats
    # New format: {"chunk": {...}, "execution_id": "..."}
    # Old format: {...chunk data...}
    if 'chunk' in event and 'execution_id' in event:
        chunk_data = event['chunk']
        execution_id = event['execution_id']
    else:
        chunk_data = event
        execution_id = 'unknown'

    chunk_id = chunk_data.get('chunk_id', 'unknown')
    file_key = chunk_data.get('file_key', 'unknown')
    chunk_index = chunk_data.get('chunk_index', 0)
    s3_bucket = chunk_data.get('s3_bucket', 'document-chunks')
    s3_key = chunk_data.get('s3_key', '')
    s3_uri = chunk_data.get('s3_uri', '')
    total_chunks = chunk_data.get('total_chunks', 1)

    # Update initial progress
    update_progress(chunk_id, file_key, 'started', f'Processing chunk {chunk_index + 1}/{total_chunks}', execution_id=execution_id)

    try:
        # Read chunk from S3
        print(f"Reading chunk from s3://{s3_bucket}/{s3_key}")
        update_progress(chunk_id, file_key, 'reading', f'Reading chunk {chunk_index + 1}/{total_chunks} from S3', execution_id=execution_id)
        response = s3_client.get_object(Bucket=s3_bucket, Key=s3_key)
        chunk_content = response['Body'].read()

        # Prepare API request
        api_url = "http://wbddocinteltech-development-alb-1625731440.ap-south-1.elb.amazonaws.com/v1/extract/extract"
        request_id = f"{chunk_id}_{int(time.time())}"
        request_body = {
            "async_mode": True,
            "features": [
                "TABLES",
                "FORMS"
            ],
            "input_s3": {
                "uri": 's3://wbddocinteltech-dev-datascience/uploads/20251010_072159_12345_resume-1.pdf'
            },
            "queries": [],
            "request_id": request_id
        }

        print(f"Calling API for chunk {chunk_index}/{total_chunks}")
        print(f"Request body: {json.dumps(request_body)}")
        update_progress(chunk_id, file_key, 'api_call', f'Calling external API for chunk {chunk_index + 1}/{total_chunks}', execution_id=execution_id)

        # Make initial API request
        api_response = requests.post(
            api_url,
            json=request_body,
            headers={'Content-Type': 'application/json'},
            timeout=60
        )

        api_response.raise_for_status()
        initial_result = api_response.json()

        print(f"Initial API response for {chunk_id}: {json.dumps(initial_result)}")

        # Check if job is queued and needs polling
        status = initial_result.get('status', '').upper()
        job_id = initial_result.get('job_id')

        if status == 'QUEUED' and job_id:
            print(f"Job {job_id} queued, starting polling...")
            update_progress(chunk_id, file_key, 'queued', f'Job {job_id} queued, starting polling', execution_id=execution_id, job_id=job_id)
            # Poll for completion with progress updates
            final_result = poll_job_status(job_id, chunk_id, file_key, execution_id=execution_id)
            api_result = final_result
        else:
            # Job completed immediately or synchronous response
            update_progress(chunk_id, file_key, 'completed', f'Job completed immediately', execution_id=execution_id, output_data=initial_result)
            api_result = initial_result

        print(f"Final API result for {chunk_id}: {json.dumps(api_result)}")

        return {
            'statusCode': 200,
            'chunk_id': chunk_id,
            'file_key': file_key,
            'chunk_index': chunk_index,
            'total_chunks': total_chunks,
            's3_uri': s3_uri,
            'api_response': api_result,
            'request_id': request_id,
            'job_id': job_id,
            'processing_timestamp': time.time()
        }

    except requests.exceptions.RequestException as e:
        print(f"API request error for {chunk_id}: {str(e)}")
        update_progress(chunk_id, file_key, 'failed', f'API error: {str(e)}', execution_id=execution_id)
        return {
            'statusCode': 500,
            'chunk_id': chunk_id,
            'file_key': file_key,
            'chunk_index': chunk_index,
            'error': str(e),
            'error_type': 'API_ERROR'
        }
    except Exception as e:
        print(f"Error processing chunk {chunk_id}: {str(e)}")
        update_progress(chunk_id, file_key, 'failed', f'Processing error: {str(e)}', execution_id=execution_id)
        return {
            'statusCode': 500,
            'chunk_id': chunk_id,
            'file_key': file_key,
            'chunk_index': chunk_index,
            'error': str(e),
            'error_type': 'PROCESSING_ERROR'
        }
