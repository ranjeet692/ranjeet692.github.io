import json
import time
import random

def handler(event, context):
    print(f"Processor received: {json.dumps(event)}")
    
    chunk_id = event.get('chunk_id', 'unknown')
    file_key = event.get('file_key', 'unknown')
    chunk_index = event.get('chunk_index', 0)
    
    # Simulate processing time (10s to 600s)
    processing_time = random.randint(10, 60)  # Reduced for demo
    
    print(f"Processing {chunk_id} for {processing_time} seconds...")
    
    # Simulate streaming output
    results = []
    for i in range(5):
        time.sleep(processing_time / 5)
        results.append({
            'timestamp': time.time(),
            'chunk_id': chunk_id,
            'progress': (i + 1) * 20,
            'partial_result': f"Processed segment {i+1}/5 of {chunk_id}"
        })
    
    return {
        'statusCode': 200,
        'chunk_id': chunk_id,
        'file_key': file_key,
        'chunk_index': chunk_index,
        'results': results,
        'processing_time': processing_time,
        'entities_found': random.randint(5, 50),
        'summary': f"Processed {chunk_id} successfully"
    }