from fastapi import Header, HTTPException, Depends
from typing import Annotated, Tuple, Optional
from app.core.config import settings
# from jose import jwt # Use for real JWT validation

# Placeholder type for a validated user session
# Returns (user_id, workspace_id, role_id)
# In production, this would validate a JWT token from the Authorization header
TenantUser = Annotated[Tuple[int, int, int], Depends]

# --- Mocking JWT Validation for Skeleton ---
async def mock_decode_jwt(authorization: Optional[str] = Header(None)) -> dict:
    """Mocks JWT validation and returns required claims."""
    if not authorization or authorization != "Bearer mock-auth-token":
        raise HTTPException(
            status_code=401, 
            detail="Unauthorized: Missing or invalid token"
        )
    
    # Mock decoded claims (User ID: 101, Workspace ID: 1, Role ID: 1 (Owner))
    # In a real app, these claims come from the validated JWT
    return {
        "sub": 101,
        "custom:tenant_id": 1,
        "custom:role_id": 1
    }

async def get_current_tenant_user(claims: dict = Depends(mock_decode_jwt)) -> Tuple[int, int, int]:
    """
    FastAPI Dependency to validate the user and extract tenant/role context.
    """
    user_id = claims.get("sub")
    workspace_id = claims.get("custom:tenant_id")
    role_id = claims.get("custom:role_id")
    
    if not user_id or not workspace_id or not role_id:
        raise HTTPException(status_code=401, detail="Token missing essential claims (user/tenant/role)")
        
    return user_id, workspace_id, role_id

async def check_role_access(required_role_id: int, current_user: Tuple[int, int, int] = Depends(get_current_tenant_user)):
    """
    Dependency to check if the current user meets the minimum required role level.
    Role IDs: 1 (Owner), 2 (Editor), 3 (Viewer)
    Lower number means higher privilege.
    """
    _, _, current_role_id = current_user
    if current_role_id > required_role_id:
        raise HTTPException(
            status_code=403, 
            detail=f"Forbidden: Insufficient permissions (Role ID: {current_role_id})"
        )
    # The user is authorized if their role ID is less than or equal to the required ID
    return True
