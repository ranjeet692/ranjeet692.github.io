from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional
from functools import lru_cache

class Settings(BaseSettings):
    """
    Application and environment settings.
    SettingsConfigDict enables reading from .env file.
    """
    model_config = SettingsConfigDict(
        env_file=".env", 
        env_file_encoding='utf-8', 
        case_sensitive=True
    )

    # General Settings
    APP_NAME: str = "AI Studio Backend"
    SECRET_KEY: str = "your-default-secret-key-please-change"
    ENVIRONMENT: str = "dev"
    UVICORN_PORT: int = 8000


    # Monitoring Settings
    ENABLE_METRICS: bool = False
    METRICS_PORT: int = 8000
    ENABLE_TRACING: bool = False
    TRACING_PORT: int = 8000
    LOG_LEVEL: str = "INFO"

    
    # Database Settings (PostgreSQL/RDS)
    POSTGRES_USER: str
    POSTGRES_PASSWORD: str
    POSTGRES_SERVER: str
    POSTGRES_PORT: int
    POSTGRES_DB: str
    
    # AWS Settings
    AWS_REGION: str = "us-east-1"
    AWS_STEP_FUNCTIONS_ARN: str = "arn:aws:states:..."
    DYNAMODB_USAGE_TABLE: str = "AIAppUsage"
    DYNAMODB_TABLE_DOCUMENTS: str = "AIAppDocuments"
    S3_BUCKET_DOCUMENTS: str = "aiapp-documents-bucket"
    CLOUDWATCH_NAMESPACE: str = "AIApp"


    # AWS Credentials
    AWS_ACCESS_KEY_ID: str
    AWS_SECRET_ACCESS_KEY: str
    
    # Cognito/Auth Settings
    COGNITO_POOL_ID: str = "us-east-1_XXXXXXXXX"
    COGNITO_AUDIENCE: str = "client_id_for_app"

    # LocalStack Settings
    USE_LOCALSTACK: bool = False
    LOCALSTACK_ENDPOINT_URL: Optional[str] = None
    
    @property
    def DATABASE_URL(self) -> str:
        """Constructs the async database URL."""
        if self.USE_LOCALSTACK:
            return "sqlite+aiosqlite:///./test.db"
        else:
            return f"postgresql+asyncpg://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}@{self.POSTGRES_SERVER}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"

@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance"""
    return Settings()

settings = Settings()
