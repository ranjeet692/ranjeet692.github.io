"""Monitoring and metrics"""

import time
from typing import Dict, Optional
from dataclasses import dataclass
import boto3

from app.core.config import settings


@dataclass
class Metrics:
    """Metrics collector"""
    
    def __init__(self):
        self.cloudwatch = None
        if settings.ENABLE_METRICS:
            self.cloudwatch = boto3.client('cloudwatch', region_name=settings.AWS_REGION)
    
    def record_request(
        self,
        method: str,
        path: str,
        status_code: int,
        duration: float
    ):
        """Record API request metrics"""
        if not self.cloudwatch:
            return
        
        try:
            self.cloudwatch.put_metric_data(
                Namespace=settings.CLOUDWATCH_NAMESPACE,
                MetricData=[
                    {
                        'MetricName': 'RequestDuration',
                        'Value': duration * 1000,  # Convert to ms
                        'Unit': 'Milliseconds',
                        'Dimensions': [
                            {'Name': 'Method', 'Value': method},
                            {'Name': 'Path', 'Value': path},
                            {'Name': 'StatusCode', 'Value': str(status_code)}
                        ]
                    },
                    {
                        'MetricName': 'RequestCount',
                        'Value': 1,
                        'Unit': 'Count',
                        'Dimensions': [
                            {'Name': 'Method', 'Value': method},
                            {'Name': 'Path', 'Value': path},
                            {'Name': 'StatusCode', 'Value': str(status_code)}
                        ]
                    }
                ]
            )
        except Exception as e:
            logger.error(f"Failed to record metrics: {e}")
    
    def record_rag_query(self, duration_ms: int, retrieval_ms: int, generation_ms: int):
        """Record RAG query metrics"""
        if not self.cloudwatch:
            return
        
        try:
            self.cloudwatch.put_metric_data(
                Namespace=settings.CLOUDWATCH_NAMESPACE,
                MetricData=[
                    {
                        'MetricName': 'RAGQueryDuration',
                        'Value': duration_ms,
                        'Unit': 'Milliseconds'
                    },
                    {
                        'MetricName': 'RAGRetrievalDuration',
                        'Value': retrieval_ms,
                        'Unit': 'Milliseconds'
                    },
                    {
                        'MetricName': 'RAGGenerationDuration',
                        'Value': generation_ms,
                        'Unit': 'Milliseconds'
                    }
                ]
            )
        except Exception as e:
            logger.error(f"Failed to record RAG metrics: {e}")


class Tracer:
    """Distributed tracing"""
    
    def __init__(self):
        self.enabled = settings.ENABLE_TRACING
    
    def start_span(self, name: str) -> Optional[Dict]:
        """Start a trace span"""
        if not self.enabled:
            return None
        
        return {
            'name': name,
            'start_time': time.time()
        }
    
    def end_span(self, span: Optional[Dict]):
        """End a trace span"""
        if not span:
            return
        
        duration = time.time() - span['start_time']
        # In production, send to X-Ray or similar
        logger.debug(f"Span {span['name']} took {duration:.3f}s")


# Global instances
metrics = Metrics()
tracer = Tracer()