from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from typing import AsyncGenerator
from app.core.config import settings
from app.models.sql.base import Base

# --- Engine Setup ---
engine = create_async_engine(
    settings.DATABASE_URL,
    echo=False,
    pool_size=10, 
    max_overflow=20
)

# --- Session Local ---
# Use expire_on_commit=False to allow ORM objects to be used outside the session block
AsyncSessionLocal = sessionmaker(
    engine, 
    class_=AsyncSession, 
    expire_on_commit=False
)

async def init_db():
    """Initializes the database structure (for dev/test)."""
    # NOTE: In production, use Alembic for migrations instead of create_all
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """Dependency to get an async database session."""
    async with AsyncSessionLocal() as session:
        yield session
