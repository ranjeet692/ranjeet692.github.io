"""Custom exceptions for the platform"""

from typing import Optional, Dict, Any


class GenAIPlatformException(Exception):
    """Base exception for all platform errors"""
    
    def __init__(
        self,
        message: str,
        error_code: str = "PLATFORM_ERROR",
        status_code: int = 500,
        details: Optional[Dict[str, Any]] = None
    ):
        self.message = message
        self.error_code = error_code
        self.status_code = status_code
        self.details = details or {}
        super().__init__(self.message)


class AuthenticationError(GenAIPlatformException):
    """Authentication failed"""
    def __init__(self, message: str = "Authentication failed"):
        super().__init__(message, "AUTH_ERROR", 401)


class AuthorizationError(GenAIPlatformException):
    """Authorization failed"""
    def __init__(self, message: str = "Insufficient permissions"):
        super().__init__(message, "AUTHZ_ERROR", 403)


class ResourceNotFoundError(GenAIPlatformException):
    """Resource not found"""
    def __init__(self, resource_type: str, resource_id: str):
        super().__init__(
            f"{resource_type} not found: {resource_id}",
            "NOT_FOUND",
            404
        )


class ValidationError(GenAIPlatformException):
    """Validation error"""
    def __init__(self, message: str, details: Optional[Dict] = None):
        super().__init__(message, "VALIDATION_ERROR", 400, details)


class QuotaExceededError(GenAIPlatformException):
    """User quota exceeded"""
    def __init__(self, quota_type: str, limit: int):
        super().__init__(
            f"Quota exceeded for {quota_type}: limit is {limit}",
            "QUOTA_EXCEEDED",
            429
        )


class ProcessingError(GenAIPlatformException):
    """Document processing error"""
    def __init__(self, message: str, details: Optional[Dict] = None):
        super().__init__(message, "PROCESSING_ERROR", 500, details)


class RateLimitError(GenAIPlatformException):
    """Rate limit exceeded"""
    def __init__(self, message: str = "Rate limit exceeded"):
        super().__init__(message, "RATE_LIMIT", 429)
