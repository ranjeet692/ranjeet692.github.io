import aioboto3
import json
from app.core.config import settings
from typing import Dict, Any

class StepFunctionsService:
    """
    Handles asynchronous interaction with AWS Step Functions.
    Uses aioboto3 for non-blocking I/O.
    """
    def __init__(self, region: str):
        self.region = region
        self.client = self._get_client()

    def _get_client(self):
        """Initializes the aioboto3 client."""
        # Using context manager for session management in an async app
        session = aioboto3.Session(region_name=self.region)
        return session.client("stepfunctions")

    async def start_workflow_execution(
        self,
        workspace_id: int,
        workflow_id: int,
        run_id: str,
        input_payload: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Starts a Step Function execution for a given workflow.
        """
        
        # Merge essential context into the input payload for tracking
        execution_input = {
            "metadata": {
                "workspace_id": workspace_id,
                "workflow_id": workflow_id,
                "run_id": run_id
            },
            "data": input_payload
        }
        
        try:
            async with self.client as client:
                response = await client.start_execution(
                    stateMachineArn=settings.AWS_STEP_FUNCTIONS_ARN,
                    name=f"run-{workspace_id}-{run_id}",
                    input=json.dumps(execution_input)
                )
            
            return {
                "execution_arn": response.get("executionArn"),
                "start_date": response.get("startDate").isoformat()
            }
        except Exception as e:
            # Proper error handling and logging would occur here
            print(f"AWS Step Functions Error: {e}")
            raise e

# Initialize the service globally
step_functions_service = StepFunctionsService(settings.AWS_REGION)
