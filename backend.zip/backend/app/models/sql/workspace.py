from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import String, ForeignKey, DateTime, Float
from datetime import datetime
from typing import List
from .base import Base

class Workspace(Base):
    """Workspace entity representing a single tenant/team."""
    __tablename__ = 'workspaces'

    name: Mapped[str] = mapped_column(String(255), index=True)
    description: Mapped[str | None]
    owner_user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    budget_limit_usd: Mapped[float] = mapped_column(Float, default=0.0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    
    # Relationships
    # users: Mapped[List["WorkspaceUserRole"]] = relationship(back_populates="workspace")
    # workflows: Mapped[List["Workflow"]] = relationship(back_populates="workspace")

# --- Simplified User Model for Foreign Key integrity ---
# In a full setup, this would be in models/sql/user.py
class User(Base):
    __tablename__ = 'users'
    
    email: Mapped[str] = mapped_column(String(255), unique=True)
    name: Mapped[str] = mapped_column(String(255))
    password_hash: Mapped[str]
    
    # roles: Mapped[List["WorkspaceUserRole"]] = relationship(back_populates="user")
