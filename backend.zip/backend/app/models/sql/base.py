from sqlalchemy.ext.asyncio import AsyncAttrs
from sqlalchemy.orm import DeclarativeBase, declared_attr
from sqlalchemy import Column, Integer

class Base(AsyncAttrs, DeclarativeBase):
    """
    Base class which provides automated table name
    and primary key generation.
    """
    @declared_attr
    def __tablename__(cls) -> str:
        # Generate table name from class name, converted to snake_case
        import re
        name = cls.__name__
        return re.sub(r'(?<!^)(?=[A-Z])', '_', name).lower() + 's'

    id = Column(Integer, primary_key=True, index=True)

    # Required for multi-tenancy model where 'workspace_id' is on every table
    __table_args__ = {'schema': 'public'}
