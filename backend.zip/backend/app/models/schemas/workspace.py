from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class WorkspaceCreate(BaseModel):
    name: str
    description: Optional[str] = None
    budget_limit_usd: float = 0.0

class WorkspaceRead(BaseModel):
    workspace_id: int
    name: str
    description: Optional[str] = None
    owner_user_id: int
    budget_limit_usd: float
    created_at: datetime

    class Config:
        # Enables reading data from ORM objects
        from_attributes = True 

class UserRoleUpdate(BaseModel):
    user_id: int
    role_id: int  # 1: Owner, 2: Editor, 3: Viewer
