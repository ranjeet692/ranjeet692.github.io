from fastapi import APIRouter, Depends
from app.api.v1 import workspaces, health #auth, workflows, datasources # Import your router files
#from app.services.workspaces.dependencies import get_valid_workspace_id  # Adjust the import path as needed

# --- Workspace-Scoped Router ---
# This router defines the mandatory prefix /workspaces/{workspace_id}
# Executes the validation dependency (get_valid_workspace_id)
workspace_router = APIRouter(
    prefix="/workspaces/{workspace_id}", 
    tags=["Workspace Scope"],
    #dependencies=[Depends(get_valid_workspace_id)] 
)

# Include the specific resource routers under the workspace scope
#workspace_router.include_router(datasources.router, prefix="/datasources")
#workspace_router.include_router(workflows.router, prefix="/workflows")


# --- V1-Scoped Router ---
v1_router = APIRouter(prefix="/v1")

# Include all V1 routers
#v1_router.include_router(auth.router, prefix="/v1", tags=["auth"])
v1_router.include_router(workspaces.router, prefix="/v1", tags=["workspaces"])

# Add more V1 routers here (datasources, workflows, workflow_runs, nodes)
v1_router.include_router(health.router, prefix="/v1", tags=["health"])

# Include the core unscoped endpoints (like auth, monitoring)
v1_router.include_router(workspaces.router, tags=["Workspace Management"]) # e.g., POST /workspaces


# # --- Main API Router ---
api_router = APIRouter()
api_router.include_router(v1_router) # All endpoints flow through here