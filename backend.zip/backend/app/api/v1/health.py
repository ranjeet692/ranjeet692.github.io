"""Health check endpoints"""

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from datetime import datetime
import boto3

from app.core.config import settings
from app.core.logging import logger

router = APIRouter()


class HealthResponse(BaseModel):
    """Health check response"""
    status: str
    timestamp: datetime
    version: str
    environment: str
    checks: dict


@router.get("/health", response_model=HealthResponse)
async def health_check():
    """
    Health check endpoint
    
    Returns service health status and dependency checks
    """
    checks = {}
    
    # Check AWS connectivity
    try:
        sts = boto3.client('sts', region_name=settings.AWS_REGION)
        sts.get_caller_identity()
        checks['aws'] = 'healthy'
    except Exception as e:
        checks['aws'] = f'unhealthy: {str(e)}'
        logger.error(f"AWS health check failed: {e}")
    
    # Check S3
    try:
        s3 = boto3.client('s3', region_name=settings.AWS_REGION)
        s3.head_bucket(Bucket=settings.S3_BUCKET_DOCUMENTS)
        checks['s3'] = 'healthy'
    except Exception as e:
        checks['s3'] = f'unhealthy: {str(e)}'
    
    # Check DynamoDB
    try:
        dynamodb = boto3.client('dynamodb', region_name=settings.AWS_REGION)
        dynamodb.describe_table(TableName=settings.DYNAMODB_TABLE_DOCUMENTS)
        checks['dynamodb'] = 'healthy'
    except Exception as e:
        checks['dynamodb'] = f'unhealthy: {str(e)}'
    
    # Determine overall status
    overall_status = 'healthy' if all('healthy' in v for v in checks.values()) else 'degraded'
    
    return HealthResponse(
        status=overall_status,
        timestamp=datetime.utcnow(),
        version="0.1.0",
        environment=settings.ENVIRONMENT,
        checks=checks
    )


@router.get("/health/ready")
async def readiness_check():
    """Readiness probe for Kubernetes/ECS"""
    return {"status": "ready"}


@router.get("/health/live")
async def liveness_check():
    """Liveness probe for Kubernetes/ECS"""
    return {"status": "alive"}