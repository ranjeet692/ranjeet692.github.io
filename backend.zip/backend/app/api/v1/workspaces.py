from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.db import get_db
from app.core.security import TenantUser, check_role_access
from app.models.sql.workspace import Workspace, User # Import ORM models
from app.models.schemas.workspace import WorkspaceCreate, WorkspaceRead, UserRoleUpdate
from sqlalchemy.future import select

router = APIRouter(prefix="/workspaces", tags=["Workspaces"])

# Dependency to check for Owner role (Role ID 1 is Owner)
OwnerAuth = Depends(lambda: check_role_access(required_role_id=1))

@router.post("/", response_model=WorkspaceRead, status_code=status.HTTP_201_CREATED)
async def create_workspace(
    data: WorkspaceCreate,
    current_user: TenantUser,
    db: AsyncSession = Depends(get_db)
):
    """Creates a new workspace and sets the user as the owner."""
    user_id, _, _ = current_user
    
    # Simple check: In a real app, this would use the user model to find the owner_user_id
    owner_exists = await db.scalar(select(User).filter(User.id == user_id))
    if not owner_exists:
        raise HTTPException(status_code=404, detail="User not found.")

    new_workspace = Workspace(
        name=data.name,
        description=data.description,
        owner_user_id=user_id,
        budget_limit_usd=data.budget_limit_usd
    )

    db.add(new_workspace)
    await db.commit()
    await db.refresh(new_workspace)

    # NOTE: Logic to insert into WorkspaceUserRole (user_id, new_workspace.id, role_id=1) would go here
    return new_workspace

@router.get("/{workspace_id}", response_model=WorkspaceRead)
async def read_workspace(
    workspace_id: int,
    current_user: TenantUser, # Ensures user is part of this workspace via Dependency
    db: AsyncSession = Depends(get_db)
):
    """Retrieves workspace details for the authenticated tenant."""
    _, tenant_id, _ = current_user

    if workspace_id != tenant_id:
        raise HTTPException(status_code=403, detail="Access to this workspace is forbidden.")

    result = await db.execute(
        select(Workspace).filter(Workspace.id == workspace_id)
    )
    workspace = result.scalar_one_or_none()

    if workspace is None:
        raise HTTPException(status_code=404, detail="Workspace not found")
    
    return workspace

@router.patch("/{workspace_id}/users", dependencies=[OwnerAuth])
async def update_user_role(
    workspace_id: int,
    data: UserRoleUpdate,
    current_user: TenantUser,
):
    """Updates a user's role within the specified workspace (Owner required)."""
    # Logic to update WorkspaceUserRole table
    return {"message": f"Updated role for user {data.user_id} in workspace {workspace_id}"}
