from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

import time
import uvicorn

from app.core.logging import setup_logging, logger
from app.core.monitoring import metrics, tracer
from app.core.exceptions import GenAIPlatformException
from app.core.config import settings
from app.core.db import init_db
from app.api.router import api_router

# Setup logging
setup_logging()

# Initialize the main FastAPI application
app = FastAPI(
    title="GenAI App Builder Platform",
    description="Enterprise GenAI Platform with RAG, Document Processing, and Embeddings",
    version="0.1.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Adjust for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request timing middleware
@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    """Add processing time to response headers"""
    start_time = time.time()
    
    response = await call_next(request)
    
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    
    # Record metrics
    metrics.record_request(
        method=request.method,
        path=request.url.path,
        status_code=response.status_code,
        duration=process_time
    )
    
    return response

# Exception handler
@app.exception_handler(GenAIPlatformException)
async def platform_exception_handler(request: Request, exc: GenAIPlatformException):
    """Handle platform-specific exceptions"""
    logger.error(
        f"Platform exception: {exc.message}",
        extra={
            "error_code": exc.error_code,
            "status_code": exc.status_code,
            "path": request.url.path
        }
    )
    
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": exc.message,
            "error_code": exc.error_code,
            "details": exc.details
        }
    )

# --- Startup Events ---
@app.on_event("startup")
async def startup_event():
    """Initialize connections and resources on startup"""
    logger.info("Starting GenAI Platform API")
    logger.info(f"Environment: {settings.ENVIRONMENT}")
    logger.info(f"AWS Region: {settings.AWS_REGION}")
    await init_db()

# --- Include Routers ---
app.include_router(api_router)

# Shutdown event
@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup resources on shutdown"""
    logger.info("Shutting down GenAI Platform API")

# Root endpoint
@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "AI App Builder Platform",
        "version": "0.1.0",
        "status": "running",
        "docs": "/api/docs"
    }


if __name__ == "__main__":
    import uvicorn
    # This block is typically for local development testing
    uvicorn.run(
        "main:app", 
        host="0.0.0.0", 
        port=8000, 
        reload=True
    )
