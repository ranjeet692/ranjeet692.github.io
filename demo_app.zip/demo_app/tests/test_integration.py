"""
Integration tests for serverless file processing workflow
"""
import json
import time
import boto3
import pytest
import requests
from datetime import datetime

# Initialize AWS clients
s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
stepfunctions = boto3.client('stepfunctions')

# Configuration (update with your deployed resources)
REST_API_URL = "https://your-api-id.execute-api.us-east-1.amazonaws.com/dev"
INPUT_BUCKET = "your-input-bucket"
OUTPUT_BUCKET = "your-output-bucket"
JOB_TABLE_NAME = "your-job-table"
STATE_MACHINE_ARN = "your-state-machine-arn"

job_table = dynamodb.Table(JOB_TABLE_NAME)


class TestFileProcessingWorkflow:
    """Test suite for file processing workflow"""

    @pytest.fixture
    def sample_files(self):
        """Create sample test files in S3"""
        test_prefix = f"test-{int(time.time())}/"
        test_files = [
            {
                "key": f"{test_prefix}file1.txt",
                "content": "This is a test document about artificial intelligence."
            },
            {
                "key": f"{test_prefix}file2.txt",
                "content": "Machine learning is transforming industries worldwide."
            },
            {
                "key": f"{test_prefix}file3.json",
                "content": json.dumps({"topic": "Cloud Computing", "content": "AWS services overview"})
            }
        ]

        # Upload files to S3
        for file_data in test_files:
            s3.put_object(
                Bucket=INPUT_BUCKET,
                Key=file_data['key'],
                Body=file_data['content'].encode('utf-8')
            )

        yield {"prefix": test_prefix, "files": test_files}

        # Cleanup after test
        for file_data in test_files:
            try:
                s3.delete_object(Bucket=INPUT_BUCKET, Key=file_data['key'])
            except:
                pass

    def test_manual_workflow_trigger(self, sample_files):
        """Test manual workflow trigger via API"""
        # Start job via API
        response = requests.post(
            f"{REST_API_URL}/jobs",
            json={"prefix": sample_files['prefix']},
            headers={"Content-Type": "application/json"}
        )

        assert response.status_code == 200
        data = response.json()
        assert 'jobId' in data
        assert 'executionArn' in data

        job_id = data['jobId']
        print(f"Job started: {job_id}")

        # Wait for job to complete
        max_wait = 300  # 5 minutes
        start_time = time.time()

        while time.time() - start_time < max_wait:
            status_response = requests.get(f"{REST_API_URL}/jobs/{job_id}")
            assert status_response.status_code == 200

            job_status = status_response.json()
            print(f"Job status: {job_status['status']} - Progress: {job_status['progress']}%")

            if job_status['status'] == 'COMPLETED':
                assert job_status['processedFiles'] == len(sample_files['files'])
                assert job_status['outputKey'] is not None
                print(f"Job completed successfully: {job_status['outputKey']}")
                return

            if job_status['status'] == 'FAILED':
                pytest.fail(f"Job failed: {job_status.get('message', 'Unknown error')}")

            time.sleep(5)

        pytest.fail("Job did not complete within timeout")

    def test_s3_event_trigger(self, sample_files):
        """Test workflow trigger via S3 event"""
        # Upload a new file which should trigger the workflow
        trigger_file = f"{sample_files['prefix']}trigger-file.txt"
        s3.put_object(
            Bucket=INPUT_BUCKET,
            Key=trigger_file,
            Body=b"This file should trigger the workflow automatically"
        )

        # Wait for workflow to start
        time.sleep(10)

        # Check DynamoDB for recent jobs
        response = job_table.scan(
            FilterExpression="contains(#prefix, :prefix)",
            ExpressionAttributeNames={"#prefix": "prefix"},
            ExpressionAttributeValues={":prefix": sample_files['prefix']}
        )

        assert len(response['Items']) > 0
        print(f"Found {len(response['Items'])} jobs triggered by S3 event")

        # Cleanup
        s3.delete_object(Bucket=INPUT_BUCKET, Key=trigger_file)

    def test_job_status_api(self, sample_files):
        """Test job status retrieval"""
        # Start a job
        response = requests.post(
            f"{REST_API_URL}/jobs",
            json={"prefix": sample_files['prefix']}
        )
        job_id = response.json()['jobId']

        # Get job status
        status_response = requests.get(f"{REST_API_URL}/jobs/{job_id}")
        assert status_response.status_code == 200

        job_data = status_response.json()
        assert job_data['jobId'] == job_id
        assert 'status' in job_data
        assert 'progress' in job_data
        assert job_data['totalFiles'] >= 0

    def test_nonexistent_job(self):
        """Test getting status of non-existent job"""
        fake_job_id = "non-existent-job-id"
        response = requests.get(f"{REST_API_URL}/jobs/{fake_job_id}")
        assert response.status_code == 404

    def test_output_file_creation(self, sample_files):
        """Test that output files are created correctly"""
        # Start job
        response = requests.post(
            f"{REST_API_URL}/jobs",
            json={"prefix": sample_files['prefix']}
        )
        job_id = response.json()['jobId']

        # Wait for completion
        max_wait = 300
        start_time = time.time()

        while time.time() - start_time < max_wait:
            status_response = requests.get(f"{REST_API_URL}/jobs/{job_id}")
            job_status = status_response.json()

            if job_status['status'] == 'COMPLETED':
                output_key = job_status['outputKey']
                assert output_key is not None

                # Verify output file exists in S3
                try:
                    s3.head_object(Bucket=OUTPUT_BUCKET, Key=output_key)
                    print(f"Output file verified: {output_key}")

                    # Download and verify content
                    obj = s3.get_object(Bucket=OUTPUT_BUCKET, Key=output_key)
                    content = json.loads(obj['Body'].read().decode('utf-8'))

                    assert 'jobId' in content
                    assert content['jobId'] == job_id
                    assert 'summary' in content
                    assert 'results' in content
                    assert len(content['results']) == len(sample_files['files'])

                    print("Output file content verified successfully")
                    return

                except s3.exceptions.NoSuchKey:
                    pytest.fail(f"Output file not found: {output_key}")

            time.sleep(5)

        pytest.fail("Job did not complete within timeout")

    def test_parallel_processing(self):
        """Test parallel processing of multiple files"""
        # Create many files to test parallelism
        test_prefix = f"parallel-test-{int(time.time())}/"
        file_count = 20

        for i in range(file_count):
            s3.put_object(
                Bucket=INPUT_BUCKET,
                Key=f"{test_prefix}file_{i}.txt",
                Body=f"Test content for file {i}".encode('utf-8')
            )

        # Start job
        response = requests.post(
            f"{REST_API_URL}/jobs",
            json={"prefix": test_prefix}
        )
        job_id = response.json()['jobId']

        # Monitor progress
        max_wait = 600  # 10 minutes for larger job
        start_time = time.time()

        while time.time() - start_time < max_wait:
            status_response = requests.get(f"{REST_API_URL}/jobs/{job_id}")
            job_status = status_response.json()

            print(f"Processing: {job_status['processedFiles']}/{job_status['totalFiles']}")

            if job_status['status'] == 'COMPLETED':
                assert job_status['totalFiles'] == file_count
                processing_time = time.time() - start_time
                print(f"Processed {file_count} files in {processing_time:.2f} seconds")

                # Cleanup
                for i in range(file_count):
                    s3.delete_object(Bucket=INPUT_BUCKET, Key=f"{test_prefix}file_{i}.txt")

                return

            time.sleep(5)

        pytest.fail("Parallel processing test did not complete within timeout")

    def test_error_handling(self):
        """Test error handling for invalid files"""
        test_prefix = f"error-test-{int(time.time())}/"

        # Upload an unsupported file type
        s3.put_object(
            Bucket=INPUT_BUCKET,
            Key=f"{test_prefix}unsupported.xyz",
            Body=b"This is an unsupported file type"
        )

        # Start job
        response = requests.post(
            f"{REST_API_URL}/jobs",
            json={"prefix": test_prefix}
        )
        job_id = response.json()['jobId']

        # Wait for completion
        time.sleep(30)

        status_response = requests.get(f"{REST_API_URL}/jobs/{job_id}")
        job_status = status_response.json()

        # Check that the job completed (even with errors)
        assert job_status['status'] in ['COMPLETED', 'RUNNING']

        # Cleanup
        s3.delete_object(Bucket=INPUT_BUCKET, Key=f"{test_prefix}unsupported.xyz")

    def test_dynamodb_job_tracking(self, sample_files):
        """Test DynamoDB job tracking"""
        # Start job
        response = requests.post(
            f"{REST_API_URL}/jobs",
            json={"prefix": sample_files['prefix']}
        )
        job_id = response.json()['jobId']

        # Give it a moment to initialize
        time.sleep(2)

        # Check DynamoDB
        db_response = job_table.get_item(Key={'jobId': job_id})
        assert 'Item' in db_response

        item = db_response['Item']
        assert item['jobId'] == job_id
        assert item['status'] in ['PENDING', 'RUNNING']
        assert 'createdAt' in item
        assert int(item['totalFiles']) >= 0


class TestStepFunctionsWorkflow:
    """Test Step Functions state machine directly"""

    def test_state_machine_execution(self):
        """Test Step Functions execution"""
        test_prefix = f"sfn-test-{int(time.time())}/"

        # Create test file
        s3.put_object(
            Bucket=INPUT_BUCKET,
            Key=f"{test_prefix}test.txt",
            Body=b"Test content for Step Functions"
        )

        # Start execution
        execution_input = {
            "jobId": f"test-{int(time.time())}",
            "bucket": INPUT_BUCKET,
            "prefix": test_prefix,
            "timestamp": int(time.time()),
            "triggerType": "test"
        }

        response = stepfunctions.start_execution(
            stateMachineArn=STATE_MACHINE_ARN,
            name=f"test-execution-{int(time.time())}",
            input=json.dumps(execution_input)
        )

        execution_arn = response['executionArn']
        print(f"Started execution: {execution_arn}")

        # Wait for execution to complete
        max_wait = 300
        start_time = time.time()

        while time.time() - start_time < max_wait:
            exec_response = stepfunctions.describe_execution(executionArn=execution_arn)
            status = exec_response['status']
            print(f"Execution status: {status}")

            if status == 'SUCCEEDED':
                print("Execution completed successfully")
                # Cleanup
                s3.delete_object(Bucket=INPUT_BUCKET, Key=f"{test_prefix}test.txt")
                return

            if status == 'FAILED':
                pytest.fail(f"Execution failed: {exec_response.get('error', 'Unknown')}")

            time.sleep(5)

        pytest.fail("Execution did not complete within timeout")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])