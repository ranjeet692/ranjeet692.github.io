# AWS Serverless File Processing Workflow

A complete serverless architecture for parallel file processing using AWS Step Functions, Lambda, and real-time job tracking with WebSockets.

## 🏗️ Architecture

This solution implements an end-to-end serverless workflow that:

1. **Triggers** on S3 file uploads or manual API calls
2. **Discovers** files from S3 buckets
3. **Processes** files in parallel using Step Functions Map state
4. **Calls** external LLM APIs for content analysis
5. **Tracks** job progress in DynamoDB
6. **Streams** real-time updates via WebSocket
7. **Aggregates** results and stores in S3

### Key Components

- **API Gateway REST**: Job submission and status queries
- **API Gateway WebSocket**: Real-time job updates
- **Step Functions**: Orchestrates the workflow
- **Lambda Functions**: Business logic for each step
- **DynamoDB**: Job tracking and WebSocket connections
- **DynamoDB Streams**: Real-time change data capture
- **S3**: Input files and output results storage

## 📋 Prerequisites

- AWS Account with appropriate permissions
- AWS CLI configured
- SAM CLI installed (`pip install aws-sam-cli`)
- Python 3.11+
- LLM API key (OpenAI, Anthropic, or AWS Bedrock)

## 🚀 Quick Start

### 1. Clone and Setup

```bash
git clone <repository>
cd serverless-file-processor

# Create directory structure
mkdir -p src/{trigger_workflow,start_workflow,list_files,process_file,aggregate_results,get_job_status,websocket_connect,websocket_disconnect,stream_processor}
mkdir statemachine
```

### 2. Configure Parameters

Create `parameters.json`:

```json
{
  "Parameters": {
    "Environment": "dev",
    "LLMAPIKey": "your-api-key-here"
  }
}
```

### 3. Deploy with SAM

```bash
# Build
sam build

# Deploy
sam deploy --guided --parameter-overrides $(cat parameters.json)
```

### 4. Get Endpoints

```bash
# Get API URLs
sam list stack-outputs --stack-name file-processing-workflow
```

### 5. Test the Workflow

```bash
# Upload test files
aws s3 cp test.txt s3://YOUR-INPUT-BUCKET/test-folder/

# Or trigger manually
curl -X POST https://YOUR-API-URL/dev/jobs \
  -H "Content-Type: application/json" \
  -d '{"prefix": "test-folder/"}'
```

## 📁 Project Structure

```
.
├── template.yaml                 # SAM/CloudFormation template
├── statemachine/
│   └── workflow.asl.json        # Step Functions definition
├── src/
│   ├── trigger_workflow/        # S3 event handler
│   ├── start_workflow/          # Manual API trigger
│   ├── list_files/              # S3 file discovery
│   ├── process_file/            # File processing & LLM calls
│   ├── aggregate_results/       # Result aggregation
│   ├── get_job_status/          # Job status API
│   ├── websocket_connect/       # WebSocket connection
│   ├── websocket_disconnect/    # WebSocket disconnection
│   └── stream_processor/        # DynamoDB stream processor
├── frontend/
│   ├── client.js                # Vanilla JS client
│   └── FileProcessingDashboard.jsx  # React component
├── tests/
│   └── test_integration.py      # Integration tests
└── README.md
```

## 🔄 Workflow Steps

### 1. Initialization
- Generate unique Job ID
- Create DynamoDB entry with PENDING status
- Record timestamp and metadata

### 2. File Discovery
- List all files in S3 bucket/prefix
- Filter by supported file types
- Extract metadata (size, last modified)

### 3. Parallel Processing (Map State)
For each file:
- Download from S3
- Extract text content
- Call LLM API for analysis
- Update job progress in DynamoDB

### 4. Aggregation
- Collect all individual results
- Calculate success/failure counts
- Create summary statistics

### 5. Finalization
- Store aggregated results in S3 (JSON & CSV)
- Update job status to COMPLETED
- Trigger WebSocket notifications

## 🔌 API Reference

### REST API

#### Start Job
```http
POST /jobs
Content-Type: application/json

{
  "prefix": "folder/path/"
}
```

Response:
```json
{
  "jobId": "uuid",
  "executionArn": "arn:aws:states:...",
  "bucket": "bucket-name",
  "prefix": "folder/path/"
}
```

#### Get Job Status
```http
GET /jobs/{jobId}
```

Response:
```json
{
  "jobId": "uuid",
  "status": "RUNNING",
  "totalFiles": 10,
  "processedFiles": 5,
  "failedFiles": 0,
  "progress": 50,
  "createdAt": 1234567890,
  "outputKey": "results/uuid/aggregated_results.json"
}
```

### WebSocket API

#### Connect
```javascript
const ws = new WebSocket('wss://your-ws-api-id.execute-api.region.amazonaws.com/dev');
```

#### Real-time Updates
```json
{
  "type": "JOB_UPDATE",
  "data": {
    "jobId": "uuid",
    "status": "RUNNING",
    "progress": 75,
    "processedFiles": 15,
    "totalFiles": 20
  }
}
```

## 🧪 Testing

### Run Integration Tests

```bash
# Install test dependencies
pip install pytest boto3 requests

# Configure test environment
export REST_API_URL="https://your-api.execute-api.us-east-1.amazonaws.com/dev"
export INPUT_BUCKET="your-input-bucket"
export OUTPUT_BUCKET="your-output-bucket"

# Run tests
pytest tests/test_integration.py -v
```

### Manual Testing

1. **S3 Upload Test**:
```bash
aws s3 cp sample.txt s3://input-bucket/test/
```

2. **API Trigger Test**:
```bash
curl -X POST $API_URL/jobs -d '{"prefix":"test/"}'
```

3. **WebSocket Test**:
```bash
npm install -g wscat
wscat -c wss://your-ws-api.execute-api.region.amazonaws.com/dev
```

## 🎨 Frontend Integration

### Vanilla JavaScript

```javascript
import { FileProcessingClient } from './client.js';

const client = new FileProcessingClient({
  restApiUrl: 'https://api-url',
  websocketUrl: 'wss://ws-url'
});

// Real-time updates
client.on('JobUpdate', (data) => {
  console.log('Job progress:', data.progress);
});

client.connectWebSocket();

// Start job
const job = await client.startJob('folder/');
```

### React

```jsx
import FileProcessingDashboard from './FileProcessingDashboard';

function App() {
  return <FileProcessingDashboard />;
}
```

## 🔒 Security Best Practices

### 1. API Keys
- Store LLM API keys in AWS Secrets Manager
- Use IAM roles instead of hardcoded credentials
- Rotate keys regularly

### 2. API Gateway
- Enable AWS IAM or Cognito authentication
- Implement API key requirements for external access
- Use request throttling and rate limiting
- Enable AWS WAF for additional protection

### 3. S3 Buckets
- Enable bucket versioning
- Use server-side encryption (SSE-S3 or SSE-KMS)
- Block public access
- Implement bucket policies for least privilege

### 4. DynamoDB
- Enable point-in-time recovery
- Use encryption at rest
- Implement fine-grained access control
- Set up TTL for old records

### 5. Network Security
- Deploy Lambdas in VPC for sensitive operations
- Use VPC endpoints for AWS service access
- Implement security groups and NACLs

## 📊 Monitoring and Logging

### CloudWatch Metrics

Key metrics to monitor:
- Lambda execution duration and errors
- Step Functions execution status
- DynamoDB read/write capacity
- API Gateway request count and latency
- WebSocket connection count

### Custom Dashboards

```bash
# Create CloudWatch dashboard
aws cloudwatch put-dashboard \
  --dashboard-name FileProcessingWorkflow \
  --dashboard-body file://dashboard.json
```

### Alarms

Set up alarms for:
- Lambda function errors (> 5 in 5 minutes)
- Step Functions failed executions
- DynamoDB throttling events
- API Gateway 5xx errors

### X-Ray Tracing

Enable distributed tracing:

```yaml
# In template.yaml
Globals:
  Function:
    Tracing: Active
```

## 💰 Cost Optimization

### Estimated Monthly Costs (1000 jobs/month)

| Service | Usage | Cost |
|---------|-------|------|
| Lambda | 50,000 invocations, 512MB, 30s avg | ~$2.50 |
| Step Functions | 1,000 executions, 10 steps each | ~$0.25 |
| DynamoDB | 100K reads, 50K writes | ~$0.50 |
| S3 | 10GB storage, 100K requests | ~$0.35 |
| API Gateway | 10K REST + 10K WebSocket | ~$0.50 |
| **Total** | | **~$4.10/month** |

### Optimization Tips

1. **Lambda**
   - Right-size memory allocation
   - Use ARM/Graviton2 for 20% cost savings
   - Minimize cold starts with provisioned concurrency

2. **S3**
   - Use S3 Intelligent-Tiering
   - Set lifecycle policies for old data
   - Enable S3 Transfer Acceleration only when needed

3. **DynamoDB**
   - Use on-demand billing for variable workloads
   - Implement auto-scaling for provisioned capacity
   - Archive old jobs to S3 with TTL

4. **API Gateway**
   - Use HTTP API instead of REST API (60% cheaper)
   - Cache responses where appropriate
   - Implement request batching

## 🔧 Advanced Configuration

### LLM Provider Examples

#### OpenAI
```python
# In process_file/handler.py
api_url = "https://api.openai.com/v1/chat/completions"
headers = {"Authorization": f"Bearer {LLM_API_KEY}"}
payload = {
    "model": "gpt-4",
    "messages": [{"role": "user", "content": content}]
}
```

#### Anthropic Claude
```python
api_url = "https://api.anthropic.com/v1/messages"
headers = {
    "x-api-key": LLM_API_KEY,
    "anthropic-version": "2023-06-01"
}
payload = {
    "model": "claude-3-sonnet-20240229",
    "messages": [{"role": "user", "content": content}],
    "max_tokens": 1024
}
```

#### AWS Bedrock
```python
import boto3
bedrock = boto3.client('bedrock-runtime')

response = bedrock.invoke_model(
    modelId='anthropic.claude-3-sonnet-20240229-v1:0',
    body=json.dumps({
        "anthropic_version": "bedrock-2023-05-31",
        "messages": [{"role": "user", "content": content}],
        "max_tokens": 1024
    })
)
```

### Custom File Processors

Add support for PDFs, Word docs, etc.:

```python
# In process_file/handler.py
import PyPDF2
import docx

def extract_text_from_file(bucket, key):
    if key.endswith('.pdf'):
        return extract_pdf(bucket, key)
    elif key.endswith('.docx'):
        return extract_docx(bucket, key)
    # ... other formats

def extract_pdf(bucket, key):
    obj = s3.get_object(Bucket=bucket, Key=key)
    pdf = PyPDF2.PdfReader(obj['Body'])
    return '\n'.join(page.extract_text() for page in pdf.pages)
```

### Parallel Processing Tuning

Adjust concurrency in Step Functions:

```json
{
  "Type": "Map",
  "MaxConcurrency": 20,  // Increase for faster processing
  "ItemsPath": "$.fileList.files",
  ...
}
```

Consider LLM API rate limits:
- OpenAI: ~3,500 requests/minute (GPT-4)
- Anthropic: ~5,000 requests/minute (Claude)
- Bedrock: Varies by model and quota

## 🐛 Troubleshooting

### Common Issues

#### 1. Lambda Timeout
**Problem**: Files taking too long to process

**Solution**:
```yaml
# Increase timeout in template.yaml
ProcessFileFunction:
  Timeout: 900  # 15 minutes max
  MemorySize: 1024
```

#### 2. LLM API Rate Limiting
**Problem**: 429 Too Many Requests errors

**Solution**:
- Reduce Map state concurrency
- Implement exponential backoff
- Use multiple API keys with round-robin

```python
# Add retry logic
@retry(
    wait=wait_exponential(min=1, max=60),
    stop=stop_after_attempt(5),
    retry=retry_if_exception_type(requests.HTTPError)
)
def call_llm_api(content):
    # API call here
```

#### 3. WebSocket Disconnections
**Problem**: Clients not receiving updates

**Solution**:
- Implement heartbeat/ping messages
- Auto-reconnect logic in frontend
- Check API Gateway timeout settings (10 minutes max)

#### 4. DynamoDB Throttling
**Problem**: ProvisionedThroughputExceededException

**Solution**:
- Use on-demand billing mode
- Enable auto-scaling
- Batch write operations

#### 5. S3 Access Denied
**Problem**: Lambda can't read files

**Solution**:
```yaml
# Add explicit S3 permissions
Policies:
  - S3ReadPolicy:
      BucketName: !Ref InputBucket
  - S3CrudPolicy:
      BucketName: !Ref OutputBucket
```

### Debug CloudWatch Logs

```bash
# Tail Lambda logs
sam logs -n ProcessFileFunction --tail

# Get specific execution logs
aws logs tail /aws/lambda/function-name --since 1h --follow

# Search for errors
aws logs filter-log-events \
  --log-group-name /aws/lambda/function-name \
  --filter-pattern ERROR \
  --start-time $(date -u -d '1 hour ago' +%s)000
```

### Step Functions Debugging

```bash
# List recent executions
aws stepfunctions list-executions \
  --state-machine-arn arn:aws:states:... \
  --max-results 10

# Get execution details
aws stepfunctions describe-execution \
  --execution-arn arn:aws:states:...

# Get execution history
aws stepfunctions get-execution-history \
  --execution-arn arn:aws:states:...
```

## 🚢 Production Deployment

### Multi-Environment Setup

```bash
# Development
sam deploy --config-env dev

# Staging
sam deploy --config-env staging

# Production
sam deploy --config-env prod
```

Create `samconfig.toml`:

```toml
[default.deploy.parameters]
stack_name = "file-processor-dev"
resolve_s3 = true
region = "us-east-1"

[prod.deploy.parameters]
stack_name = "file-processor-prod"
resolve_s3 = true
region = "us-east-1"
capabilities = "CAPABILITY_IAM"
parameter_overrides = "Environment=prod"
```

### CI/CD Pipeline

GitHub Actions example:

```yaml
name: Deploy to AWS

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Setup Python
        uses: actions/setup-python@v2
        with:
          python-version: 3.11
      
      - name: Install SAM CLI
        run: pip install aws-sam-cli
      
      - name: Configure AWS
        uses: aws-actions/configure-aws-credentials@v1
        with:
          aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
          aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
          aws-region: us-east-1
      
      - name: Build and Deploy
        run: |
          sam build
          sam deploy --no-confirm-changeset --no-fail-on-empty-changeset
```

### Backup and Disaster Recovery

1. **DynamoDB Point-in-Time Recovery**:
```bash
aws dynamodb update-continuous-backups \
  --table-name your-job-table \
  --point-in-time-recovery-specification PointInTimeRecoveryEnabled=true
```

2. **S3 Versioning and Replication**:
```yaml
InputBucket:
  Type: AWS::S3::Bucket
  Properties:
    VersioningConfiguration:
      Status: Enabled
    ReplicationConfiguration:
      Role: !GetAtt S3ReplicationRole.Arn
      Rules:
        - Destination:
            Bucket: arn:aws:s3:::backup-bucket
          Status: Enabled
```

3. **CloudFormation Stack Exports**:
```bash
# Export stack template
aws cloudformation get-template \
  --stack-name file-processing-workflow \
  --query TemplateBody > backup-template.json
```

## 📚 Additional Resources

- [AWS Step Functions Developer Guide](https://docs.aws.amazon.com/step-functions/)
- [AWS Lambda Best Practices](https://docs.aws.amazon.com/lambda/latest/dg/best-practices.html)
- [DynamoDB Streams](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/Streams.html)
- [API Gateway WebSocket](https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-websocket-api.html)

## 📄 License

MIT License - feel free to use this in your own projects!

## 🤝 Contributing

Contributions welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📞 Support

For issues and questions:
- GitHub Issues: [repository]/issues
- AWS Support: For AWS-specific issues
- Stack Overflow: Tag with `aws-step-functions`, `aws-lambda`