import React, { useState, useEffect, useRef } from 'react';

const FileProcessingDashboard = () => {
  const [jobs, setJobs] = useState([]);
  const [currentJob, setCurrentJob] = useState(null);
  const [prefix, setPrefix] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [loading, setLoading] = useState(false);
  const wsRef = useRef(null);

  const API_URL = process.env.REACT_APP_API_URL || 'https://your-api.execute-api.us-east-1.amazonaws.com/dev';
  const WS_URL = process.env.REACT_APP_WS_URL || 'wss://your-ws-api.execute-api.us-east-1.amazonaws.com/dev';

  // WebSocket connection
  useEffect(() => {
    connectWebSocket();
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  const connectWebSocket = () => {
    const ws = new WebSocket(WS_URL);

    ws.onopen = () => {
      console.log('WebSocket connected');
      setIsConnected(true);
    };

    ws.onmessage = (event) => {
      const message = JSON.parse(event.data);
      if (message.type === 'JOB_UPDATE') {
        updateJobInList(message.data);
      }
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
      setIsConnected(false);
    };

    ws.onclose = () => {
      console.log('WebSocket disconnected');
      setIsConnected(false);
      // Reconnect after 5 seconds
      setTimeout(connectWebSocket, 5000);
    };

    wsRef.current = ws;
  };

  const updateJobInList = (jobData) => {
    setJobs(prevJobs => {
      const index = prevJobs.findIndex(j => j.jobId === jobData.jobId);
      if (index >= 0) {
        const updatedJobs = [...prevJobs];
        updatedJobs[index] = { ...updatedJobs[index], ...jobData };
        return updatedJobs;
      } else {
        return [jobData, ...prevJobs];
      }
    });

    if (currentJob?.jobId === jobData.jobId) {
      setCurrentJob(prev => ({ ...prev, ...jobData }));
    }
  };

  const startJob = async () => {
    if (!prefix.trim()) {
      alert('Please enter a folder prefix');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${API_URL}/jobs`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prefix: prefix.trim() })
      });

      const data = await response.json();
      setCurrentJob(data);
      setJobs(prev => [data, ...prev]);
      setPrefix('');
    } catch (error) {
      console.error('Error starting job:', error);
      alert('Failed to start job');
    } finally {
      setLoading(false);
    }
  };

  const getJobStatus = async (jobId) => {
    try {
      const response = await fetch(`${API_URL}/jobs/${jobId}`);
      const data = await response.json();
      setCurrentJob(data);
      updateJobInList(data);
    } catch (error) {
      console.error('Error fetching job status:', error);
    }
  };

  const downloadResults = (outputKey) => {
    const bucketUrl = `https://${process.env.REACT_APP_OUTPUT_BUCKET}.s3.amazonaws.com/${outputKey}`;
    window.open(bucketUrl, '_blank');
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'COMPLETED': return 'text-green-600 bg-green-100';
      case 'RUNNING': return 'text-blue-600 bg-blue-100';
      case 'FAILED': return 'text-red-600 bg-red-100';
      case 'PENDING': return 'text-yellow-600 bg-yellow-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            File Processing Dashboard
          </h1>
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`} />
            <span className="text-sm text-gray-600">
              {isConnected ? 'Connected to real-time updates' : 'Disconnected'}
            </span>
          </div>
        </div>

        {/* Start Job Section */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">Start New Job</h2>
          <div className="flex gap-4">
            <input
              type="text"
              value={prefix}
              onChange={(e) => setPrefix(e.target.value)}
              placeholder="Enter S3 folder prefix (e.g., documents/2024/)"
              className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <button
              onClick={startJob}
              disabled={loading}
              className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
            >
              {loading ? 'Starting...' : 'Start Job'}
            </button>
          </div>
        </div>

        {/* Current Job Details */}
        {currentJob && (
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4">Current Job</h2>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm text-gray-600">Job ID</p>
                  <p className="font-mono text-sm">{currentJob.jobId}</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(currentJob.status)}`}>
                  {currentJob.status}
                </span>
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm text-gray-600">Progress</span>
                  <span className="text-sm font-medium">{currentJob.progress || 0}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${currentJob.progress || 0}%` }}
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 pt-2">
                <div>
                  <p className="text-sm text-gray-600">Total Files</p>
                  <p className="text-2xl font-bold">{currentJob.totalFiles || 0}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Processed</p>
                  <p className="text-2xl font-bold text-green-600">{currentJob.processedFiles || 0}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Failed</p>
                  <p className="text-2xl font-bold text-red-600">{currentJob.failedFiles || 0}</p>
                </div>
              </div>

              {currentJob.status === 'COMPLETED' && currentJob.outputKey && (
                <button
                  onClick={() => downloadResults(currentJob.outputKey)}
                  className="w-full mt-4 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
                >
                  Download Results
                </button>
              )}
            </div>
          </div>
        )}

        {/* Job History */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">Job History</h2>
          {jobs.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No jobs yet. Start one above!</p>
          ) : (
            <div className="space-y-3">
              {jobs.map((job) => (
                <div
                  key={job.jobId}
                  onClick={() => getJobStatus(job.jobId)}
                  className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 cursor-pointer transition-colors"
                >
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex-1">
                      <p className="font-mono text-sm text-gray-600">{job.jobId}</p>
                      {job.prefix && (
                        <p className="text-sm text-gray-500 mt-1">Prefix: {job.prefix}</p>
                      )}
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(job.status)}`}>
                      {job.status}
                    </span>
                  </div>
                  
                  {job.totalFiles > 0 && (
                    <div className="mt-3">
                      <div className="flex justify-between text-xs text-gray-600 mb-1">
                        <span>{job.processedFiles || 0} / {job.totalFiles} files</span>
                        <span>{job.progress || 0}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-1">
                        <div
                          className="bg-blue-600 h-1 rounded-full transition-all duration-300"
                          style={{ width: `${job.progress || 0}%` }}
                        />
                      </div>
                    </div>
                  )}

                  {job.createdAt && (
                    <p className="text-xs text-gray-400 mt-2">
                      {new Date(job.createdAt * 1000).toLocaleString()}
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FileProcessingDashboard;