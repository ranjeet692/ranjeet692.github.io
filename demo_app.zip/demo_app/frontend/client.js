/**
 * Frontend client for AWS serverless file processing workflow
 * Handles job submission, status tracking, and real-time WebSocket updates
 */

class FileProcessingClient {
  constructor(config) {
    this.restApiUrl = config.restApiUrl;
    this.websocketUrl = config.websocketUrl;
    this.websocket = null;
    this.eventHandlers = {
      onJobUpdate: null,
      onConnect: null,
      onDisconnect: null,
      onError: null
    };
  }

  /**
   * Start a new file processing job
   * @param {string} prefix - S3 prefix/folder to process
   * @returns {Promise<object>} Job details
   */
  async startJob(prefix = '') {
    try {
      const response = await fetch(`${this.restApiUrl}/jobs`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ prefix })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      console.log('Job started:', data);
      return data;
    } catch (error) {
      console.error('Error starting job:', error);
      throw error;
    }
  }

  /**
   * Get current status of a job
   * @param {string} jobId - Job ID to check
   * @returns {Promise<object>} Job status
   */
  async getJobStatus(jobId) {
    try {
      const response = await fetch(`${this.restApiUrl}/jobs/${jobId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('Job not found');
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error getting job status:', error);
      throw error;
    }
  }

  /**
   * Poll job status at regular intervals
   * @param {string} jobId - Job ID to poll
   * @param {function} callback - Called with job status on each poll
   * @param {number} interval - Polling interval in ms (default 2000)
   * @returns {function} Function to stop polling
   */
  pollJobStatus(jobId, callback, interval = 2000) {
    const pollInterval = setInterval(async () => {
      try {
        const status = await this.getJobStatus(jobId);
        callback(status);

        // Stop polling if job is complete or failed
        if (status.status === 'COMPLETED' || status.status === 'FAILED') {
          clearInterval(pollInterval);
        }
      } catch (error) {
        console.error('Polling error:', error);
        clearInterval(pollInterval);
        if (this.eventHandlers.onError) {
          this.eventHandlers.onError(error);
        }
      }
    }, interval);

    // Return function to stop polling
    return () => clearInterval(pollInterval);
  }

  /**
   * Connect to WebSocket for real-time updates
   */
  connectWebSocket() {
    if (this.websocket && this.websocket.readyState === WebSocket.OPEN) {
      console.log('WebSocket already connected');
      return;
    }

    this.websocket = new WebSocket(this.websocketUrl);

    this.websocket.onopen = (event) => {
      console.log('WebSocket connected');
      if (this.eventHandlers.onConnect) {
        this.eventHandlers.onConnect(event);
      }
    };

    this.websocket.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        console.log('WebSocket message received:', message);

        if (message.type === 'JOB_UPDATE' && this.eventHandlers.onJobUpdate) {
          this.eventHandlers.onJobUpdate(message.data);
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };

    this.websocket.onerror = (error) => {
      console.error('WebSocket error:', error);
      if (this.eventHandlers.onError) {
        this.eventHandlers.onError(error);
      }
    };

    this.websocket.onclose = (event) => {
      console.log('WebSocket disconnected');
      if (this.eventHandlers.onDisconnect) {
        this.eventHandlers.onDisconnect(event);
      }

      // Auto-reconnect after 5 seconds
      setTimeout(() => {
        console.log('Attempting to reconnect...');
        this.connectWebSocket();
      }, 5000);
    };
  }

  /**
   * Disconnect WebSocket
   */
  disconnectWebSocket() {
    if (this.websocket) {
      this.websocket.close();
      this.websocket = null;
    }
  }

  /**
   * Register event handlers
   */
  on(event, handler) {
    if (this.eventHandlers.hasOwnProperty(`on${event}`)) {
      this.eventHandlers[`on${event}`] = handler;
    }
  }

  /**
   * Download processed results from S3
   * @param {string} outputKey - S3 key of the results file
   * @param {string} bucketName - S3 bucket name
   */
  async downloadResults(outputKey, bucketName) {
    // In a real implementation, you'd use AWS SDK or a signed URL
    const s3Url = `https://${bucketName}.s3.amazonaws.com/${outputKey}`;
    window.open(s3Url, '_blank');
  }
}

// Usage Example
// ==============

// Initialize client
const client = new FileProcessingClient({
  restApiUrl: 'https://your-api-id.execute-api.us-east-1.amazonaws.com/dev',
  websocketUrl: 'wss://your-ws-api-id.execute-api.us-east-1.amazonaws.com/dev'
});

// Set up event handlers for real-time updates
client.on('JobUpdate', (jobData) => {
  console.log('Job updated:', jobData);
  updateUI(jobData);
});

client.on('Connect', () => {
  console.log('Connected to real-time updates');
});

client.on('Error', (error) => {
  console.error('Client error:', error);
});

// Connect to WebSocket for real-time updates
client.connectWebSocket();

// Start a new job
async function processFiles() {
  try {
    const job = await client.startJob('input-folder/');
    console.log('Job started:', job.jobId);

    // Option 1: Poll for status updates (if WebSocket not available)
    const stopPolling = client.pollJobStatus(job.jobId, (status) => {
      console.log('Job status:', status);
      updateUI(status);
    });

    // Option 2: Real-time updates via WebSocket (already set up above)
    // Updates will come through the 'JobUpdate' event handler

  } catch (error) {
    console.error('Failed to start job:', error);
  }
}

// UI Update function
function updateUI(jobStatus) {
  const progressBar = document.getElementById('progress-bar');
  const statusText = document.getElementById('status-text');
  const fileCount = document.getElementById('file-count');

  if (progressBar) {
    progressBar.style.width = `${jobStatus.progress}%`;
    progressBar.setAttribute('aria-valuenow', jobStatus.progress);
  }

  if (statusText) {
    statusText.textContent = `Status: ${jobStatus.status}`;
  }

  if (fileCount) {
    fileCount.textContent = `Processed: ${jobStatus.processedFiles}/${jobStatus.totalFiles}`;
  }

  // Show download button when complete
  if (jobStatus.status === 'COMPLETED' && jobStatus.outputKey) {
    const downloadBtn = document.getElementById('download-btn');
    if (downloadBtn) {
      downloadBtn.style.display = 'block';
      downloadBtn.onclick = () => {
        client.downloadResults(jobStatus.outputKey, 'your-output-bucket');
      };
    }
  }
}

// Example HTML structure
/*
<div class="job-tracker">
  <h2>File Processing Job</h2>
  <div id="status-text">Status: Ready</div>
  <div id="file-count">Processed: 0/0</div>
  
  <div class="progress">
    <div id="progress-bar" 
         class="progress-bar" 
         role="progressbar" 
         style="width: 0%" 
         aria-valuenow="0" 
         aria-valuemin="0" 
         aria-valuemax="100">
      0%
    </div>
  </div>
  
  <button onclick="processFiles()">Start Processing</button>
  <button id="download-btn" style="display: none;">Download Results</button>
</div>
*/