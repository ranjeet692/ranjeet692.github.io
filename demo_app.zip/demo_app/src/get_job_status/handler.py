import json
import os
import boto3
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')

JOB_TABLE_NAME = os.environ['JOB_TABLE_NAME']
job_table = dynamodb.Table(JOB_TABLE_NAME)


class DecimalEncoder(json.JSONEncoder):
    """Helper class to convert DynamoDB Decimal to JSON."""
    def default(self, obj):
        if isinstance(obj, Decimal):
            return int(obj) if obj % 1 == 0 else float(obj)
        return super(DecimalEncoder, self).default(obj)


def lambda_handler(event, context):
    """
    Get job status from DynamoDB.
    GET /jobs/{jobId}
    """
    try:
        # Extract job ID from path parameters
        job_id = event['pathParameters']['jobId']
        
        print(f"Getting status for job: {job_id}")
        
        # Query DynamoDB
        response = job_table.get_item(Key={'jobId': job_id})
        
        if 'Item' not in response:
            return {
                'statusCode': 404,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'error': 'Job not found',
                    'jobId': job_id
                })
            }
        
        item = response['Item']
        
        # Calculate progress percentage
        total_files = int(item.get('totalFiles', 0))
        processed_files = int(item.get('processedFiles', 0))
        
        progress = 0
        if total_files > 0:
            progress = int((processed_files / total_files) * 100)
        
        # Build response
        job_status = {
            'jobId': item['jobId'],
            'status': item['status'],
            'createdAt': int(item['createdAt']),
            'totalFiles': total_files,
            'processedFiles': processed_files,
            'failedFiles': int(item.get('failedFiles', 0)),
            'progress': progress,
            'prefix': item.get('prefix', ''),
            'outputKey': item.get('outputKey'),
            'completedAt': int(item['completedAt']) if 'completedAt' in item else None,
            'message': item.get('message')
        }
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps(job_status, cls=DecimalEncoder)
        }
    
    except Exception as e:
        print(f"Error getting job status: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': str(e),
                'message': 'Failed to get job status'
            })
        }