import json
import os
import boto3
import requests
from datetime import datetime
from decimal import Decimal

s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')

JOB_TABLE_NAME = os.environ['JOB_TABLE_NAME']
LLM_API_KEY = os.environ['LLM_API_KEY']

job_table = dynamodb.Table(JOB_TABLE_NAME)


def extract_text_from_file(bucket, key):
    """
    Download and extract text content from S3 file.
    Supports: txt, json, csv, md files
    """
    response = s3.get_object(Bucket=bucket, Key=key)
    content = response['Body'].read()
    
    # Handle different file types
    if key.lower().endswith('.txt') or key.lower().endswith('.md'):
        return content.decode('utf-8')
    elif key.lower().endswith('.json'):
        data = json.loads(content.decode('utf-8'))
        return json.dumps(data, indent=2)
    elif key.lower().endswith('.csv'):
        return content.decode('utf-8')
    else:
        # For other types, try UTF-8 decode
        try:
            return content.decode('utf-8')
        except:
            return f"Binary file: {key}"


def call_llm_api(content, file_key):
    """
    Call external LLM API (example using OpenAI).
    Modify this for Anthropic, Bedrock, or other providers.
    """
    # OpenAI Example
    api_url = "https://api.openai.com/v1/chat/completions"
    
    headers = {
        "Authorization": f"Bearer {LLM_API_KEY}",
        "Content-Type": "application/json"
    }
    
    # Truncate content if too long
    max_chars = 10000
    truncated_content = content[:max_chars] if len(content) > max_chars else content
    
    payload = {
        "model": "gpt-4",
        "messages": [
            {
                "role": "system",
                "content": "You are a document analyzer. Summarize the following document and extract key insights."
            },
            {
                "role": "user",
                "content": f"File: {file_key}\n\nContent:\n{truncated_content}"
            }
        ],
        "max_tokens": 500,
        "temperature": 0.7
    }
    
    try:
        response = requests.post(api_url, headers=headers, json=payload, timeout=60)
        response.raise_for_status()
        result = response.json()
        
        return {
            'summary': result['choices'][0]['message']['content'],
            'model': result['model'],
            'usage': result.get('usage', {})
        }
    
    except requests.exceptions.RequestException as e:
        print(f"LLM API error: {str(e)}")
        raise


def update_job_progress(job_id):
    """
    Increment processed file count in DynamoDB.
    """
    try:
        job_table.update_item(
            Key={'jobId': job_id},
            UpdateExpression='SET processedFiles = processedFiles + :inc',
            ExpressionAttributeValues={':inc': 1}
        )
    except Exception as e:
        print(f"Error updating job progress: {str(e)}")


def lambda_handler(event, context):
    """
    Process a single file:
    1. Download from S3
    2. Extract content
    3. Call LLM API
    4. Update job progress
    """
    try:
        job_id = event['jobId']
        bucket = event['bucket']
        key = event['key']
        size = event['size']
        
        print(f"Processing file: {key} (Job: {job_id})")
        
        # Extract text content
        content = extract_text_from_file(bucket, key)
        print(f"Extracted {len(content)} characters from {key}")
        
        # Call LLM API
        llm_response = call_llm_api(content, key)
        print(f"LLM processing complete for {key}")
        
        # Update job progress
        update_job_progress(job_id)
        
        # Return result
        result = {
            'key': key,
            'size': size,
            'status': 'SUCCESS',
            'processedAt': datetime.utcnow().isoformat(),
            'contentLength': len(content),
            'llmResponse': llm_response
        }
        
        return result
    
    except Exception as e:
        error_msg = str(e)
        print(f"Error processing file {event.get('key')}: {error_msg}")
        
        # Update failed count
        try:
            job_table.update_item(
                Key={'jobId': event['jobId']},
                UpdateExpression='SET failedFiles = failedFiles + :inc',
                ExpressionAttributeValues={':inc': 1}
            )
        except:
            pass
        
        return {
            'key': event.get('key', 'unknown'),
            'status': 'FAILED',
            'error': error_msg,
            'processedAt': datetime.utcnow().isoformat()
        }