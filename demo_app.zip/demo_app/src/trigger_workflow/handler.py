import json
import os
import boto3
import uuid
from datetime import datetime
from urllib.parse import unquote_plus

stepfunctions = boto3.client('stepfunctions')

STATE_MACHINE_ARN = os.environ['STATE_MACHINE_ARN']
INPUT_BUCKET = os.environ['INPUT_BUCKET']


def lambda_handler(event, context):
    """
    Triggered by S3 event when files are uploaded.
    Starts the Step Functions workflow.
    """
    try:
        print(f"Received S3 event: {json.dumps(event)}")
        
        # Extract S3 event details
        for record in event['Records']:
            bucket = record['s3']['bucket']['name']
            key = unquote_plus(record['s3']['object']['key'])
            
            # Extract prefix (folder path)
            prefix = '/'.join(key.split('/')[:-1]) if '/' in key else ''
            
            # Generate unique job ID
            job_id = str(uuid.uuid4())
            timestamp = int(datetime.utcnow().timestamp())
            
            # Prepare Step Functions input
            sf_input = {
                'jobId': job_id,
                'bucket': bucket,
                'prefix': prefix,
                'timestamp': timestamp,
                'triggerType': 's3_event',
                'triggerKey': key
            }
            
            # Start Step Functions execution
            response = stepfunctions.start_execution(
                stateMachineArn=STATE_MACHINE_ARN,
                name=f"job-{job_id}",
                input=json.dumps(sf_input)
            )
            
            print(f"Started Step Functions execution: {response['executionArn']}")
            print(f"Job ID: {job_id}")
            
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': 'Workflow started successfully',
                    'jobId': job_id,
                    'executionArn': response['executionArn']
                })
            }
    
    except Exception as e:
        print(f"Error triggering workflow: {str(e)}")
        raise