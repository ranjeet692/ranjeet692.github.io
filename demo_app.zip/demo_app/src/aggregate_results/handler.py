import json
import os
import boto3
from datetime import datetime

s3 = boto3.client('s3')

OUTPUT_BUCKET = os.environ['OUTPUT_BUCKET']


def lambda_handler(event, context):
    """
    Aggregate all individual file processing results.
    Store the final output in S3 as JSON.
    """
    try:
        job_id = event['jobId']
        results = event['results']
        
        print(f"Aggregating results for job: {job_id}")
        
        # Extract actual results from Lambda invocation wrapper
        processed_results = []
        success_count = 0
        failure_count = 0
        
        for item in results:
            if 'result' in item and item['result']:
                result = item['result']
                processed_results.append(result)
                
                if result.get('status') == 'SUCCESS':
                    success_count += 1
                else:
                    failure_count += 1
        
        # Create aggregated output
        aggregated_data = {
            'jobId': job_id,
            'timestamp': datetime.utcnow().isoformat(),
            'summary': {
                'totalFiles': len(processed_results),
                'successfulFiles': success_count,
                'failedFiles': failure_count
            },
            'results': processed_results
        }
        
        # Store in S3
        output_key = f"results/{job_id}/aggregated_results.json"
        
        s3.put_object(
            Bucket=OUTPUT_BUCKET,
            Key=output_key,
            Body=json.dumps(aggregated_data, indent=2),
            ContentType='application/json'
        )
        
        print(f"Stored aggregated results: s3://{OUTPUT_BUCKET}/{output_key}")
        
        # Also create CSV summary if needed
        csv_key = f"results/{job_id}/summary.csv"
        csv_content = create_csv_summary(processed_results)
        
        s3.put_object(
            Bucket=OUTPUT_BUCKET,
            Key=csv_key,
            Body=csv_content,
            ContentType='text/csv'
        )
        
        return {
            'statusCode': 200,
            'outputKey': output_key,
            'csvKey': csv_key,
            'successCount': success_count,
            'failureCount': failure_count
        }
    
    except Exception as e:
        print(f"Error aggregating results: {str(e)}")
        raise


def create_csv_summary(results):
    """
    Create a CSV summary of all processed files.
    """
    csv_lines = ['File,Status,Content Length,Processed At,Error']
    
    for result in results:
        key = result.get('key', '')
        status = result.get('status', 'UNKNOWN')
        content_length = result.get('contentLength', 0)
        processed_at = result.get('processedAt', '')
        error = result.get('error', '')
        
        csv_lines.append(f"{key},{status},{content_length},{processed_at},{error}")
    
    return '\n'.join(csv_lines)