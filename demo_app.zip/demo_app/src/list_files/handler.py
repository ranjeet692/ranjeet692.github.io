import json
import os
import boto3
import uuid
from datetime import datetime

stepfunctions = boto3.client('stepfunctions')

STATE_MACHINE_ARN = os.environ['STATE_MACHINE_ARN']
INPUT_BUCKET = os.environ['INPUT_BUCKET']


def lambda_handler(event, context):
    """
    Manual API trigger to start the workflow.
    POST /jobs with body: { "prefix": "folder/path" }
    """
    try:
        # Parse request body
        body = json.loads(event.get('body', '{}'))
        prefix = body.get('prefix', '')
        
        # Generate unique job ID
        job_id = str(uuid.uuid4())
        timestamp = int(datetime.utcnow().timestamp())
        
        # Prepare Step Functions input
        sf_input = {
            'jobId': job_id,
            'bucket': INPUT_BUCKET,
            'prefix': prefix,
            'timestamp': timestamp,
            'triggerType': 'api_manual'
        }
        
        # Start Step Functions execution
        response = stepfunctions.start_execution(
            stateMachineArn=STATE_MACHINE_ARN,
            name=f"job-{job_id}",
            input=json.dumps(sf_input)
        )
        
        print(f"Started Step Functions execution: {response['executionArn']}")
        print(f"Job ID: {job_id}")
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'message': 'Workflow started successfully',
                'jobId': job_id,
                'executionArn': response['executionArn'],
                'bucket': INPUT_BUCKET,
                'prefix': prefix
            })
        }
    
    except Exception as e:
        print(f"Error starting workflow: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': str(e),
                'message': 'Failed to start workflow'
            })
        }