import json
import os
import boto3
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
apigateway_management = boto3.client('apigatewaymanagementapi')

WEBSOCKET_API_ENDPOINT = os.environ['WEBSOCKET_API_ENDPOINT']
CONNECTION_TABLE = os.environ['CONNECTION_TABLE']

connection_table = dynamodb.Table(CONNECTION_TABLE)


class DecimalEncoder(json.JSONEncoder):
    """Helper class to convert DynamoDB Decimal to JSON."""
    def default(self, obj):
        if isinstance(obj, Decimal):
            return int(obj) if obj % 1 == 0 else float(obj)
        return super(DecimalEncoder, self).default(obj)


def get_all_connections():
    """Get all active WebSocket connections."""
    try:
        response = connection_table.scan()
        return [item['connectionId'] for item in response.get('Items', [])]
    except Exception as e:
        print(f"Error getting connections: {str(e)}")
        return []


def send_to_connection(connection_id, data):
    """Send data to a specific WebSocket connection."""
    try:
        # Create API Gateway Management API client with endpoint
        endpoint_url = WEBSOCKET_API_ENDPOINT.replace('wss://', 'https://')
        client = boto3.client(
            'apigatewaymanagementapi',
            endpoint_url=endpoint_url
        )
        
        client.post_to_connection(
            ConnectionId=connection_id,
            Data=json.dumps(data, cls=DecimalEncoder).encode('utf-8')
        )
        return True
    
    except client.exceptions.GoneException:
        # Connection is gone, remove from table
        print(f"Connection {connection_id} is gone, removing from table")
        connection_table.delete_item(Key={'connectionId': connection_id})
        return False
    
    except Exception as e:
        print(f"Error sending to connection {connection_id}: {str(e)}")
        return False


def lambda_handler(event, context):
    """
    Process DynamoDB Stream events and push updates to WebSocket clients.
    """
    try:
        print(f"Processing {len(event['Records'])} stream records")
        
        for record in event['Records']:
            if record['eventName'] in ['INSERT', 'MODIFY']:
                # Extract new image (current state)
                new_image = record['dynamodb'].get('NewImage', {})
                
                # Convert DynamoDB format to regular dict
                job_data = {}
                for key, value in new_image.items():
                    if 'S' in value:
                        job_data[key] = value['S']
                    elif 'N' in value:
                        job_data[key] = int(value['N'])
                
                # Calculate progress
                total_files = job_data.get('totalFiles', 0)
                processed_files = job_data.get('processedFiles', 0)
                progress = 0
                
                if total_files > 0:
                    progress = int((processed_files / total_files) * 100)
                
                # Prepare update message
                update_message = {
                    'type': 'JOB_UPDATE',
                    'data': {
                        'jobId': job_data.get('jobId'),
                        'status': job_data.get('status'),
                        'totalFiles': total_files,
                        'processedFiles': processed_files,
                        'failedFiles': job_data.get('failedFiles', 0),
                        'progress': progress,
                        'outputKey': job_data.get('outputKey'),
                        'timestamp': job_data.get('createdAt')
                    }
                }
                
                # Get all connections and broadcast
                connections = get_all_connections()
                print(f"Broadcasting to {len(connections)} connections")
                
                for connection_id in connections:
                    send_to_connection(connection_id, update_message)
        
        return {
            'statusCode': 200,
            'body': 'Stream processed successfully'
        }
    
    except Exception as e:
        print(f"Error processing stream: {str(e)}")
        raise