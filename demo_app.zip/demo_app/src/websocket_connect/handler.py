import json
import os
import boto3
from datetime import datetime

dynamodb = boto3.resource('dynamodb')

CONNECTION_TABLE = os.environ.get('CONNECTION_TABLE', os.environ['JOB_TABLE_NAME'].replace('jobs', 'connections'))
connection_table = dynamodb.Table(CONNECTION_TABLE)


def lambda_handler(event, context):
    """
    Handle WebSocket $connect event.
    Store connection ID in DynamoDB.
    """
    try:
        connection_id = event['requestContext']['connectionId']
        
        # Store connection
        connection_table.put_item(
            Item={
                'connectionId': connection_id,
                'connectedAt': int(datetime.utcnow().timestamp())
            }
        )
        
        print(f"WebSocket connected: {connection_id}")
        
        return {
            'statusCode': 200,
            'body': 'Connected'
        }
    
    except Exception as e:
        print(f"Error connecting WebSocket: {str(e)}")
        return {
            'statusCode': 500,
            'body': f'Failed to connect: {str(e)}'
        }