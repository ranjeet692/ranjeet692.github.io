import json
import os
import boto3

dynamodb = boto3.resource('dynamodb')

CONNECTION_TABLE = os.environ.get('CONNECTION_TABLE', os.environ['JOB_TABLE_NAME'].replace('jobs', 'connections'))
connection_table = dynamodb.Table(CONNECTION_TABLE)


def lambda_handler(event, context):
    """
    Handle WebSocket $disconnect event.
    Remove connection ID from DynamoDB.
    """
    try:
        connection_id = event['requestContext']['connectionId']
        
        # Delete connection
        connection_table.delete_item(
            Key={'connectionId': connection_id}
        )
        
        print(f"WebSocket disconnected: {connection_id}")
        
        return {
            'statusCode': 200,
            'body': 'Disconnected'
        }
    
    except Exception as e:
        print(f"Error disconnecting WebSocket: {str(e)}")
        return {
            'statusCode': 500,
            'body': f'Failed to disconnect: {str(e)}'
        }