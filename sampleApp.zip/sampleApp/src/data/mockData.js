const workflowRuns = [
  { name: 'Invoice Processing', status: 'Completed', docsProcessed: 12, startedAt: '2024-01-15 10:00 AM', duration: '1h 30m', statusColor: 'green' },
  { name: 'Contract Review', status: 'In Progress', docsProcessed: 5, startedAt: '2024-01-15 11:30 AM', duration: '2h 15m', statusColor: 'blue' },
  { name: 'Compliance Check', status: 'Completed', docsProcessed: 20, startedAt: '2024-01-14 02:00 PM', duration: '3h 45m', statusColor: 'green' },
  { name: 'Report Generation', status: 'Failed', docsProcessed: 8, startedAt: '2024-01-14 09:00 AM', duration: '1h 00m', statusColor: 'red' },
  { name: 'Data Extraction', status: 'Completed', docsProcessed: 15, startedAt: '2021-01-13 04:30 PM', duration: '2h 00m', statusColor: 'green' },
];

const allWorkflowLogs = [
  { name: 'Invoice Processing', status: 'Success', startTime: '2024-01-15 10:00 AM', duration: '5 minutes', steps: 12, statusColor: 'green' },
  { name: 'Contract Review', status: 'Failed', startTime: '2024-01-14 03:30 PM', duration: '10 minutes', steps: 8, statusColor: 'red' },
  { name: 'Expense Report', status: 'Success', startTime: '2024-01-13 09:15 AM', duration: '3 minutes', steps: 5, statusColor: 'green' },
  { name: 'Legal Document Analysis', status: 'Success', startTime: '2024-01-12 02:00 PM', duration: '15 minutes', steps: 20, statusColor: 'green' },
  { name: 'Customer Onboarding', status: 'Failed', startTime: '2024-01-11 11:45 AM', duration: '8 minutes', steps: 10, statusColor: 'red' },
  { name: 'Financial Report', status: 'Success', startTime: '2024-01-10 04:00 PM', duration: '7 minutes', steps: 15, statusColor: 'green' },
];

const templates = [
  { title: 'Invoice Processing', description: 'Automate invoice data extraction', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAkevcHNOEIjv1o-KFv79ynLfyEkGh0wdQggztL0Io_-PyFbcPSpx2WFd9saF-LZav5hrBHrfJ3qtYGWRq3wsGnjTMXcdeg4n5WmtojWVtW8jevfaTIaWO09wq_anoXLpqp9vNkUNOWNnUWXKpk8wH-oRz8SHT8bJch-xcM1AWMSTg5_YPQk3_F_DlwxCAEbMNUrkc47R8wcCGNukQzKhi0WVyvBQDj46tLVBGX4oBacxF7r4HL6j6QKst6O8Skofl55zJ5XDFjETT9jZnQsBHHRmd82', href: '#' },
  { title: 'Contract Review', description: 'Streamline contract review process', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDPv7qBiR7rNjk6YS7KMz2R3QKPXNCsxjkV_YGxu4vvXOuspoXUtPAabsB8Kc7iIkuf-D_RGbCjU_2yetMqOrwyCgy0huCOCGbvZwHnqcvmOwQzogk3ZJcFOC-6o34-zoPhOIZY_f4iaDZwsvEXT5_MrdIsD-Dj2fdlneqOyEEiEEVGkKX2O4rqBVxIixb2X1bHIROt0WHBfN0FwZsJVmMT0ALAiHY07wybXiHc1zPiin993TZQ9OON4W4cU7Ay5M2soMctiuTA-YN', href: '#' },
  { title: 'Compliance Check', description: 'Ensure regulatory compliance', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDfY3lMcDKzAT0Fim1KYYvDUysMAFUTqX3aImbTEEodi_4d6u19GcM-OeEoTBkzrMfiTxee6AYFbEKg85LveS3odAHlUoujUY1PL4yMNMpWNaIEcRdclEUe-viGU_2VTPex_pEANzbFDKsPBSeyEWHZkabV5JhW5-i0OpBf9AzrKCFrLFCtE7dgFKYdjQnYZXjl6jAYw1xoU7Tn-BufHy1_8P9ukIjp_H_DC19iP32C-YkBk6bMjgPxgoPzdkhfGLH-wR2jCrsBngXthnLv6zxJxCYImKs3zvlf6rYgCkLp_1IcnCSNauwt64Sfw-C0g_JK56av3MlgX_Lpolae9z', href: '#' },
  { title: 'Report Generation', description: 'Generate custom reports', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCrXHE8NOVlwutVIrrQTJACbW4TysYM98DiY53TlCZWoVo5LJKZ6Ss3oQLJYF0DJGylXd0L8NvxNdITRBmTrqcejrI3F_R4evTrqwN9MJCjtStS_Zx6FWRYxftFowxzqTXHquaoNKFNr4v-Alb3JtsZId9QW6yHw25V7E68iK9tFDWoXFUpvzdkhfGLH-wR2jCrsBngXthnLv6zxJxCYImKs3zvlf6rYgCkLp_1IcnCSNauwt64Sfw-C0g_JK56av3MlgX_Lpolae9z', href: '#' },
];

export { workflowRuns, allWorkflowLogs, templates };