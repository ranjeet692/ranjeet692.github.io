import { Database, UploadCloud, Cpu, FileText, Blocks, List, File, Image } from 'lucide-react';

// Converted from src/data/workflows/resume_shortlisting.yaml
// Assumptions:
// - YAML node ids are preserved
// - Positions were not provided in YAML; reasonable default coordinates are assigned
// - Icons chosen based on node type and available lucide icons in the project

const workflowNodes = [
  {
    id: 'upload_files',
    name: 'Upload Files',
    icon: UploadCloud,
    category: 'Data Connectors',
    type: 'input',
    data: { label: 'Upload Files' },
    position: { x: 50, y: 80 },
    config: {
      fields: [
        { name: 'resumes', type: 'file_upload', accept: ['pdf', 'docx'], multiple: true, required: true, max_size_mb: 10, min_files: 1, max_files: 50, category: 'resume' },
        { name: 'job_description', type: 'file_upload', accept: ['pdf', 'docx', 'txt'], required: true, category: 'jd' },
        { name: 'min_experience_years', type: 'number', default: 0, min: 0, max: 50, description: 'Minimum years of experience required' }
      ],
      outputs: [
        { name: 'resume_files', type: 'file_array' },
        { name: 'jd_file', type: 'file' },
        { name: 'requirements', type: 'object' }
      ]
    }
  },

  {
    id: 'extract_requirements',
    name: 'Extract Requirements',
    icon: Cpu,
    category: 'Agents',
    type: 'agent',
    data: { label: 'Extract Requirements' },
    position: { x: 300, y: 40 },
    config: {
      depends_on: ['upload_files'],
      agent: {
        name: 'jd_analyzer',
        model: { provider: 'bedrock', model_id: 'anthropic.claude-3-sonnet-20240229-v1:0', temperature: 0.1, max_tokens: 2000 },
        prompt_template: `Extract key requirements from this job description.\n\nJob Description:\n{{job_description}}\n\nProvide a structured JSON response with: ...\nReturn ONLY valid JSON.`,
        input_mapping: { job_description: '$nodes.upload_files.outputs.jd_file.text' },
        output_schema: { type: 'object', required: ['title', 'required_skills', 'min_experience_years'] }
      },
      outputs: [{ name: 'requirements', type: 'object' }]
    }
  },

  {
    id: 'batch_resumes',
    name: 'Batch Resumes',
    icon: List,
    category: 'Batching',
    type: 'batch',
    data: { label: 'Batch Resumes' },
    position: { x: 300, y: 160 },
    config: {
      depends_on: ['upload_files'],
      batch_size: 10,
      strategy: 'even_distribution',
      input_mapping: { items: '$nodes.upload_files.outputs.resume_files' },
      outputs: [{ name: 'batches', type: 'array' }]
    }
  },

  {
    id: 'analyze_resumes',
    name: 'Analyze Resumes',
    icon: Blocks,
    category: 'Processors',
    type: 'parallel',
    data: { label: 'Analyze Resumes' },
    position: { x: 550, y: 100 },
    config: {
      depends_on: ['extract_requirements', 'batch_resumes'],
      concurrency: 5,
      foreach: '$nodes.batch_resumes.outputs.batches',
      agent: {
        name: 'resume_evaluator',
        model: { provider: 'bedrock', model_id: 'anthropic.claude-3-haiku-20240307-v1:0', temperature: 0.2, max_tokens: 1500 },
        prompt_template: `Evaluate this resume against the job requirements.\n\nJob Requirements:\n{{requirements}}\n\nResume:\n{{resume}}\n\nProvide evaluation in JSON: ...`,
        input_mapping: { requirements: '$nodes.extract_requirements.outputs.requirements', resume: '$item' },
        retry: { max_attempts: 2, backoff_seconds: 5 }
      },
      outputs: [{ name: 'evaluations', type: 'array' }]
    }
  },

  {
    id: 'aggregate_results',
    name: 'Aggregate Results',
    icon: FileText,
    category: 'Merging',
    type: 'merge',
    data: { label: 'Aggregate Results' },
    position: { x: 800, y: 100 },
    config: {
      depends_on: ['analyze_resumes'],
      strategy: 'flatten',
      input_mapping: { items: '$nodes.analyze_resumes.outputs.evaluations' },
      outputs: [{ name: 'all_evaluations', type: 'array' }]
    }
  },

  {
    id: 'categorize_candidates',
    name: 'Categorize Candidates',
    icon: File,
    category: 'Conditional',
    type: 'conditional',
    data: { label: 'Categorize Candidates' },
    position: { x: 1050, y: 100 },
    config: {
      depends_on: ['aggregate_results'],
      conditions: [
        { when: "$item.overall_score >= 80 && $item.recommendation in ['strong_yes', 'yes']", then: 'shortlisted' },
        { when: "$item.overall_score >= 60 && $item.overall_score < 80", then: 'maybe_list' },
        { otherwise: 'rejected' }
      ],
      input_mapping: { items: '$nodes.aggregate_results.outputs.all_evaluations' },
      outputs: [{ name: 'shortlisted', type: 'array' }, { name: 'maybe_list', type: 'array' }, { name: 'rejected', type: 'array' }]
    }
  },

  {
    id: 'generate_questions',
    name: 'Generate Questions',
    icon: Cpu,
    category: 'Agents',
    type: 'agent',
    data: { label: 'Generate Questions' },
    position: { x: 1050, y: 220 },
    config: {
      depends_on: ['categorize_candidates', 'extract_requirements'],
      agent: {
        name: 'question_generator',
        model: { provider: 'bedrock', model_id: 'anthropic.claude-3-sonnet-20240229-v1:0', temperature: 0.7, max_tokens: 1000 },
        prompt_template: `Generate 5 targeted interview questions for this candidate.`,
        input_mapping: { requirements: '$nodes.extract_requirements.outputs.requirements', candidate: '$item' },
        foreach: '$nodes.categorize_candidates.outputs.shortlisted'
      },
      outputs: [{ name: 'interview_guides', type: 'array' }]
    }
  },

  {
    id: 'generate_report',
    name: 'Generate Report',
    icon: Image,
    category: 'Outputs',
    type: 'output',
    data: { label: 'Generate Report' },
    position: { x: 1300, y: 150 },
    config: {
      depends_on: ['categorize_candidates', 'generate_questions'],
      format: 'html',
      template: 'shortlist_report.html',
      data_mapping: {
        job_title: '$nodes.extract_requirements.outputs.requirements.title',
        total_candidates: '$nodes.upload_files.outputs.resume_files.length',
        shortlisted: '$nodes.categorize_candidates.outputs.shortlisted',
        maybe_list: '$nodes.categorize_candidates.outputs.maybe_list',
        rejected: '$nodes.categorize_candidates.outputs.rejected',
        interview_guides: '$nodes.generate_questions.outputs.interview_guides',
        generated_at: '$now'
      },
      delivery: [
        { type: 's3', bucket: 'workflow-outputs', key: '{execution_id}/shortlist_report.html' },
        { type: 'email', to: ['hr@company.com'], subject: 'Resume Shortlist Report - {{job_title}}', template: 'email_notification.html' },
        { type: 'webhook', url: 'https://api.company.com/recruitment/webhook', method: 'POST', headers: { Authorization: 'Bearer ${SECRET_API_KEY}' } }
      ],
      outputs: [{ name: 'report_url', type: 'string' }, { name: 'summary', type: 'object' }]
    }
  }
];

const initialEdges = [
  { id: 'e_upload_extract', source: 'upload_files', target: 'extract_requirements', animated: true },
  { id: 'e_upload_batch', source: 'upload_files', target: 'batch_resumes', animated: true },
  { id: 'e_extract_analyze', source: 'extract_requirements', target: 'analyze_resumes', animated: true },
  { id: 'e_batch_analyze', source: 'batch_resumes', target: 'analyze_resumes', animated: true },
  { id: 'e_analyze_aggregate', source: 'analyze_resumes', target: 'aggregate_results' },
  { id: 'e_aggregate_categorize', source: 'aggregate_results', target: 'categorize_candidates' },
  { id: 'e_categorize_questions', source: 'categorize_candidates', target: 'generate_questions' },
  { id: 'e_extract_questions', source: 'extract_requirements', target: 'generate_questions' },
  { id: 'e_categorize_report', source: 'categorize_candidates', target: 'generate_report' },
  { id: 'e_questions_report', source: 'generate_questions', target: 'generate_report' }
];

export { workflowNodes, initialEdges };
