import { 
  Database, File, FileText, Cpu, Upload, Download,
  GitBranch, Layers, Repeat, Filter, Merge, Send,
  Brain, CheckCircle, AlertTriangle, Settings,
  FileSearch, Users, DollarSign, Shield, Scale,
  Clipboard, Search, BarChart, Target, Zap
} from 'lucide-react';

// ============================================================================
// NODE TYPE TO ICON MAPPING
// ============================================================================
const NODE_TYPE_ICONS = {
  input: Upload,
  agent: Brain,
  batch: Layers,
  parallel: Repeat,
  conditional: GitBranch,
  merge: Merge,
  output: Send,
  default: Cpu
};

// ============================================================================
// NODE CATEGORY TO ICON MAPPING
// ============================================================================
const CATEGORY_ICONS = {
  'Data Connectors': Database,
  'Processors': Cpu,
  'Gen AI': Brain,
  'ML Models': Target,
  'Validation': CheckCircle,
  'Transformation': Zap,
  'Output': Send
};

// ============================================================================
// WORKFLOW TEMPLATES
// ============================================================================

export const WORKFLOW_TEMPLATES = {
  
  // ---------------------------------------------------------------------------
  // RESUME SHORTLISTING WORKFLOW
  // ---------------------------------------------------------------------------
  resume_shortlisting: {
    id: 'resume_shortlisting',
    name: 'Resume Shortlisting',
    version: '1.0',
    description: 'Analyze resumes and shortlist candidates based on job requirements',
    metadata: {
      author: 'platform-team',
      created_at: '2025-10-14',
      tags: ['recruitment', 'ai', 'automation']
    },
    config: {
      timeout: 1800,
      retry_policy: {
        max_attempts: 3,
        backoff: 'exponential'
      }
    },
    nodes: [
      {
        id: 'upload_files',
        name: 'Upload Files',
        type: 'input',
        category: 'Data Connectors',
        icon: Upload,
        description: 'Upload resumes and job description',
        position: { x: 50, y: 100 },
        config: {
          fields: [
            {
              name: 'resumes',
              type: 'file_upload',
              accept: ['pdf', 'docx'],
              multiple: true,
              required: true,
              max_size_mb: 10,
              min_files: 1,
              max_files: 50
            },
            {
              name: 'job_description',
              type: 'file_upload',
              accept: ['pdf', 'docx', 'txt'],
              required: true
            },
            {
              name: 'min_experience_years',
              type: 'number',
              default: 0,
              min: 0,
              max: 50
            }
          ]
        },
        data: { label: 'Upload Files' }
      },
      {
        id: 'extract_requirements',
        name: 'Extract JD Requirements',
        type: 'agent',
        category: 'Gen AI',
        icon: Brain,
        description: 'Extract key requirements from job description',
        position: { x: 300, y: 50 },
        depends_on: ['upload_files'],
        config: {
          model: {
            provider: 'bedrock',
            model_id: 'anthropic.claude-3-sonnet-20240229-v1:0',
            temperature: 0.1,
            max_tokens: 2000
          },
          extract_fields: ['title', 'required_skills', 'min_experience_years', 'education_required']
        },
        data: { label: 'Extract Requirements' }
      },
      {
        id: 'batch_resumes',
        name: 'Batch Resumes',
        type: 'batch',
        category: 'Processors',
        icon: Layers,
        description: 'Group resumes into batches for parallel processing',
        position: { x: 300, y: 150 },
        depends_on: ['upload_files'],
        config: {
          batch_size: 10,
          strategy: 'even_distribution'
        },
        data: { label: 'Batch Process' }
      },
      {
        id: 'analyze_resumes',
        name: 'Analyze Resumes',
        type: 'parallel',
        category: 'Gen AI',
        icon: Repeat,
        description: 'Analyze each resume against requirements',
        position: { x: 550, y: 100 },
        depends_on: ['extract_requirements', 'batch_resumes'],
        config: {
          concurrency: 5,
          model: {
            provider: 'bedrock',
            model_id: 'anthropic.claude-3-haiku-20240307-v1:0',
            temperature: 0.2
          }
        },
        data: { label: 'Analyze Resumes' }
      },
      {
        id: 'aggregate_results',
        name: 'Aggregate Results',
        type: 'merge',
        category: 'Processors',
        icon: Merge,
        description: 'Combine all resume evaluations',
        position: { x: 800, y: 100 },
        depends_on: ['analyze_resumes'],
        config: {
          strategy: 'flatten'
        },
        data: { label: 'Merge Results' }
      },
      {
        id: 'categorize_candidates',
        name: 'Categorize Candidates',
        type: 'conditional',
        category: 'Processors',
        icon: GitBranch,
        description: 'Categorize candidates based on scores',
        position: { x: 1050, y: 100 },
        depends_on: ['aggregate_results'],
        config: {
          conditions: [
            { threshold: 80, category: 'shortlisted' },
            { threshold: 60, category: 'maybe_list' },
            { threshold: 0, category: 'rejected' }
          ]
        },
        data: { label: 'Categorize' }
      },
      {
        id: 'generate_questions',
        name: 'Generate Interview Questions',
        type: 'agent',
        category: 'Gen AI',
        icon: Brain,
        description: 'Generate interview questions for shortlisted candidates',
        position: { x: 1300, y: 50 },
        depends_on: ['categorize_candidates', 'extract_requirements'],
        config: {
          model: {
            provider: 'bedrock',
            model_id: 'anthropic.claude-3-sonnet-20240229-v1:0',
            temperature: 0.7
          },
          questions_per_candidate: 5
        },
        data: { label: 'Generate Questions' }
      },
      {
        id: 'generate_report',
        name: 'Generate Report',
        type: 'output',
        category: 'Output',
        icon: Send,
        description: 'Create final shortlisting report',
        position: { x: 1550, y: 100 },
        depends_on: ['categorize_candidates', 'generate_questions'],
        config: {
          format: 'html',
          delivery: ['s3', 'email', 'webhook']
        },
        data: { label: 'Send Report' }
      }
    ]
  },

  // ---------------------------------------------------------------------------
  // INVOICE PROCESSING WORKFLOW
  // ---------------------------------------------------------------------------
  invoice_processing: {
    id: 'invoice_processing',
    name: 'Invoice Processing',
    version: '1.0',
    description: 'Automate invoice data extraction, validation, and accounting system integration',
    metadata: {
      author: 'platform-team',
      created_at: '2025-10-14',
      tags: ['finance', 'invoice-processing', 'automation', 'accounts-payable']
    },
    config: {
      timeout: 1200,
      retry_policy: {
        max_attempts: 3,
        backoff: 'exponential'
      }
    },
    nodes: [
      {
        id: 'upload_invoices',
        name: 'Upload Invoices',
        type: 'input',
        category: 'Data Connectors',
        icon: Upload,
        description: 'Upload invoices for processing',
        position: { x: 50, y: 150 },
        config: {
          accept: ['pdf', 'png', 'jpg', 'jpeg'],
          max_files: 500,
          max_size_mb: 10,
          additional_fields: ['validate_against_pos', 'auto_approve_threshold', 'output_format']
        },
        data: { label: 'Upload Invoices' }
      },
      {
        id: 'load_reference_data',
        name: 'Load Reference Data',
        type: 'agent',
        category: 'Data Connectors',
        icon: Database,
        description: 'Load and parse reference data files',
        position: { x: 300, y: 50 },
        depends_on: ['upload_invoices'],
        config: {
          data_sources: ['po_reference', 'vendor_master', 'gl_mapping']
        },
        data: { label: 'Load References' }
      },
      {
        id: 'batch_invoices',
        name: 'Batch Invoices',
        type: 'batch',
        category: 'Processors',
        icon: Layers,
        description: 'Group invoices into batches',
        position: { x: 300, y: 200 },
        depends_on: ['upload_invoices'],
        config: {
          batch_size: 20,
          strategy: 'even_distribution'
        },
        data: { label: 'Batch Invoices' }
      },
      {
        id: 'extract_invoice_data',
        name: 'Extract Invoice Data',
        type: 'parallel',
        category: 'Gen AI',
        icon: FileSearch,
        description: 'Extract structured data from each invoice',
        position: { x: 550, y: 150 },
        depends_on: ['batch_invoices'],
        config: {
          concurrency: 10,
          ocr_enabled: true,
          model: {
            provider: 'bedrock',
            model_id: 'anthropic.claude-3-sonnet-20240229-v1:0',
            temperature: 0
          }
        },
        data: { label: 'Extract Data' }
      },
      {
        id: 'merge_extractions',
        name: 'Merge Extractions',
        type: 'merge',
        category: 'Processors',
        icon: Merge,
        description: 'Combine all invoice extractions',
        position: { x: 800, y: 150 },
        depends_on: ['extract_invoice_data'],
        config: {
          strategy: 'flatten'
        },
        data: { label: 'Merge Data' }
      },
      {
        id: 'validate_invoices',
        name: 'Validate Invoices',
        type: 'parallel',
        category: 'Validation',
        icon: CheckCircle,
        description: 'Validate invoice data for accuracy',
        position: { x: 1050, y: 100 },
        depends_on: ['merge_extractions', 'load_reference_data'],
        config: {
          concurrency: 15,
          checks: ['math_validation', 'required_fields', 'vendor_validation', 'po_matching', 'duplicate_check']
        },
        data: { label: 'Validate' }
      },
      {
        id: 'merge_validations',
        name: 'Merge Validations',
        type: 'merge',
        category: 'Processors',
        icon: Merge,
        description: 'Combine validation results',
        position: { x: 1300, y: 100 },
        depends_on: ['validate_invoices'],
        config: {
          strategy: 'join',
          join_type: 'left'
        },
        data: { label: 'Merge Validations' }
      },
      {
        id: 'categorize_invoices',
        name: 'Categorize Invoices',
        type: 'conditional',
        category: 'Processors',
        icon: GitBranch,
        description: 'Route invoices based on validation',
        position: { x: 1550, y: 100 },
        depends_on: ['merge_validations', 'upload_invoices'],
        config: {
          routes: ['auto_approved', 'needs_review', 'rejected', 'low_confidence']
        },
        data: { label: 'Categorize' }
      },
      {
        id: 'enrich_gl_accounts',
        name: 'Enrich GL Accounts',
        type: 'agent',
        category: 'Gen AI',
        icon: DollarSign,
        description: 'Map line items to GL accounts',
        position: { x: 1800, y: 50 },
        depends_on: ['categorize_invoices', 'load_reference_data'],
        config: {
          model: {
            provider: 'bedrock',
            model_id: 'anthropic.claude-3-haiku-20240307-v1:0'
          }
        },
        data: { label: 'GL Mapping' }
      },
      {
        id: 'generate_summary',
        name: 'Generate Summary',
        type: 'agent',
        category: 'Gen AI',
        icon: BarChart,
        description: 'Generate processing statistics',
        position: { x: 1800, y: 150 },
        depends_on: ['categorize_invoices'],
        config: {
          include_metrics: ['total_invoices', 'success_rate', 'vendor_summary', 'quality_metrics']
        },
        data: { label: 'Generate Summary' }
      },
      {
        id: 'export_output',
        name: 'Export Output',
        type: 'output',
        category: 'Output',
        icon: Send,
        description: 'Export to desired format',
        position: { x: 2050, y: 100 },
        depends_on: ['enrich_gl_accounts', 'generate_summary'],
        config: {
          formats: ['excel', 'csv', 'json', 'api'],
          delivery: ['s3', 'email', 'webhook']
        },
        data: { label: 'Export' }
      }
    ]
  },

  // ---------------------------------------------------------------------------
  // ENTITY EXTRACTION WORKFLOW
  // ---------------------------------------------------------------------------
  entity_extraction: {
    id: 'entity_extraction',
    name: 'Entity Extraction',
    version: '1.0',
    description: 'Extract structured entities from unstructured documents with validation and quality control',
    metadata: {
      author: 'platform-team',
      created_at: '2025-10-14',
      tags: ['data-extraction', 'nlp', 'automation', 'batch-processing']
    },
    config: {
      timeout: 1800
    },
    nodes: [
      {
        id: 'upload_documents',
        name: 'Upload Documents',
        type: 'input',
        category: 'Data Connectors',
        icon: Upload,
        description: 'Upload documents for entity extraction',
        position: { x: 50, y: 150 },
        config: {
          accept: ['pdf', 'docx', 'txt', 'jpg', 'png'],
          max_files: 100,
          entity_types: ['person', 'organization', 'location', 'date', 'money', 'email', 'phone']
        },
        data: { label: 'Upload Docs' }
      },
      {
        id: 'batch_documents',
        name: 'Batch Documents',
        type: 'batch',
        category: 'Processors',
        icon: Layers,
        description: 'Group documents into batches',
        position: { x: 300, y: 150 },
        depends_on: ['upload_documents'],
        config: {
          batch_size: 10
        },
        data: { label: 'Batch Docs' }
      },
      {
        id: 'extract_text',
        name: 'Extract Text',
        type: 'parallel',
        category: 'Processors',
        icon: FileText,
        description: 'Extract text with OCR',
        position: { x: 550, y: 150 },
        depends_on: ['batch_documents'],
        config: {
          ocr_enabled: true,
          concurrency: 5
        },
        data: { label: 'OCR Extract' }
      },
      {
        id: 'extract_entities_primary',
        name: 'Extract Entities',
        type: 'parallel',
        category: 'Gen AI',
        icon: Brain,
        description: 'Extract entities using AI',
        position: { x: 800, y: 150 },
        depends_on: ['extract_text'],
        config: {
          concurrency: 10,
          model: {
            provider: 'bedrock',
            model_id: 'anthropic.claude-3-sonnet-20240229-v1:0'
          }
        },
        data: { label: 'Extract Entities' }
      },
      {
        id: 'merge_extractions',
        name: 'Merge Extractions',
        type: 'merge',
        category: 'Processors',
        icon: Merge,
        description: 'Combine all entity extractions',
        position: { x: 1050, y: 150 },
        depends_on: ['extract_entities_primary'],
        config: {
          strategy: 'flatten'
        },
        data: { label: 'Merge' }
      },
      {
        id: 'validate_normalize',
        name: 'Validate & Normalize',
        type: 'agent',
        category: 'Validation',
        icon: CheckCircle,
        description: 'Validate and normalize entities',
        position: { x: 1300, y: 150 },
        depends_on: ['merge_extractions'],
        config: {
          tasks: ['format_validation', 'duplicate_detection', 'consistency_check']
        },
        data: { label: 'Validate' }
      },
      {
        id: 'assess_quality',
        name: 'Assess Quality',
        type: 'conditional',
        category: 'Validation',
        icon: GitBranch,
        description: 'Route based on extraction quality',
        position: { x: 1550, y: 150 },
        depends_on: ['validate_normalize'],
        config: {
          thresholds: {
            high_quality: 0.70,
            medium_quality: 0.30
          }
        },
        data: { label: 'Quality Check' }
      },
      {
        id: 'retry_low_quality',
        name: 'Retry Low Quality',
        type: 'agent',
        category: 'Gen AI',
        icon: Repeat,
        description: 'Re-extract with advanced model',
        position: { x: 1550, y: 300 },
        depends_on: ['assess_quality', 'extract_text'],
        config: {
          model: {
            provider: 'bedrock',
            model_id: 'anthropic.claude-3-opus-20240229-v1:0'
          }
        },
        data: { label: 'Retry Extract' }
      },
      {
        id: 'merge_final_results',
        name: 'Merge Final Results',
        type: 'merge',
        category: 'Processors',
        icon: Merge,
        description: 'Combine all results',
        position: { x: 1800, y: 200 },
        depends_on: ['assess_quality', 'retry_low_quality'],
        config: {
          strategy: 'concatenate'
        },
        data: { label: 'Final Merge' }
      },
      {
        id: 'generate_summary',
        name: 'Generate Summary',
        type: 'agent',
        category: 'Gen AI',
        icon: BarChart,
        description: 'Generate extraction summary',
        position: { x: 2050, y: 150 },
        depends_on: ['merge_final_results'],
        config: {
          include_statistics: true
        },
        data: { label: 'Summary' }
      },
      {
        id: 'output_results',
        name: 'Output Results',
        type: 'output',
        category: 'Output',
        icon: Send,
        description: 'Generate outputs in multiple formats',
        position: { x: 2300, y: 150 },
        depends_on: ['merge_final_results', 'generate_summary'],
        config: {
          formats: ['json', 'csv', 'excel', 'knowledge_graph']
        },
        data: { label: 'Export' }
      }
    ]
  },

  // ---------------------------------------------------------------------------
  // DOCUMENT COMPARISON WORKFLOW
  // ---------------------------------------------------------------------------
  document_comparison: {
    id: 'document_comparison',
    name: 'Document Comparison',
    version: '1.0',
    description: 'Compare two versions of documents to identify changes and critical modifications',
    metadata: {
      author: 'platform-team',
      created_at: '2025-10-14',
      tags: ['document-comparison', 'legal', 'compliance', 'version-control']
    },
    config: {
      timeout: 900
    },
    nodes: [
      {
        id: 'upload_documents',
        name: 'Upload Documents',
        type: 'input',
        category: 'Data Connectors',
        icon: Upload,
        description: 'Upload original and revised documents',
        position: { x: 50, y: 150 },
        config: {
          fields: ['original_document', 'revised_document', 'comparison_type']
        },
        data: { label: 'Upload Docs' }
      },
      {
        id: 'chunk_documents',
        name: 'Chunk Documents',
        type: 'parallel',
        category: 'Processors',
        icon: Layers,
        description: 'Split documents into semantic chunks',
        position: { x: 300, y: 150 },
        depends_on: ['upload_documents'],
        config: {
          concurrency: 2,
          strategy: 'semantic',
          chunk_size: 1000
        },
        data: { label: 'Chunk' }
      },
      {
        id: 'generate_embeddings',
        name: 'Generate Embeddings',
        type: 'parallel',
        category: 'Gen AI',
        icon: Brain,
        description: 'Generate embeddings for alignment',
        position: { x: 550, y: 150 },
        depends_on: ['chunk_documents'],
        config: {
          model: 'amazon.titan-embed-text-v2:0',
          dimensions: 1024
        },
        data: { label: 'Embeddings' }
      },
      {
        id: 'align_sections',
        name: 'Align Sections',
        type: 'agent',
        category: 'Gen AI',
        icon: GitBranch,
        description: 'Align sections using semantic similarity',
        position: { x: 800, y: 150 },
        depends_on: ['generate_embeddings'],
        config: {
          model: {
            provider: 'bedrock',
            model_id: 'anthropic.claude-3-sonnet-20240229-v1:0'
          }
        },
        data: { label: 'Align' }
      },
      {
        id: 'compare_sections',
        name: 'Compare Sections',
        type: 'parallel',
        category: 'Gen AI',
        icon: Search,
        description: 'Detailed comparison of aligned sections',
        position: { x: 1050, y: 150 },
        depends_on: ['align_sections'],
        config: {
          concurrency: 10,
          model: {
            provider: 'bedrock',
            model_id: 'anthropic.claude-3-haiku-20240307-v1:0'
          }
        },
        data: { label: 'Compare' }
      },
      {
        id: 'aggregate_changes',
        name: 'Aggregate Changes',
        type: 'merge',
        category: 'Processors',
        icon: Merge,
        description: 'Combine all comparisons',
        position: { x: 1300, y: 150 },
        depends_on: ['compare_sections'],
        config: {
          strategy: 'flatten'
        },
        data: { label: 'Aggregate' }
      },
      {
        id: 'flag_critical_changes',
        name: 'Flag Critical Changes',
        type: 'agent',
        category: 'Validation',
        icon: AlertTriangle,
        description: 'Identify critical modifications',
        position: { x: 1550, y: 100 },
        depends_on: ['aggregate_changes', 'align_sections'],
        config: {
          categories: ['legal', 'financial', 'dates', 'parties', 'scope']
        },
        data: { label: 'Flag Critical' }
      },
      {
        id: 'generate_summary',
        name: 'Generate Summary',
        type: 'agent',
        category: 'Gen AI',
        icon: BarChart,
        description: 'Create executive summary',
        position: { x: 1800, y: 150 },
        depends_on: ['aggregate_changes', 'flag_critical_changes'],
        config: {
          include_recommendations: true
        },
        data: { label: 'Summary' }
      },
      {
        id: 'generate_reports',
        name: 'Generate Reports',
        type: 'output',
        category: 'Output',
        icon: Send,
        description: 'Generate comparison reports',
        position: { x: 2050, y: 150 },
        depends_on: ['generate_summary', 'flag_critical_changes'],
        config: {
          formats: ['html', 'pdf', 'excel', 'json']
        },
        data: { label: 'Reports' }
      }
    ]
  },

  // ---------------------------------------------------------------------------
  // CONTRACT RISK ANALYSIS WORKFLOW
  // ---------------------------------------------------------------------------
  contract_risk_analysis: {
    id: 'contract_risk_analysis',
    name: 'Contract Risk Analysis',
    version: '1.0',
    description: 'Analyze contracts for legal risks, unfavorable terms, and missing protections',
    metadata: {
      author: 'platform-team',
      created_at: '2025-10-14',
      tags: ['legal', 'contract-analysis', 'risk-assessment', 'compliance']
    },
    config: {
      timeout: 600
    },
    nodes: [
      {
        id: 'upload_contract',
        name: 'Upload Contract',
        type: 'input',
        category: 'Data Connectors',
        icon: Upload,
        description: 'Upload contract for risk analysis',
        position: { x: 50, y: 150 },
        config: {
          accept: ['pdf', 'docx'],
          fields: ['contract_type', 'party_role', 'risk_tolerance', 'jurisdiction']
        },
        data: { label: 'Upload Contract' }
      },
      {
        id: 'extract_contract_text',
        name: 'Extract Text',
        type: 'agent',
        category: 'Processors',
        icon: FileText,
        description: 'Extract and structure contract text',
        position: { x: 300, y: 150 },
        depends_on: ['upload_contract'],
        config: {
          ocr_enabled: true,
          detect_sections: true
        },
        data: { label: 'Extract' }
      },
      {
        id: 'extract_metadata',
        name: 'Extract Metadata',
        type: 'agent',
        category: 'Gen AI',
        icon: Clipboard,
        description: 'Extract basic contract information',
        position: { x: 550, y: 50 },
        depends_on: ['extract_contract_text'],
        config: {
          fields: ['parties', 'dates', 'term_length', 'governing_law', 'contract_value']
        },
        data: { label: 'Metadata' }
      },
      {
        id: 'extract_clauses',
        name: 'Extract Clauses',
        type: 'agent',
        category: 'Gen AI',
        icon: FileSearch,
        description: 'Identify and extract all clauses',
        position: { x: 550, y: 150 },
        depends_on: ['extract_contract_text'],
        config: {
          model: {
            provider: 'bedrock',
            model_id: 'anthropic.claude-3-sonnet-20240229-v1:0'
          }
        },
        data: { label: 'Extract Clauses' }
      },
      {
        id: 'analyze_clause_risks',
        name: 'Analyze Clause Risks',
        type: 'parallel',
        category: 'Validation',
        icon: Shield,
        description: 'Assess risk level for each clause',
        position: { x: 800, y: 150 },
        depends_on: ['extract_clauses', 'upload_contract'],
        config: {
          concurrency: 10,
          risk_factors: ['unfavorable_terms', 'liability', 'ambiguity', 'compliance']
        },
        data: { label: 'Risk Analysis' }
      },
      {
        id: 'merge_risk_analyses',
        name: 'Merge Risk Analyses',
        type: 'merge',
        category: 'Processors',
        icon: Merge,
        description: 'Combine all risk analyses',
        position: { x: 1050, y: 150 },
        depends_on: ['analyze_clause_risks'],
        config: {
          strategy: 'flatten'
        },
        data: { label: 'Merge' }
      },
      {
        id: 'identify_missing_clauses',
        name: 'Identify Missing Clauses',
        type: 'agent',
        category: 'Validation',
        icon: AlertTriangle,
        description: 'Find standard clauses that are missing',
        position: { x: 1050, y: 50 },
        depends_on: ['extract_clauses', 'upload_contract'],
        config: {
          check_standard_clauses: true
        },
        data: { label: 'Missing Clauses' }
      },
      {
        id: 'calculate_overall_risk',
        name: 'Calculate Overall Risk',
        type: 'agent',
        category: 'Validation',
        icon: BarChart,
        description: 'Calculate overall risk score',
        position: { x: 1300, y: 100 },
        depends_on: ['merge_risk_analyses', 'identify_missing_clauses', 'extract_metadata'],
        config: {
          scoring_model: 'weighted_average'
        },
        data: { label: 'Risk Score' }
      },
      {
        id: 'generate_negotiation_strategy',
        name: 'Generate Negotiation Strategy',
        type: 'agent',
        category: 'Gen AI',
        icon: Target,
        description: 'Create negotiation recommendations',
        position: { x: 1550, y: 50 },
        depends_on: ['merge_risk_analyses', 'identify_missing_clauses', 'calculate_overall_risk'],
        config: {
          include_priorities: true,
          include_talking_points: true
        },
        data: { label: 'Strategy' }
      },
      {
        id: 'generate_executive_summary',
        name: 'Generate Executive Summary',
        type: 'agent',
        category: 'Gen AI',
        icon: FileText,
        description: 'Create executive summary',
        position: { x: 1550, y: 150 },
        depends_on: ['calculate_overall_risk', 'extract_metadata'],
        config: {
          target_audience: 'executives'
        },
        data: { label: 'Summary' }
      },
      {
        id: 'generate_reports',
        name: 'Generate Reports',
        type: 'output',
        category: 'Output',
        icon: Send,
        description: 'Create comprehensive reports',
        position: { x: 1800, y: 100 },
        depends_on: ['generate_executive_summary', 'calculate_overall_risk', 'generate_negotiation_strategy'],
        config: {
          formats: ['pdf', 'json'],
          delivery: ['s3', 'email', 'webhook']
        },
        data: { label: 'Reports' }
      }
    ]
  }
};

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Get all workflows as an array
 */
export const getAllWorkflows = () => {
  return Object.values(WORKFLOW_TEMPLATES);
};

/**
 * Get workflow by ID
 */
export const getWorkflowById = (id) => {
  return WORKFLOW_TEMPLATES[id];
};

/**
 * Get workflow names for dropdown
 */
export const getWorkflowNames = () => {
  return Object.values(WORKFLOW_TEMPLATES).map(wf => ({
    id: wf.id,
    name: wf.name,
    description: wf.description
  }));
};

/**
 * Generate edges from depends_on relationships
 */
export const generateEdges = (nodes) => {
  const edges = [];
  let edgeCounter = 0;

  nodes.forEach(node => {
    if (node.depends_on && node.depends_on.length > 0) {
      node.depends_on.forEach(sourceId => {
        edges.push({
          id: `e${edgeCounter++}`,
          source: sourceId,
          target: node.id,
          animated: node.type === 'parallel' || node.type === 'batch'
        });
      });
    }
  });

  return edges;
};

/**
 * Calculate automatic node positions in a layout
 */
export const autoLayoutNodes = (nodes) => {
  // Simple left-to-right layout based on dependencies
  const positioned = [];
  const levels = {};
  
  // Calculate level for each node (depth in dependency tree)
  const calculateLevel = (nodeId, visited = new Set()) => {
    if (visited.has(nodeId)) return 0;
    visited.add(nodeId);
    
    const node = nodes.find(n => n.id === nodeId);
    if (!node || !node.depends_on || node.depends_on.length === 0) {
      return 0;
    }
    
    const maxParentLevel = Math.max(
      ...node.depends_on.map(depId => calculateLevel(depId, new Set(visited)))
    );
    
    return maxParentLevel + 1;
  };
  
  // Assign levels
  nodes.forEach(node => {
    const level = calculateLevel(node.id);
    if (!levels[level]) levels[level] = [];
    levels[level].push(node);
  });
  
  // Position nodes
  const HORIZONTAL_SPACING = 250;
  const VERTICAL_SPACING = 100;
  
  Object.keys(levels).forEach(level => {
    const nodesAtLevel = levels[level];
    const levelNum = parseInt(level);
    
    nodesAtLevel.forEach((node, index) => {
      node.position = {
        x: 50 + (levelNum * HORIZONTAL_SPACING),
        y: 50 + (index * VERTICAL_SPACING)
      };
    });
  });
  
  return nodes;
};

/**
 * Get icon for node type
 */
export const getIconForNodeType = (type) => {
  return NODE_TYPE_ICONS[type] || NODE_TYPE_ICONS.default;
};

/**
 * Get icon for category
 */
export const getIconForCategory = (category) => {
  return CATEGORY_ICONS[category] || Cpu;
};

// ============================================================================
// EXPORTS
// ============================================================================

export default WORKFLOW_TEMPLATES;