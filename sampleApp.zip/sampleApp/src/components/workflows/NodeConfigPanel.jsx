import React, { useState, useEffect } from 'react';
import { Settings2, X } from 'lucide-react';

const NodeConfigPanel = ({ selectedNode, onClose, onUpdateNode }) => {
  const [formData, setFormData] = useState(selectedNode?.config || {});

  useEffect(() => {
    setFormData(selectedNode?.config || {});
  }, [selectedNode]);

  if (!selectedNode) return null;

  const handleConfigChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSave = () => {
    onUpdateNode(selectedNode.id, formData);
    onClose();
  };

  const renderConfigField = (key, value) => {
    if (typeof value === 'boolean') {
      return (
        <div key={key} className="flex items-center justify-between">
          <label className="text-sm font-medium text-gray-800 dark:text-gray-200">
            {key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1')}
          </label>
          <input
            type="checkbox"
            name={key}
            checked={formData[key] || false}
            onChange={handleConfigChange}
            className="h-5 w-5 rounded border-gray-300 text-[#1173d4] focus:ring-[#1173d4] dark:border-gray-600 dark:bg-gray-700"
          />
        </div>
      );
    }
    
    const isTextArea = key.toLowerCase().includes('query') || key.toLowerCase().includes('prompt');

    return (
      <div key={key} className="space-y-1">
        <label htmlFor={key} className="text-sm font-medium text-gray-800 dark:text-gray-200">
          {key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1')}
        </label>
        {isTextArea ? (
          <textarea
            id={key}
            name={key}
            value={formData[key] || ''}
            onChange={handleConfigChange}
            rows={3}
            className="w-full rounded-lg border border-gray-300 bg-white p-2 text-sm text-gray-900 focus:border-[#1173d4] focus:ring-[#1173d4] dark:border-gray-600 dark:bg-gray-700 dark:text-white"
          />
        ) : (
          <input
            id={key}
            type="text"
            name={key}
            value={formData[key] || ''}
            onChange={handleConfigChange}
            className="w-full rounded-lg border border-gray-300 bg-white p-2 text-sm text-gray-900 focus:border-[#1173d4] focus:ring-[#1173d4] dark:border-gray-600 dark:bg-gray-700 dark:text-white"
          />
        )}
      </div>
    );
  };

  return (
    <div className="absolute right-0 z-10 h-full w-96 flex-col border-l border-gray-200/50 bg-[#f6f7f8] shadow-2xl transition-transform dark:border-gray-500/10 dark:bg-[#101922] flex">
      <header className="flex items-center justify-between p-4 border-b border-gray-200/50 dark:border-gray-500/10">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">
          <Settings2 className="inline-block h-5 w-5 mr-2 text-[#1173d4]" />
          {selectedNode.name} Configuration
        </h2>
        <button onClick={onClose} className="rounded-full p-1 transition-colors hover:bg-gray-200 dark:hover:bg-gray-700">
          <X className="h-5 w-5 text-gray-500 dark:text-gray-400" />
        </button>
      </header>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {Object.keys(selectedNode.config).map(key => renderConfigField(key, selectedNode.config[key]))}
      </div>

      <footer className="p-4 border-t border-gray-200/50 dark:border-gray-500/10 flex justify-end gap-2">
        <button 
          onClick={onClose} 
          className="rounded-lg bg-gray-200 px-4 py-2 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600"
        >
          Cancel
        </button>
        <button 
          onClick={handleSave} 
          className="rounded-lg bg-[#1173d4] px-4 py-2 text-sm font-medium text-white shadow-sm transition-colors hover:bg-[#1173d4]/90"
        >
          Save Changes
        </button>
      </footer>
    </div>
  );
};


export default NodeConfigPanel;