import React, { useState } from 'react';

const NodeGridItem = ({ name, Icon, description, nodeType }) => {
  const [showTooltip, setShowTooltip] = useState(false);

  // Type colors
  const typeColors = {
    input: 'border-green-200 hover:bg-green-50 dark:border-green-800 dark:hover:bg-green-900/20',
    agent: 'border-purple-200 hover:bg-purple-50 dark:border-purple-800 dark:hover:bg-purple-900/20',
    batch: 'border-blue-200 hover:bg-blue-50 dark:border-blue-800 dark:hover:bg-blue-900/20',
    parallel: 'border-indigo-200 hover:bg-indigo-50 dark:border-indigo-800 dark:hover:bg-indigo-900/20',
    conditional: 'border-yellow-200 hover:bg-yellow-50 dark:border-yellow-800 dark:hover:bg-yellow-900/20',
    merge: 'border-orange-200 hover:bg-orange-50 dark:border-orange-800 dark:hover:bg-orange-900/20',
    output: 'border-red-200 hover:bg-red-50 dark:border-red-800 dark:hover:bg-red-900/20',
    default: 'border-gray-200 hover:bg-gray-50 dark:border-gray-700 dark:hover:bg-gray-800'
  };

  const colorClass = typeColors[nodeType] || typeColors.default;

  return (
    <div 
      className="relative"
      onMouseEnter={() => setShowTooltip(true)}
      onMouseLeave={() => setShowTooltip(false)}
    >
      <div 
        className={`flex cursor-grab flex-col items-center gap-2 rounded-lg border-2 bg-white dark:bg-gray-900 p-3 text-center shadow-sm transition-all ${colorClass}`}
      >
        <Icon className="h-5 w-5 text-[#1173d4]" />
        <h3 className="text-xs font-semibold text-gray-800 dark:text-gray-200 line-clamp-2 leading-tight">
          {name}
        </h3>
      </div>
      
      {/* Tooltip */}
      {showTooltip && description && (
        <div className="absolute left-full top-0 ml-2 z-50 w-64 rounded-lg border border-gray-200 bg-white p-3 shadow-xl dark:border-gray-700 dark:bg-gray-800">
          <div className="flex items-start gap-2">
            <Icon className="h-4 w-4 text-[#1173d4] flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-1">{name}</h4>
              <p className="text-xs text-gray-600 dark:text-gray-400">{description}</p>
              <div className="mt-2 pt-2 border-t border-gray-200 dark:border-gray-700">
                <span className="inline-block px-2 py-0.5 text-xs rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                  {nodeType || 'default'}
                </span>
              </div>
            </div>
          </div>
          {/* Arrow pointer */}
          <div className="absolute right-full top-4 w-0 h-0 border-t-4 border-b-4 border-r-4 border-transparent border-r-gray-200 dark:border-r-gray-700"></div>
        </div>
      )}
    </div>
  );
};

export default NodeGridItem;