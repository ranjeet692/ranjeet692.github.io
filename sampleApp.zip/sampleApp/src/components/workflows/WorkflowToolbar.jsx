// src/components/workflows/WorkflowToolbar.jsx

import React, { useState, useRef, useEffect } from 'react';
import { 
  Upload, Download, Save, Send, 
  ChevronDown, Blocks, Check 
} from 'lucide-react';

// Import workflow list
import { getWorkflowNames } from '../../data/nodeConfig';

const WorkflowToolbar = ({ workflowName, currentWorkflowId, onWorkflowChange }) => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);
  
  // Get all available workflows
  const availableWorkflows = getWorkflowNames();

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleWorkflowSelect = (workflowId) => {
    onWorkflowChange(workflowId);
    setIsDropdownOpen(false);
  };

  return (
    <div className="flex h-16 shrink-0 items-center justify-between border-b border-gray-200/50 bg-[#f6f7f8] px-4 dark:border-gray-700/50 dark:bg-[#101922]">
      <div className="flex items-center gap-4">
        {/* Workflow Selector Dropdown */}
        <div className="relative" ref={dropdownRef}>
          <button
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            className="flex items-center gap-2 rounded-lg bg-white px-3 py-2 text-sm font-medium text-gray-700 ring-1 ring-inset ring-gray-300 transition-colors hover:bg-gray-50 dark:bg-gray-800 dark:text-gray-300 dark:ring-gray-600 dark:hover:bg-gray-700"
          >
            <Blocks className="h-4 w-4 text-[#1173d4]" />
            <span className="max-w-[180px] truncate">
              {workflowName || 'Select Workflow'}
            </span>
            <ChevronDown className={`h-4 w-4 transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} />
          </button>
          
          {/* Dropdown Menu */}
          {isDropdownOpen && (
            <div className="absolute left-0 top-full mt-2 w-80 rounded-lg border border-gray-200 bg-white shadow-xl dark:border-gray-700 dark:bg-gray-800 z-50 max-h-96 overflow-y-auto">
              <div className="p-2">
                <div className="px-3 py-2 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Available Workflows
                </div>
                {availableWorkflows.map((workflow) => (
                  <button
                    key={workflow.id}
                    onClick={() => handleWorkflowSelect(workflow.id)}
                    className={`w-full rounded-md px-3 py-2.5 text-left transition-colors ${
                      currentWorkflowId === workflow.id
                        ? 'bg-blue-50 dark:bg-blue-900/20'
                        : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-gray-900 dark:text-white flex items-center gap-2">
                          {workflow.name}
                          {currentWorkflowId === workflow.id && (
                            <Check className="h-4 w-4 text-[#1173d4]" />
                          )}
                        </div>
                        <div className="text-xs text-gray-500 dark:text-gray-400 mt-0.5 line-clamp-2">
                          {workflow.description}
                        </div>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
        
        {/* Current Workflow Name */}
        <div className="hidden md:block">
          <h2 className="text-lg font-bold text-gray-900 dark:text-white">
            {workflowName || 'Workflow Builder'}
          </h2>
        </div>
        
        {/* Status Badge */}
        <span className="rounded-full bg-gray-200 px-3 py-1 text-xs font-medium text-gray-600 dark:bg-gray-700 dark:text-gray-300">
          Draft
        </span>
      </div>
      
      {/* Action Buttons */}
      <div className="flex items-center gap-2">
        <button 
          className="flex items-center gap-1.5 rounded-lg bg-gray-200 px-3 py-2 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600"
          title="Import workflow"
        >
          <Upload className="h-4 w-4" />
          <span className="hidden sm:inline">Import</span>
        </button>
        
        <button 
          className="flex items-center gap-1.5 rounded-lg bg-gray-200 px-3 py-2 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600"
          title="Export workflow"
        >
          <Download className="h-4 w-4" />
          <span className="hidden sm:inline">Export</span>
        </button>
        
        <button 
          className="flex items-center gap-1.5 rounded-lg bg-white px-3 py-2 text-sm font-medium text-[#1173d4] ring-1 ring-inset ring-[#1173d4]/50 transition-colors hover:bg-gray-50 dark:bg-gray-900 dark:text-[#1173d4] dark:ring-[#1173d4]/30 dark:hover:bg-gray-800"
          title="Save workflow"
        >
          <Save className="h-4 w-4" />
          <span className="hidden sm:inline">Save</span>
        </button>
        
        <button 
          className="flex items-center gap-1.5 rounded-lg bg-[#1173d4] px-4 py-2 text-sm font-semibold text-white shadow-md shadow-[#1173d4]/30 transition-all hover:bg-[#1173d4]/90"
          title="Deploy workflow"
        >
          <Send className="h-4 w-4" />
          <span>Deploy</span>
        </button>
      </div>
    </div>
  );
};

export default WorkflowToolbar;