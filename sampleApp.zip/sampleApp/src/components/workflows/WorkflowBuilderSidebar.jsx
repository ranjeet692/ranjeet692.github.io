// src/components/workflows/WorkflowBuilderSidebar.jsx

import React, { useState, useMemo } from 'react';
import NodeGridItem from './NodeGridItem';

const WorkflowBuilderSidebar = ({ currentWorkflow, nodes }) => {
  // Extract unique categories from the current workflow's nodes
  const categories = useMemo(() => {
    if (!nodes || nodes.length === 0) return ['Nodes'];
    
    const uniqueCategories = [...new Set(nodes.map(node => node.category))];
    return ['Nodes', ...uniqueCategories];
  }, [nodes]);

  const [activeTab, setActiveTab] = useState('Nodes');
  
  // Filter nodes based on active category
  const filteredNodes = useMemo(() => {
    if (!nodes) return [];
    if (activeTab === 'Nodes') return nodes;
    return nodes.filter(node => node.category === activeTab);
  }, [nodes, activeTab]);

  // Group nodes by type for better organization
  const nodesByType = useMemo(() => {
    const grouped = {};
    filteredNodes.forEach(node => {
      const type = node.type || 'default';
      if (!grouped[type]) grouped[type] = [];
      grouped[type].push(node);
    });
    return grouped;
  }, [filteredNodes]);

  // Type display names and colors
  const typeInfo = {
    input: { name: 'Input', color: 'text-green-600 dark:text-green-400' },
    agent: { name: 'Agent', color: 'text-purple-600 dark:text-purple-400' },
    batch: { name: 'Batch', color: 'text-blue-600 dark:text-blue-400' },
    parallel: { name: 'Parallel', color: 'text-indigo-600 dark:text-indigo-400' },
    conditional: { name: 'Conditional', color: 'text-yellow-600 dark:text-yellow-400' },
    merge: { name: 'Merge', color: 'text-orange-600 dark:text-orange-400' },
    output: { name: 'Output', color: 'text-red-600 dark:text-red-400' },
    default: { name: 'Processing', color: 'text-gray-600 dark:text-gray-400' }
  };

  return (
    <aside className="hidden lg:flex w-80 flex-col border-r border-gray-200/50 dark:border-gray-500/10 shrink-0 bg-white dark:bg-[#101922]">
      {/* Header */}
      <div className="p-4 border-b border-gray-200/50 dark:border-gray-500/10">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">Workflow Nodes</h2>
        {currentWorkflow && (
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
            {currentWorkflow.name} • {nodes.length} nodes
          </p>
        )}
      </div>
      
      {/* Category tabs */}
      <div className="border-b border-gray-200/50 dark:border-gray-500/10">
        <nav aria-label="Tabs" className="-mb-px flex space-x-2 px-4 overflow-x-auto scrollbar-thin">
          {categories.map((category) => (
            <button
              key={category}
              className={`whitespace-nowrap border-b-2 px-2 py-3 text-xs font-medium transition-colors ${
                activeTab === category
                  ? 'border-[#1173d4] text-[#1173d4]'
                  : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 dark:text-gray-400 dark:hover:border-gray-600 dark:hover:text-gray-200'
              }`}
              onClick={() => setActiveTab(category)}
            >
              {category}
            </button>
          ))}
        </nav>
      </div>
      
      {/* Nodes list */}
      <div className="flex-1 overflow-y-auto p-4">
        {filteredNodes.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-sm text-gray-500 dark:text-gray-400">No nodes in this category</p>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Group by type */}
            {Object.entries(nodesByType).map(([type, typeNodes]) => (
              <div key={type}>
                {/* Type header */}
                <div className="flex items-center gap-2 mb-3">
                  <h3 className={`text-xs font-semibold uppercase tracking-wider ${typeInfo[type]?.color || typeInfo.default.color}`}>
                    {typeInfo[type]?.name || typeInfo.default.name}
                  </h3>
                  <div className="flex-1 h-px bg-gray-200 dark:bg-gray-700"></div>
                  <span className="text-xs text-gray-400 dark:text-gray-500">{typeNodes.length}</span>
                </div>
                
                {/* Nodes grid */}
                <div className="grid grid-cols-2 gap-3">
                  {typeNodes.map((node) => (
                    <NodeGridItem 
                      key={node.id} 
                      name={node.name} 
                      Icon={node.icon}
                      description={node.description}
                      nodeType={node.type}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Footer with stats */}
      <div className="p-4 border-t border-gray-200/50 dark:border-gray-500/10 bg-gray-50 dark:bg-gray-800/50">
        <div className="text-xs text-gray-600 dark:text-gray-400">
          <div className="flex justify-between mb-1">
            <span>Showing:</span>
            <span className="font-medium">{filteredNodes.length} of {nodes.length} nodes</span>
          </div>
          {activeTab !== 'Nodes' && (
            <button
              onClick={() => setActiveTab('Nodes')}
              className="text-[#1173d4] hover:underline text-xs mt-1"
            >
              View all nodes
            </button>
          )}
        </div>
      </div>
    </aside>
  );
};

export default WorkflowBuilderSidebar;