const WorkflowNode = ({ node, onSelect, isSelected }) => {
  const Icon = node.icon;
  
  return (
    <div
      onClick={() => onSelect(node)}
      className={`absolute flex cursor-pointer flex-col items-center gap-2 rounded-lg border p-4 shadow-md transition-all 
        ${isSelected 
          ? 'border-[#1173d4] ring-2 ring-[#1173d4] bg-white dark:bg-gray-700' 
          : 'border-gray-300 bg-white hover:shadow-lg dark:border-gray-600 dark:bg-gray-800 dark:hover:border-[#1173d4]'}
      `}
      style={{ left: node.position.x, top: node.position.y }}
    >
      <Icon className="h-6 w-6 text-[#1173d4]" />
      <span className="text-sm font-medium text-gray-900 dark:text-white">{node.data.label}</span>
      <div className="absolute -left-2 top-1/2 h-4 w-4 rounded-full bg-gray-400 dark:bg-gray-500 border-2 border-white dark:border-[#101922]"></div>
      <div className="absolute -right-2 top-1/2 h-4 w-4 rounded-full bg-gray-400 dark:bg-gray-500 border-2 border-white dark:border-[#101922]"></div>
    </div>
  );
};

export default WorkflowNode;