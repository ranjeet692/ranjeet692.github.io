const Logo = () => (
  <div className="flex items-center gap-2 text-gray-800 dark:text-white">
    <svg className="h-6 w-6 text-[#1173d4]" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path d="M16.883 14.899L12 17.525L7.117 14.899L3 12.825L12 7.675L21 12.825L16.883 14.899Z"></path>
      <path d="M12 21.325L3 16.175V7.675L12 2.525L21 7.675V16.175L12 21.325ZM12 19.175L18.883 15.1V9.4L12 13.525L5.117 9.4V15.1L12 19.175Z"></path>
    </svg>
    <h1 className="text-lg font-bold">DocuMind</h1>
  </div>
);

export default Logo;