const StatusPill = ({ status, color }) => {
  const isPulsing = status === 'In Progress';
  let bgColor, textColor;

  switch(color) {
    case 'green': 
      bgColor = 'bg-green-500/10';
      textColor = 'text-green-500';
      break;
    case 'red': 
      bgColor = 'bg-red-500/10';
      textColor = 'text-red-500';
      break;
    case 'blue': 
      bgColor = 'bg-blue-500/10';
      textColor = 'text-blue-500';
      break;
    default:
      bgColor = 'bg-gray-500/10';
      textColor = 'text-gray-500';
  }
  
  return (
    <span className={`inline-flex items-center rounded-full px-2 py-1 text-xs font-medium ${bgColor} ${textColor}`}>
      {isPulsing && (
        <svg className={`-ml-0.5 mr-1 h-2 w-2 ${textColor} animate-pulse`} fill="currentColor" viewBox="0 0 8 8">
          <circle cx="4" cy="4" r="3"></circle>
        </svg>
      )}
      {status}
    </span>
  );
};

export default StatusPill;