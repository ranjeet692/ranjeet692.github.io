const NavItem = ({ name, currentPage, onNavigate }) => (
  <button
    className={`rounded-lg px-3 py-2 text-sm transition-colors ${
      currentPage === name
        ? 'bg-[#1173d4]/10 font-semibold text-[#1173d4] dark:bg-[#1173d4]/20 dark:text-white'
        : 'font-medium text-gray-600 hover:bg-[#1173d4]/10 hover:text-[#1173d4] dark:text-gray-300 dark:hover:bg-[#1173d4]/20 dark:hover:text-white'
    }`}
    onClick={() => onNavigate(name)}
  >
    {name}
  </button>
);

export default NavItem;