import React from 'react';
import { Search } from 'lucide-react';

import { PAGES } from '../../config/constants';

import Logo from './Logo';
import NavItem from './NavItem';

const Header = ({ currentPage, onNavigate }) => (
  <header className="sticky top-0 z-20 flex h-16 shrink-0 items-center justify-between border-b border-white/10 bg-[#f6f7f8]/80 px-4 backdrop-blur-sm dark:bg-[#101922]/80 sm:px-6 lg:px-8">
    <div className="flex items-center gap-6">
      <Logo />
      <nav className="hidden items-center gap-4 md:flex">
        {Object.values(PAGES).map(pageName => (
          <NavItem
            key={pageName}
            name={pageName}
            currentPage={currentPage}
            onNavigate={onNavigate}
          />
        ))}
      </nav>
    </div>
    <div className="flex items-center gap-4">
      <div className="relative hidden md:block">
        <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-500 dark:text-gray-400" />
        <input
          className="h-10 w-full min-w-[200px] rounded-lg border-none bg-white/50 pl-10 pr-4 text-sm text-gray-900 ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-[#1173d4] dark:bg-white/10 dark:text-white dark:ring-white/20 dark:placeholder:text-gray-400 dark:focus:ring-[#1173d4]"
          placeholder="Search"
          type="search"
        />
      </div>
      <button className="relative h-10 w-10 rounded-full">
        <img
          alt="User avatar"
          className="h-full w-full rounded-full object-cover"
          src="https://lh3.googleusercontent.com/aida-public/AB6AXuBFaPa-lKHfq9SaASLSuPIDqmDhfpqjBgCysjsezFxmrL3Gfihd8jgPRI6qmxu_42uhQLVUMWkGbio21V6rs5WmtojWVtW8jevfaTIaWO09wq_anoXLpqp9vNkUNOWNnUWXKpk8wH-oRz8SHT8bJch-xcM1AWMSTg5_YPQk3_F_DlwxCAEbMNUrkc47R8wcCGNukQzKhi0WVyvBQDj46tLVBGX4oBacxF7r4HL6j6QKst6O8Skofl55zJ5XDFjETT9jZnQsBHHRmd82"
        />
      </button>
    </div>
  </header>
);

export default Header;