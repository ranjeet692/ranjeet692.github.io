import { 
  // General Icons
  Search, UploadCloud, Plus, X, Settings2, Filter, ChevronDown, List, Clock,
  // New Icons for Workflow Builder Toolbar
  Save, Upload, Download, Send,
  // Navigation Icons
  LayoutDashboard, Settings, FileText, Blocks, Heart, 
  // Workflow Builder Nodes
  Database, Folders, Cloud, Cpu, File, Image 
} from 'lucide-react';

const DashboardActions = ({ onNavigate }) => (
  <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
    <div>
      <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Dashboard</h2>
      <p className="text-gray-500 dark:text-gray-400">Welcome back, Sarah. Here's what's happening.</p>
    </div>
    <div className="flex gap-2">
      <button className="flex h-10 items-center justify-center gap-2 rounded-lg bg-white px-4 text-sm font-medium text-gray-700 ring-1 ring-inset ring-gray-300 transition-all hover:bg-gray-50 dark:bg-white/10 dark:text-gray-300 dark:ring-white/20 dark:hover:bg-white/20">
        <UploadCloud className="h-4 w-4" />
        <span>Upload Documents</span>
      </button>
      <button 
        className="flex h-10 items-center justify-center gap-2 rounded-lg bg-[#1173d4] px-4 text-sm font-medium text-white shadow-sm transition-all hover:bg-[#1173d4]/90"
        onClick={() => onNavigate(PAGES.WORKFLOWS)}
      >
        <Plus className="h-4 w-4" />
        <span>Create Workflow</span>
      </button>
    </div>
  </div>
);

export default DashboardActions;