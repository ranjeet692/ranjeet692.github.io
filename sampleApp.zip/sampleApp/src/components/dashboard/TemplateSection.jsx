import { templates } from "../../data/mockData";

import TemplateCard from "./TemplateCard";

const TemplateSection = () => (
  <section>
    <h3 className="mb-4 text-xl font-semibold text-gray-900 dark:text-white">Frequently Used Templates</h3>
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {templates.map((template, index) => (
        <TemplateCard key={index} template={template} />
      ))}
    </div>
  </section>
);

export default TemplateSection;