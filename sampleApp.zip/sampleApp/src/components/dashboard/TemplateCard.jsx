const TemplateCard = ({ template }) => (
  <div className="group overflow-hidden rounded-lg border border-gray-200 bg-white transition-all hover:shadow-lg dark:border-white/10 dark:bg-[#101922]/50 dark:hover:border-[#1173d4]/50">
    <a href={template.href}>
      <img
        alt={`${template.title} Template`}
        className="h-40 w-full object-cover"
        src={template.imageUrl}
        onError={(e) => { e.target.onerror = null; e.target.src = "https://placehold.co/600x400/333/fff?text=Template+Placeholder" }}
      />
      <div className="p-4">
        <h4 className="font-semibold text-gray-900 dark:text-white">{template.title}</h4>
        <p className="text-sm text-gray-500 dark:text-gray-400">{template.description}</p>
      </div>
    </a>
  </div>
);

export default TemplateCard;