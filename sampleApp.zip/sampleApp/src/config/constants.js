const PAGES = {
  DASHBOARD: 'Dashboard',
  WORKFLOWS: 'Workflows',
  TEMPLATES: 'Templates',
  DOCUMENTS: 'Documents',
  SETTINGS: 'Settings',
};

const nodeCategories = ['Data Connectors', 'Processors', 'Gen AI'];

export { PAGES, nodeCategories };