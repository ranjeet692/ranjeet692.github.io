import { 
  // General Icons
  Search, UploadCloud, Plus, X, Settings2, Filter, ChevronDown, List, Clock,
  // New Icons for Workflow Builder Toolbar
  Save, Upload, Download, Send,
  // Navigation Icons
  LayoutDashboard, Settings, FileText, Blocks, Heart, 
  // Workflow Builder Nodes
  Database, Folders, Cloud, Cpu, File, Image 
} from 'lucide-react';

const workflowNodes = [
  { id: '1', name: 'Database', icon: Database, category: 'Data Connectors', type: 'input', data: { label: 'DB Source' }, position: { x: 50, y: 50 }, config: { connectionString: 'sqlite://...', query: 'SELECT * FROM documents' } },
  { id: '2', name: 'File Upload', icon: File, category: 'Data Connectors', type: 'input', data: { label: 'Upload Files' }, position: { x: 50, y: 150 }, config: { allowedTypes: ['pdf', 'docx'] } },
  { id: '3', name: 'Text Extraction', icon: Cpu, category: 'Processors', type: 'default', data: { label: 'Extract Text' }, position: { x: 300, y: 100 }, config: { language: 'en', ocrEnabled: true } },
  { id: '4', name: 'Compliance Check', icon: FileText, category: 'Processors', type: 'default', data: { label: 'Check Policy' }, position: { x: 550, y: 100 }, config: { policyName: 'GDPR', threshold: 0.9 } },
  { id: '5', name: 'LLM Analysis', icon: Blocks, category: 'Gen AI', type: 'output', data: { label: 'AI Summary' }, position: { x: 800, y: 100 }, config: { model: 'gemini-2.5-flash', prompt: 'Summarize key risks' } },
];

const initialEdges = [
  { id: 'e1-3', source: '1', target: '3', animated: true },
  { id: 'e2-3', source: '2', target: '3', animated: true },
  { id: 'e3-4', source: '3', target: '4' },
  { id: 'e4-5', source: '4', target: '5' },
];

export { workflowNodes, initialEdges };