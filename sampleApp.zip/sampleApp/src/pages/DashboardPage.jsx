import DashboardActions from '../components/dashboard/DashboardActions';
import RecentWorkflowTable from '../components/dashboard/RecentWorkflowTable';
import TemplateSection from '../components/dashboard/TemplateSection';

const DashboardPage = ({ onNavigate }) => (
  <div className="container mx-auto px-4 py-8 sm:px-6 lg:px-8">
    <DashboardActions onNavigate={onNavigate} />
    <div className="space-y-12">
      <RecentWorkflowTable />
      <TemplateSection />
    </div>
  </div>
);

export default DashboardPage;