// src/pages/WorkflowBuilderPage.jsx

import React, { useState, useEffect, useCallback } from 'react';
import WorkflowBuilderSidebar from '../components/workflows/WorkflowBuilderSidebar';
import WorkflowToolbar from '../components/workflows/WorkflowToolbar';
import WorkflowNode from '../components/workflows/WorkflowNode';
import NodeConfigPanel from '../components/workflows/NodeConfigPanel';

// Import workflow data
import WORKFLOW_TEMPLATES, { generateEdges } from '../data/nodeConfig';

const WorkflowBuilderPage = () => {
  // Start with the first workflow
  const [selectedWorkflowId, setSelectedWorkflowId] = useState('resume_shortlisting');
  const [currentWorkflow, setCurrentWorkflow] = useState(null);
  const [nodes, setNodes] = useState([]);
  const [edges, setEdges] = useState([]);
  const [selectedNode, setSelectedNode] = useState(null);

  // Load workflow when selection changes
  useEffect(() => {
    const workflow = WORKFLOW_TEMPLATES[selectedWorkflowId];
    if (workflow) {
      setCurrentWorkflow(workflow);
      setNodes([...workflow.nodes]); // Create a copy to allow modifications
      setEdges(generateEdges(workflow.nodes));
      setSelectedNode(null); // Clear selection when switching workflows
    }
  }, [selectedWorkflowId]);

  const onNodeClick = useCallback((node) => {
    setSelectedNode(node);
  }, []);

  const onConfigPanelClose = useCallback(() => {
    setSelectedNode(null);
  }, []);
  
  const onUpdateNode = useCallback((id, newConfig) => {
    setNodes(prevNodes => 
      prevNodes.map(node => 
        node.id === id ? { ...node, config: { ...node.config, ...newConfig } } : node
      )
    );
    // Update selected node to reflect changes
    setSelectedNode(prev => {
      if (prev && prev.id === id) {
        return { ...prev, config: { ...prev.config, ...newConfig } };
      }
      return prev;
    });
  }, []);

  const onWorkflowChange = useCallback((workflowId) => {
    setSelectedWorkflowId(workflowId);
  }, []);

  const renderEdges = () => {
    return edges.map(edge => {
      const sourceNode = nodes.find(n => n.id === edge.source);
      const targetNode = nodes.find(n => n.id === edge.target);

      if (!sourceNode || !targetNode) return null;

      const sx = sourceNode.position.x + 100; // Adjust based on node width
      const sy = sourceNode.position.y + 40;  // Center of node height
      const tx = targetNode.position.x;
      const ty = targetNode.position.y + 40;
      
      const path = `M${sx},${sy} L${tx},${ty}`;

      return (
        <path
          key={edge.id}
          d={path}
          stroke="#1173d4"
          strokeWidth="2"
          fill="none"
          className={edge.animated ? 'animate-dash' : ''}
          markerEnd="url(#arrowhead)"
        />
      );
    });
  };
  
  // CSS for animated edges
  const animatedEdgeStyle = `
    @keyframes dash {
      to {
        stroke-dashoffset: 0;
      }
    }
    .animate-dash {
      stroke-dasharray: 5;
      stroke-dashoffset: 10;
      animation: dash 1s linear infinite;
    }
  `;

  return (
    <div className="flex flex-1 overflow-hidden h-[calc(100vh-4rem)]">
      <style>{animatedEdgeStyle}</style>
      
      {/* Sidebar with workflow-specific nodes */}
      <WorkflowBuilderSidebar 
        currentWorkflow={currentWorkflow}
        nodes={nodes}
      />
      
      <div className={`flex-1 flex flex-col transition-all duration-300 ${selectedNode ? 'lg:mr-96' : ''}`}>
        {/* Toolbar with workflow selector */}
        <WorkflowToolbar 
          workflowName={currentWorkflow?.name}
          currentWorkflowId={selectedWorkflowId}
          onWorkflowChange={onWorkflowChange}
        />

        {/* Canvas area */}
        <main className="flex-1 relative overflow-hidden bg-gray-100/50 dark:bg-gray-800/20">
          <svg className="absolute inset-0 w-full h-full z-0 pointer-events-none">
            {/* Grid pattern */}
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="0.5" className="text-gray-300/30 dark:text-gray-700/30"/>
              </pattern>
              {/* Arrow marker for edges */}
              <marker
                id="arrowhead"
                markerWidth="10"
                markerHeight="10"
                refX="9"
                refY="3"
                orient="auto"
                markerUnits="strokeWidth"
              >
                <path d="M0,0 L0,6 L9,3 z" fill="#1173d4" />
              </marker>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
            {renderEdges()}
          </svg>
          
          {/* Nodes */}
          <div className="absolute inset-0 z-10 p-10 overflow-auto">
            {nodes.map(node => (
              <WorkflowNode
                key={node.id}
                node={node}
                onSelect={onNodeClick}
                isSelected={selectedNode && selectedNode.id === node.id}
              />
            ))}
          </div>

          {/* Empty state */}
          {nodes.length === 0 && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="text-center">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">No nodes in this workflow</h3>
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Select a different workflow or drag nodes from the sidebar.</p>
              </div>
            </div>
          )}
          
          {/* Workflow info overlay */}
          {currentWorkflow && (
            <div className="absolute buttom-2 right-4 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4 max-w-xs z-20 border border-gray-200 dark:border-gray-700">
              <h3 className="font-semibold text-gray-900 dark:text-white mb-1">{currentWorkflow.name}</h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">{currentWorkflow.description}</p>
              <div className="flex flex-wrap gap-1">
                {currentWorkflow.metadata?.tags?.map((tag, idx) => (
                  <span key={idx} className="inline-block px-2 py-0.5 text-xs rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                    {tag}
                  </span>
                ))}
              </div>
              <div className="mt-2 pt-2 border-t border-gray-200 dark:border-gray-700 text-xs text-gray-500 dark:text-gray-400">
                <div className="flex justify-between">
                  <span>Nodes:</span>
                  <span className="font-medium">{nodes.length}</span>
                </div>
                <div className="flex justify-between">
                  <span>Connections:</span>
                  <span className="font-medium">{edges.length}</span>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Configuration panel for selected node */}
      {selectedNode && (
        <NodeConfigPanel 
          selectedNode={selectedNode} 
          onClose={onConfigPanelClose} 
          onUpdateNode={onUpdateNode}
        />
      )}
    </div>
  );
};

export default WorkflowBuilderPage;