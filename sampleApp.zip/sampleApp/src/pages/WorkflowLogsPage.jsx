import WorkflowLogsTable from "../components/logs/WorkflowLogsTable";   
import LogsFilters from "../components/logs/LogsFilters";

const WorkflowLogsPage = () => {
  return (
    <div className="container mx-auto px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-white">Workflow Execution Logs</h1>
        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Detailed logs of all workflow executions, including status, duration, and step-by-step breakdowns.</p>
      </div>
      
      <LogsFilters />
      <WorkflowLogsTable />
    </div>
  );
};

export default WorkflowLogsPage;
