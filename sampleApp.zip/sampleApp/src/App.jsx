import React, { useState, useEffect, useCallback } from 'react';
import { 
  Search, UploadCloud, Plus, X, Settings2, Filter, ChevronDown, List, Clock,
  Save, Upload, Download, Send,
  LayoutDashboard, Settings, FileText, Blocks, Heart, 
  Database, Folders, Cloud, Cpu, File, Image 
} from 'lucide-react';

import { PAGES } from './config/constants';
import Header from './components/common/Header';
import DashboardPage from './pages/DashboardPage';
import WorkflowBuilderPage from './pages/WorkflowBuilderPage';
import WorkflowLogsPage from './pages/WorkflowLogsPage';

const App = () => {
  const [currentPage, setCurrentPage] = useState(PAGES.WORKFLOWS);
  const [isDarkMode, setIsDarkMode] = useState(true);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const renderPage = () => {
    if (currentPage === PAGES.WORKFLOWS) {
      return <WorkflowBuilderPage />;
    }
    
    return (
      <div className="container mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {(() => {
          switch (currentPage) {
            case PAGES.DASHBOARD:
              return <DashboardPage onNavigate={setCurrentPage} />;
            case PAGES.DOCUMENTS:
              return <WorkflowLogsPage />;
            case PAGES.TEMPLATES:
            case PAGES.SETTINGS:
              return (
                <>
                  <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{currentPage}</h1>
                  <p className="text-gray-500 dark:text-gray-400 mt-2">Content coming soon for the {currentPage} page!</p>
                </>
              );
            default:
              return <DashboardPage onNavigate={setCurrentPage} />;
          }
        })()}
      </div>
    );
  };

  return (
    <div className="font-display bg-[#f6f7f8] dark:bg-[#101922] flex min-h-screen w-full flex-col">
      <Header currentPage={currentPage} onNavigate={setCurrentPage} />
      <main className="flex-1 overflow-y-auto">
        {renderPage()}
      </main>
    </div>
  );
};

export default App;