import React, { useState, useEffect, useCallback } from 'react';
import { 
  // General Icons
  Search, UploadCloud, Plus, X, Settings2, Filter, ChevronDown, List, Clock,
  // New Icons for Workflow Builder Toolbar
  Save, Upload, Download, Send,
  // Navigation Icons
  LayoutDashboard, Settings, FileText, Blocks, Heart, 
  // Workflow Builder Nodes
  Database, Folders, Cloud, Cpu, File, Image 
} from 'lucide-react';
// We will simulate React Flow components since we cannot import the library directly, 
// but we will use the styles and structure it implies.
// For the sake of a fully functional simulation in a single file:
// We will use state to manage the visual nodes and edges (simplified).

// --- CONFIG & DATA STRUCTURES ---

const PAGES = {
  DASHBOARD: 'Dashboard',
  WORKFLOWS: 'Workflows',
  TEMPLATES: 'Templates',
  DOCUMENTS: 'Documents', // This page will now be the Workflow Logs/Status page
  SETTINGS: 'Settings',
};

const workflowRuns = [
  { name: 'Invoice Processing', status: 'Completed', docsProcessed: 12, startedAt: '2024-01-15 10:00 AM', duration: '1h 30m', statusColor: 'green' },
  { name: 'Contract Review', status: 'In Progress', docsProcessed: 5, startedAt: '2024-01-15 11:30 AM', duration: '2h 15m', statusColor: 'blue' },
  { name: 'Compliance Check', status: 'Completed', docsProcessed: 20, startedAt: '2024-01-14 02:00 PM', duration: '3h 45m', statusColor: 'green' },
  { name: 'Report Generation', status: 'Failed', docsProcessed: 8, startedAt: '2024-01-14 09:00 AM', duration: '1h 00m', statusColor: 'red' },
  { name: 'Data Extraction', status: 'Completed', docsProcessed: 15, startedAt: '2021-01-13 04:30 PM', duration: '2h 00m', statusColor: 'green' },
];

const allWorkflowLogs = [
    { name: 'Invoice Processing', status: 'Success', startTime: '2024-01-15 10:00 AM', duration: '5 minutes', steps: 12, statusColor: 'green' },
    { name: 'Contract Review', status: 'Failed', startTime: '2024-01-14 03:30 PM', duration: '10 minutes', steps: 8, statusColor: 'red' },
    { name: 'Expense Report', status: 'Success', startTime: '2024-01-13 09:15 AM', duration: '3 minutes', steps: 5, statusColor: 'green' },
    { name: 'Legal Document Analysis', status: 'Success', startTime: '2024-01-12 02:00 PM', duration: '15 minutes', steps: 20, statusColor: 'green' },
    { name: 'Customer Onboarding', status: 'Failed', startTime: '2024-01-11 11:45 AM', duration: '8 minutes', steps: 10, statusColor: 'red' },
    { name: 'Financial Report', status: 'Success', startTime: '2024-01-10 04:00 PM', duration: '7 minutes', steps: 15, statusColor: 'green' },
];

const templates = [
  { title: 'Invoice Processing', description: 'Automate invoice data extraction', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAkevcHNOEIjv1o-KFv79ynLfyEkGh0wdQggztL0Io_-PyFbcPSpx2WFd9saF-LZav5hrBHrfJ3qtYGWRq3wsGnjTMXcdeg4n5WmtojWVtW8jevfaTIaWO09wq_anoXLpqp9vNkUNOWNnUWXKpk8wH-oRz8SHT8bJch-xcM1AWMSTg5_YPQk3_F_DlwxCAEbMNUrkc47R8wcCGNukQzKhi0WVyvBQDj46tLVBGX4oBacxF7r4HL6j6QKst6O8Skofl55zJ5XDFjETT9jZnQsBHHRmd82', href: '#' },
  { title: 'Contract Review', description: 'Streamline contract review process', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDPv7qBiR7rNjk6YS7KMz2R3QKPXNCsxjkV_YGxu4vvXOuspoXUtPAabsB8Kc7iIkuf-D_RGbCjU_2yetMqOrwyCgy0huCOCGbvZwHnqcvmOwQzogk3ZJcFOC-6o34-zoPhOIZY_f4iaDZwsvEXT5_MrdIsD-Dj2fdlneqOyEEiEEVGkKX2O4rqBVxIixb2X1bHIROt0WHBfN0FwZsJVmMT0ALAiHY07wybXiHc1zPiin993TZQ9OON4W4cU7Ay5M2soMctiuTA-YN', href: '#' },
  { title: 'Compliance Check', description: 'Ensure regulatory compliance', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDfY3lMcDKzAT0Fim1KYYvDUysMAFUTqX3aImbTEEodi_4d6u19GcM-OeEoTBkzrMfiTxee6AYFbEKg85LveS3odAHlUoujUY1PL4yMNMpWNaIEcRdclEUe-viGU_2VTPex_pEANzbFDKsPBSeyEWHZkabV5JhW5-i0OpBf9AzrKCFrLFCtE7dgFKYdjQnYZXjl6jAYw1xoU7Tn-BufHy1_8P9ukIjp_H_DC19iP32C-YkBk6bMjgPxgoPzdkhfGLH-wR2jCrsBngXthnLv6zxJxCYImKs3zvlf6rYgCkLp_1IcnCSNauwt64Sfw-C0g_JK56av3MlgX_Lpolae9z', href: '#' },
  { title: 'Report Generation', description: 'Generate custom reports', imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCrXHE8NOVlwutVIrrQTJACbW4TysYM98DiY53TlCZWoVo5LJKZ6Ss3oQLJYF0DJGylXd0L8NvxNdITRBmTrqcejrI3F_R4evTrqwN9MJCjtStS_Zx6FWRYxftFowxzqTXHquaoNKFNr4v-Alb3JtsZId9QW6yHw25V7E68iK9tFDWoXFUpvzdkhfGLH-wR2jCrsBngXthnLv6zxJxCYImKs3zvlf6rYgCkLp_1IcnCSNauwt64Sfw-C0g_JK56av3MlgX_Lpolae9z', href: '#' },
];

const workflowNodes = [
  { id: '1', name: 'Database', icon: Database, category: 'Data Connectors', type: 'input', data: { label: 'DB Source' }, position: { x: 50, y: 50 }, config: { connectionString: 'sqlite://...', query: 'SELECT * FROM documents' } },
  { id: '2', name: 'File Upload', icon: File, category: 'Data Connectors', type: 'input', data: { label: 'Upload Files' }, position: { x: 50, y: 150 }, config: { allowedTypes: ['pdf', 'docx'] } },
  { id: '3', name: 'Text Extraction', icon: Cpu, category: 'Processors', type: 'default', data: { label: 'Extract Text' }, position: { x: 300, y: 100 }, config: { language: 'en', ocrEnabled: true } },
  { id: '4', name: 'Compliance Check', icon: FileText, category: 'Processors', type: 'default', data: { label: 'Check Policy' }, position: { x: 550, y: 100 }, config: { policyName: 'GDPR', threshold: 0.9 } },
  { id: '5', name: 'LLM Analysis', icon: Blocks, category: 'Gen AI', type: 'output', data: { label: 'AI Summary' }, position: { x: 800, y: 100 }, config: { model: 'gemini-2.5-flash', prompt: 'Summarize key risks' } },
];

const initialEdges = [
    { id: 'e1-3', source: '1', target: '3', animated: true },
    { id: 'e2-3', source: '2', target: '3', animated: true },
    { id: 'e3-4', source: '3', target: '4' },
    { id: 'e4-5', source: '4', target: '5' },
];

const nodeCategories = ['Data Connectors', 'Processors', 'Gen AI', 'ML Models'];

// --- SHARED COMPONENTS ---

const NavItem = ({ name, currentPage, onNavigate }) => (
  <button
    className={`rounded-lg px-3 py-2 text-sm transition-colors ${
      currentPage === name
        ? 'bg-[#1173d4]/10 font-semibold text-[#1173d4] dark:bg-[#1173d4]/20 dark:text-white'
        : 'font-medium text-gray-600 hover:bg-[#1173d4]/10 hover:text-[#1173d4] dark:text-gray-300 dark:hover:bg-[#1173d4]/20 dark:hover:text-white'
    }`}
    onClick={() => onNavigate(name)}
  >
    {name}
  </button>
);

const Logo = () => (
  <div className="flex items-center gap-2 text-gray-800 dark:text-white">
    {/* DocuMind Logo SVG */}
    <svg className="h-6 w-6 text-[#1173d4]" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path d="M16.883 14.899L12 17.525L7.117 14.899L3 12.825L12 7.675L21 12.825L16.883 14.899Z"></path>
      <path d="M12 21.325L3 16.175V7.675L12 2.525L21 7.675V16.175L12 21.325ZM12 19.175L18.883 15.1V9.4L12 13.525L5.117 9.4V15.1L12 19.175Z"></path>
    </svg>
    <h1 className="text-lg font-bold">DocuMind</h1>
  </div>
);

const Header = ({ currentPage, onNavigate }) => (
  <header className="sticky top-0 z-20 flex h-16 shrink-0 items-center justify-between border-b border-white/10 bg-[#f6f7f8]/80 px-4 backdrop-blur-sm dark:bg-[#101922]/80 sm:px-6 lg:px-8">
    <div className="flex items-center gap-6">
      <Logo />
      <nav className="hidden items-center gap-4 md:flex">
        {Object.values(PAGES).map(pageName => (
          <NavItem
            key={pageName}
            name={pageName}
            currentPage={currentPage}
            onNavigate={onNavigate}
          />
        ))}
      </nav>
    </div>
    <div className="flex items-center gap-4">
      <div className="relative hidden md:block">
        <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-500 dark:text-gray-400" />
        <input
          className="h-10 w-full min-w-[200px] rounded-lg border-none bg-white/50 pl-10 pr-4 text-sm text-gray-900 ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-[#1173d4] dark:bg-white/10 dark:text-white dark:ring-white/20 dark:placeholder:text-gray-400 dark:focus:ring-[#1173d4]"
          placeholder="Search"
          type="search"
        />
      </div>
      <button className="relative h-10 w-10 rounded-full">
        <img
          alt="User avatar"
          className="h-full w-full rounded-full object-cover"
          src="https://lh3.googleusercontent.com/aida-public/AB6AXuBFaPa-lKHfq9SaASLSuPIDqmDhfpqjBgCysjsezFxmrL3Gfihd8jgPRI6qmxu_42uhQLVUMWkGbio21V6rs5WmtojWVtW8jevfaTIaWO09wq_anoXLpqp9vNkUNOWNnUWXKpk8wH-oRz8SHT8bJch-xcM1AWMSTg5_YPQk3_F_DlwxCAEbMNUrkc47R8wcCGNukQzKhi0WVyvBQDj46tLVBGX4oBacxF7r4HL6j6QKst6O8Skofl55zJ5XDFjETT9jZnQsBHHRmd82"
        />
      </button>
    </div>
  </header>
);

// --- DASHBOARD PAGE COMPONENTS (from previous file) ---
const StatusPill = ({ status, color }) => {
  const isPulsing = status === 'In Progress';
  let bgColor, textColor;

  switch(color) {
      case 'green': 
          bgColor = 'bg-green-500/10';
          textColor = 'text-green-500';
          break;
      case 'red': 
          bgColor = 'bg-red-500/10';
          textColor = 'text-red-500';
          break;
      case 'blue': 
          bgColor = 'bg-blue-500/10';
          textColor = 'text-blue-500';
          break;
      default:
          bgColor = 'bg-gray-500/10';
          textColor = 'text-gray-500';
  }
  
  return (
    <span className={`inline-flex items-center rounded-full px-2 py-1 text-xs font-medium ${bgColor} ${textColor}`}>
      {/* Small dot for visual status */}
      {isPulsing && (
        <svg className={`-ml-0.5 mr-1 h-2 w-2 ${textColor} animate-pulse`} fill="currentColor" viewBox="0 0 8 8">
          <circle cx="4" cy="4" r="3"></circle>
        </svg>
      )}
      {status}
    </span>
  );
};

const RecentWorkflowTable = () => (
  <section>
    <h3 className="mb-4 text-xl font-semibold text-gray-900 dark:text-white">Recent Workflow Runs</h3>
    <div className="overflow-hidden rounded-lg border border-gray-200 bg-white dark:border-white/10 dark:bg-[#101922]/50">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-white/10">
          <thead className="bg-gray-50 dark:bg-white/5">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500 dark:text-gray-400" scope="col">Workflow Name</th>
              <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500 dark:text-gray-400" scope="col">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500 dark:text-gray-400" scope="col">Docs Processed</th>
              <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500 dark:text-gray-400" scope="col">Started At</th>
              <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500 dark:text-gray-400" scope="col">Duration</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200 bg-white dark:divide-white/10 dark:bg-transparent">
            {workflowRuns.map((run, index) => (
              <tr key={index}>
                <td className="whitespace-nowrap px-6 py-4 text-sm font-medium text-gray-900 dark:text-white">{run.name}</td>
                <td className="whitespace-nowrap px-6 py-4 text-sm">
                  <StatusPill status={run.status} color={run.statusColor} />
                </td>
                <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-500 dark:text-gray-400">{run.docsProcessed}</td>
                <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-500 dark:text-gray-400">{run.startedAt}</td>
                <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-500 dark:text-gray-400">{run.duration}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  </section>
);

const TemplateCard = ({ template }) => (
  <div className="group overflow-hidden rounded-lg border border-gray-200 bg-white transition-all hover:shadow-lg dark:border-white/10 dark:bg-[#101922]/50 dark:hover:border-[#1173d4]/50">
    <a href={template.href}>
      <img
        alt={`${template.title} Template`}
        className="h-40 w-full object-cover"
        src={template.imageUrl}
        // Fallback for image loading errors
        onError={(e) => { e.target.onerror = null; e.target.src = "https://placehold.co/600x400/333/fff?text=Template+Placeholder" }}
      />
      <div className="p-4">
        <h4 className="font-semibold text-gray-900 dark:text-white">{template.title}</h4>
        <p className="text-sm text-gray-500 dark:text-gray-400">{template.description}</p>
      </div>
    </a>
  </div>
);

const TemplateSection = () => (
  <section>
    <h3 className="mb-4 text-xl font-semibold text-gray-900 dark:text-white">Frequently Used Templates</h3>
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {templates.map((template, index) => (
        <TemplateCard key={index} template={template} />
      ))}
    </div>
  </section>
);

const DashboardActions = ({ onNavigate }) => (
  <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
    <div>
      <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Dashboard</h2>
      <p className="text-gray-500 dark:text-gray-400">Welcome back, Sarah. Here's what's happening.</p>
    </div>
    <div className="flex gap-2">
      <button className="flex h-10 items-center justify-center gap-2 rounded-lg bg-white px-4 text-sm font-medium text-gray-700 ring-1 ring-inset ring-gray-300 transition-all hover:bg-gray-50 dark:bg-white/10 dark:text-gray-300 dark:ring-white/20 dark:hover:bg-white/20">
        <UploadCloud className="h-4 w-4" />
        <span>Upload Documents</span>
      </button>
      <button 
        className="flex h-10 items-center justify-center gap-2 rounded-lg bg-[#1173d4] px-4 text-sm font-medium text-white shadow-sm transition-all hover:bg-[#1173d4]/90"
        onClick={() => onNavigate(PAGES.WORKFLOWS)}
      >
        <Plus className="h-4 w-4" />
        <span>Create Workflow</span>
      </button>
    </div>
  </div>
);

const DashboardPage = ({ onNavigate }) => (
  <div className="container mx-auto px-4 py-8 sm:px-6 lg:px-8">
    <DashboardActions onNavigate={onNavigate} />
    <div className="space-y-12">
      <RecentWorkflowTable />
      <TemplateSection />
    </div>
  </div>
);
// --- END DASHBOARD PAGE COMPONENTS ---


// --- WORKFLOW LOGS PAGE COMPONENT ---

const WorkflowLogsPage = () => {
    return (
        <div className="container mx-auto px-4 py-8 sm:px-6 lg:px-8">
            <div className="mb-8">
                <h1 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-white">Workflow Execution Logs</h1>
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Detailed logs of all workflow executions, including status, duration, and step-by-step breakdowns.</p>
            </div>
            
            <div className="mb-6 flex flex-wrap items-center gap-4">
                <div className="relative flex-1 min-w-[200px] md:min-w-[300px]">
                    <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-500 dark:text-gray-400" />
                    <input 
                        className="w-full rounded-lg border border-gray-300 bg-white/50 py-2.5 pl-10 pr-4 text-sm text-gray-900 placeholder-gray-500 focus:border-[#1173d4] focus:ring-[#1173d4] dark:border-gray-600 dark:bg-white/10 dark:text-white dark:placeholder-gray-400" 
                        placeholder="Search by workflow name, status, or date" 
                        type="search"
                    />
                </div>
                
                <div className="flex flex-wrap gap-2">
                    <button className="flex items-center gap-1.5 rounded-lg bg-gray-100 dark:bg-white/10 px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 transition-colors hover:bg-gray-200 dark:hover:bg-white/20">
                        <Filter className="h-4 w-4" />
                        <span>Status</span>
                        <ChevronDown className="h-3 w-3" />
                    </button>
                    <button className="flex items-center gap-1.5 rounded-lg bg-gray-100 dark:bg-white/10 px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 transition-colors hover:bg-gray-200 dark:hover:bg-white/20">
                        <Clock className="h-4 w-4" />
                        <span>Date Range</span>
                        <ChevronDown className="h-3 w-3" />
                    </button>
                    <button className="flex items-center gap-1.5 rounded-lg bg-gray-100 dark:bg-white/10 px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 transition-colors hover:bg-gray-200 dark:hover:bg-white/20">
                        <List className="h-4 w-4" />
                        <span>Workflow</span>
                        <ChevronDown className="h-3 w-3" />
                    </button>
                </div>
            </div>

            <div className="overflow-hidden rounded-lg border border-gray-200 dark:border-white/10 bg-white dark:bg-[#101922]/50">
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200 dark:divide-white/10">
                        <thead className="bg-gray-50 dark:bg-white/5">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500 dark:text-gray-400" scope="col">Workflow Name</th>
                                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500 dark:text-gray-400" scope="col">Status</th>
                                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500 dark:text-gray-400" scope="col">Start Time</th>
                                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500 dark:text-gray-400" scope="col">Duration</th>
                                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500 dark:text-gray-400" scope="col">Steps</th>
                                <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500 dark:text-gray-400" scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200 bg-white dark:divide-white/10 dark:bg-transparent">
                            {allWorkflowLogs.map((log, index) => (
                                <tr key={index}>
                                    <td className="whitespace-nowrap px-6 py-4 text-sm font-medium text-gray-900 dark:text-white">{log.name}</td>
                                    <td className="whitespace-nowrap px-6 py-4 text-sm">
                                        <StatusPill status={log.status} color={log.statusColor} />
                                    </td>
                                    <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-500 dark:text-gray-400">{log.startTime}</td>
                                    <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-500 dark:text-gray-400">{log.duration}</td>
                                    <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-500 dark:text-gray-400">{log.steps}</td>
                                    <td className="whitespace-nowrap px-6 py-4 text-sm font-medium">
                                        <button className="text-[#1173d4] hover:underline text-sm font-medium">View Details</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};


// --- WORKFLOW BUILDER COMPONENTS ---
const WorkflowToolbar = () => (
    <div className="flex h-16 shrink-0 items-center justify-between border-b border-gray-200/50 bg-[#f6f7f8] px-4 dark:border-gray-700/50 dark:bg-[#101922]">
        <div className="flex items-center gap-4">
            <h2 className="text-lg font-bold text-gray-900 dark:text-white">Invoice Processing Workflow</h2>
            <span className="rounded-full bg-gray-200 px-3 py-1 text-xs font-medium text-gray-600 dark:bg-gray-700 dark:text-gray-300">Draft</span>
        </div>
        <div className="flex items-center gap-2">
            <button className="flex items-center gap-1.5 rounded-lg bg-gray-200 px-3 py-2 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600">
                <Upload className="h-4 w-4" />
                <span>Import</span>
            </button>
            <button className="flex items-center gap-1.5 rounded-lg bg-gray-200 px-3 py-2 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600">
                <Download className="h-4 w-4" />
                <span>Export</span>
            </button>
            <button className="flex items-center gap-1.5 rounded-lg bg-white px-3 py-2 text-sm font-medium text-[#1173d4] ring-1 ring-inset ring-[#1173d4]/50 transition-colors hover:bg-gray-50 dark:bg-gray-900 dark:text-[#1173d4] dark:ring-[#1173d4]/30 dark:hover:bg-gray-800">
                <Save className="h-4 w-4" />
                <span>Save</span>
            </button>
            <button className="flex items-center gap-1.5 rounded-lg bg-[#1173d4] px-4 py-2 text-sm font-semibold text-white shadow-md shadow-[#1173d4]/30 transition-all hover:bg-[#1173d4]/90">
                <Send className="h-4 w-4" />
                <span>Deploy</span>
            </button>
        </div>
    </div>
);

const NodeConfigPanel = ({ selectedNode, onClose, onUpdateNode }) => {
  const [formData, setFormData] = useState(selectedNode?.config || {});

  // Update local state when selectedNode changes
  useEffect(() => {
    setFormData(selectedNode?.config || {});
  }, [selectedNode]);

  if (!selectedNode) return null;

  const handleConfigChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSave = () => {
    onUpdateNode(selectedNode.id, formData);
    onClose();
  };

  const renderConfigField = (key, value) => {
    // Simple rendering logic based on value type for demonstration
    if (typeof value === 'boolean') {
      return (
        <div key={key} className="flex items-center justify-between">
          <label className="text-sm font-medium text-gray-800 dark:text-gray-200">
            {key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1')}
          </label>
          <input
            type="checkbox"
            name={key}
            checked={formData[key] || false}
            onChange={handleConfigChange}
            className="h-5 w-5 rounded border-gray-300 text-[#1173d4] focus:ring-[#1173d4] dark:border-gray-600 dark:bg-gray-700"
          />
        </div>
      );
    }
    
    // Default to text/textarea input
    const isTextArea = key.toLowerCase().includes('query') || key.toLowerCase().includes('prompt');

    return (
      <div key={key} className="space-y-1">
        <label htmlFor={key} className="text-sm font-medium text-gray-800 dark:text-gray-200">
          {key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1')}
        </label>
        {isTextArea ? (
          <textarea
            id={key}
            name={key}
            value={formData[key] || ''}
            onChange={handleConfigChange}
            rows={3}
            className="w-full rounded-lg border border-gray-300 bg-white p-2 text-sm text-gray-900 focus:border-[#1173d4] focus:ring-[#1173d4] dark:border-gray-600 dark:bg-gray-700 dark:text-white"
          />
        ) : (
          <input
            id={key}
            type="text"
            name={key}
            value={formData[key] || ''}
            onChange={handleConfigChange}
            className="w-full rounded-lg border border-gray-300 bg-white p-2 text-sm text-gray-900 focus:border-[#1173d4] focus:ring-[#1173d4] dark:border-gray-600 dark:bg-gray-700 dark:text-white"
          />
        )}
      </div>
    );
  };

  return (
    // Slide-in panel structure
    <div className="absolute right-0 top-0 z-10 h-full w-96 flex-col border-l border-gray-200/50 bg-[#f6f7f8] shadow-2xl transition-transform dark:border-gray-500/10 dark:bg-[#101922] flex">
      <header className="flex items-center justify-between p-4 border-b border-gray-200/50 dark:border-gray-500/10">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">
          <Settings2 className="inline-block h-5 w-5 mr-2 text-[#1173d4]" />
          {selectedNode.name} Configuration
        </h2>
        <button onClick={onClose} className="rounded-full p-1 transition-colors hover:bg-gray-200 dark:hover:bg-gray-700">
          <X className="h-5 w-5 text-gray-500 dark:text-gray-400" />
        </button>
      </header>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {Object.keys(selectedNode.config).map(key => renderConfigField(key, selectedNode.config[key]))}
      </div>

      <footer className="p-4 border-t border-gray-200/50 dark:border-gray-500/10 flex justify-end gap-2">
        <button 
          onClick={onClose} 
          className="rounded-lg bg-gray-200 px-4 py-2 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600"
        >
          Cancel
        </button>
        <button 
          onClick={handleSave} 
          className="rounded-lg bg-[#1173d4] px-4 py-2 text-sm font-medium text-white shadow-sm transition-colors hover:bg-[#1173d4]/90"
        >
          Save Changes
        </button>
      </footer>
    </div>
  );
};


const WorkflowNode = ({ node, onSelect, isSelected }) => {
  const Icon = node.icon;
  
  return (
    <div
      onClick={() => onSelect(node)}
      className={`absolute flex cursor-pointer flex-col items-center gap-2 rounded-lg border p-4 shadow-md transition-all 
        ${isSelected 
          ? 'border-[#1173d4] ring-2 ring-[#1173d4] bg-white dark:bg-gray-700' 
          : 'border-gray-300 bg-white hover:shadow-lg dark:border-gray-600 dark:bg-gray-800 dark:hover:border-[#1173d4]'}
      `}
      style={{ left: node.position.x, top: node.position.y }}
    >
      <Icon className="h-6 w-6 text-[#1173d4]" />
      <span className="text-sm font-medium text-gray-900 dark:text-white">{node.data.label}</span>
      {/* Simulation of React Flow handles */}
      <div className="absolute -left-2 top-1/2 h-4 w-4 rounded-full bg-gray-400 dark:bg-gray-500 border-2 border-white dark:border-[#101922]"></div>
      <div className="absolute -right-2 top-1/2 h-4 w-4 rounded-full bg-gray-400 dark:bg-gray-500 border-2 border-white dark:border-[#101922]"></div>
    </div>
  );
};

const NodeGridItem = ({ name, Icon }) => (
  <div className="flex cursor-grab flex-col items-center gap-2 rounded-lg border border-gray-200/50 bg-white/5 p-3 text-center shadow-sm transition-all hover:bg-[#1173d4]/5 dark:border-gray-500/10 dark:hover:bg-[#1173d4]/10">
    <Icon className="h-6 w-6 text-[#1173d4]" />
    <h3 className="text-sm font-semibold text-gray-800 dark:text-gray-200">{name}</h3>
  </div>
);

const WorkflowBuilderSidebar = () => {
  const [activeTab, setActiveTab] = useState(nodeCategories[0]);
  
  const getNodeComponent = (name) => {
    const node = workflowNodes.find(n => n.name === name);
    return node ? node.icon : Blocks;
  };

  const currentNodes = workflowNodes.filter(node => node.category === activeTab);

  return (
    <aside className="hidden lg:flex w-80 flex-col border-r border-gray-200/50 dark:border-gray-500/10 shrink-0">
      <div className="p-4">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">Nodes</h2>
      </div>
      <div className="border-b border-gray-200/50 dark:border-gray-500/10">
        <nav aria-label="Tabs" className="-mb-px flex space-x-2 px-4 overflow-x-auto">
          {nodeCategories.map((category) => (
            <button
              key={category}
              className={`whitespace-nowrap border-b-2 px-1 py-3 text-sm font-medium transition-colors ${
                activeTab === category
                  ? 'border-[#1173d4] text-[#1173d4]'
                  : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 dark:text-gray-400 dark:hover:border-gray-600 dark:hover:text-gray-200'
              }`}
              onClick={() => setActiveTab(category)}
            >
              {category}
            </button>
          ))}
        </nav>
      </div>
      <div className="flex-1 overflow-y-auto p-4">
        <div className="grid grid-cols-2 gap-4">
          {currentNodes.map((node) => (
            <NodeGridItem key={node.id} name={node.name} Icon={getNodeComponent(node.name)} />
          ))}
          {/* Placeholder items for categories without full mock data */}
          {activeTab !== 'Data Connectors' && activeTab !== 'Processors' && (
             Array(4).fill(null).map((_, index) => (
                <NodeGridItem key={`placeholder-${index}`} name={`${activeTab} ${index + 1}`} Icon={Blocks} />
             ))
          )}
        </div>
      </div>
    </aside>
  );
};

const WorkflowBuilderPage = () => {
  const [nodes, setNodes] = useState(workflowNodes);
  const [edges, setEdges] = useState(initialEdges);
  const [selectedNode, setSelectedNode] = useState(null);

  const onNodeClick = useCallback((node) => {
    setSelectedNode(node);
  }, []);

  const onConfigPanelClose = useCallback(() => {
    setSelectedNode(null);
  }, []);
  
  const onUpdateNode = useCallback((id, newConfig) => {
    setNodes(prevNodes => 
        prevNodes.map(node => 
            node.id === id ? { ...node, config: newConfig } : node
        )
    );
    // Also update the selected node state to reflect changes immediately
    setSelectedNode(prev => (prev && prev.id === id) ? { ...prev, config: newConfig } : null);
  }, []);

  // Simple edge rendering for visualization
  const renderEdges = () => {
    return edges.map(edge => {
      const sourceNode = nodes.find(n => n.id === edge.source);
      const targetNode = nodes.find(n => n.id === edge.target);

      if (!sourceNode || !targetNode) return null;

      const sx = sourceNode.position.x + 100; // Center of node width
      const sy = sourceNode.position.y + 40;  // Center of node height
      const tx = targetNode.position.x;
      const ty = targetNode.position.y + 40;
      
      // Simple straight line path
      const path = `M${sx},${sy} L${tx},${ty}`;

      return (
        <path
          key={edge.id}
          d={path}
          stroke="#1173d4"
          strokeWidth="2"
          fill="none"
          className={edge.animated ? 'animate-dash' : ''}
          style={{ transition: 'stroke-dashoffset 0.5s linear' }}
        />
      );
    });
  };
  
  // Custom CSS for simple dash animation (simulating animated edges)
  const animatedEdgeStyle = `
    @keyframes dash {
      to {
        stroke-dashoffset: 0;
      }
    }
    .animate-dash {
      stroke-dasharray: 5;
      stroke-dashoffset: 10;
      animation: dash 1s linear infinite;
    }
  `;

  return (
    <div className="flex flex-1 overflow-hidden h-[calc(100vh-4rem)]">
      <style>{animatedEdgeStyle}</style>
      <WorkflowBuilderSidebar />
      
      <div className={`flex-1 flex flex-col transition-all duration-300 ${selectedNode ? 'lg:mr-96' : ''}`}>
        
        {/* New Workflow Toolbar */}
        <WorkflowToolbar />

        {/* React Flow Canvas Simulation */}
        <main className="flex-1 relative overflow-hidden bg-gray-100/50 dark:bg-gray-800/20">
            <svg className="absolute inset-0 w-full h-full z-0 pointer-events-none">
                {/* Grid lines simulating React Flow background */}
                <defs>
                    <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                        <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="0.5" className="text-gray-300/30 dark:text-gray-700/30"/>
                    </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#grid)" />
                {renderEdges()}
            </svg>
            
            <div className="absolute inset-0 z-10 p-10">
              {nodes.map(node => (
                <WorkflowNode
                  key={node.id}
                  node={node}
                  onSelect={onNodeClick}
                  isSelected={selectedNode && selectedNode.id === node.id}
                />
              ))}
            </div>

            {/* Empty state overlay (hidden when nodes are present) */}
            {nodes.length === 0 && (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="text-center">
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Drag and drop nodes here</h3>
                        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Select nodes from the sidebar to start building.</p>
                    </div>
                </div>
            )}
        </main>
      </div>

      {/* Node Configuration Panel */}
      {selectedNode && (
        <NodeConfigPanel 
          selectedNode={selectedNode} 
          onClose={onConfigPanelClose} 
          onUpdateNode={onUpdateNode}
        />
      )}
    </div>
  );
};


// --- MAIN APPLICATION ENTRY POINT ---

const App = () => {
  const [currentPage, setCurrentPage] = useState(PAGES.WORKFLOWS); // Start on Workflows page
  const [isDarkMode, setIsDarkMode] = useState(true);

  // Effect to apply the dark mode class to the body for consistent theming
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const renderPage = () => {
    // The Workflow Builder page handles its own layout (sidebar + main area)
    if (currentPage === PAGES.WORKFLOWS) {
        return <WorkflowBuilderPage />;
    }
    
    // For all other pages, use the standard container layout.
    return (
      <div className="container mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {(() => {
          switch (currentPage) {
            case PAGES.DASHBOARD:
              return <DashboardPage onNavigate={setCurrentPage} />;
            case PAGES.DOCUMENTS:
              return <WorkflowLogsPage />; // New page component
            // Placeholder pages
            case PAGES.TEMPLATES:
            case PAGES.SETTINGS:
              return (
                <>
                  <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{currentPage}</h1>
                  <p className="text-gray-500 dark:text-gray-400 mt-2">Content coming soon for the {currentPage} page!</p>
                </>
              );
            default:
              return <DashboardPage onNavigate={setCurrentPage} />;
          }
        })()}
      </div>
    );
  };

  return (
    <div className="font-display bg-[#f6f7f8] dark:bg-[#101922] flex min-h-screen w-full flex-col">
      <Header currentPage={currentPage} onNavigate={setCurrentPage} />
      {/* Main content area, which takes up the remaining vertical space */}
      <main className="flex-1 overflow-y-auto">
        {renderPage()}
      </main>
    </div>
  );
};

export default App;
